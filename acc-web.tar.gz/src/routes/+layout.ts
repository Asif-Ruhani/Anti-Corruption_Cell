import { browser } from '$app/environment';
import { langCode } from '$lib/translate';
import { language } from '../stores/language';

export async function load() {
	if (browser) {
		const storedLangCode = localStorage.getItem('lang_code') || 'en';
		langCode.set(storedLangCode);
		language.set(storedLangCode);
	}
	return {};
}
