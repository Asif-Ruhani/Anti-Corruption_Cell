<script lang="ts">
	import { PUBLIC_API_URL } from '$env/static/public';
	import { onDestroy, onMount } from 'svelte';
	import { writable } from 'svelte/store';
	import { filters } from '../../../stores/filter';
	import { userId } from '../../../stores/auth';
	import SortFilter from '$lib/components/dashboard/common/SortFilter.svelte';
	import ComplaintPreview from '$lib/components/dashboard/common/ComplaintPreviewBox.svelte';
	import CategoryFilter from '$lib/components/dashboard/common/CategoryFilter.svelte';
	import ComplaintList from '$lib/components/dashboard/common/ComplaintList.svelte';
	import { translate } from '$lib/translate';

	const isGeneralUser: boolean = false;
	const shortPreview: boolean = false;

	const complaints = writable([]);
	async function fetchComplaints(filters) {
		try {
			const params = new URLSearchParams(
				Object.entries(filters).filter(([_, value]) => value !== null && value !== '')
			);

			params.append('user_id', $userId);

			const response = await fetch(`${PUBLIC_API_URL}/complaints?${params.toString()}`);

			if (response.ok) {
				const data = await response.json();
				complaints.set(data);
			} else {
				complaints.set([]);
			}
		} catch (err) {
			console.error('Error fetching complaints:', err);
			complaints.set([]);
		}
	}

	onMount(async () => {
		userId.set(localStorage.getItem('user_id') || '-1');
		const response = await fetch(
			`${PUBLIC_API_URL}/complaints?user_id=${localStorage.getItem('user_id') || '-1'}`
		);

		if (response.ok) {
			complaints.set(await response.json());
		} else {
			console.error('Failed to load complaints');
		}
	});

	$: {
		const filterValues = $filters;
		fetchComplaints(filterValues);
	}

	let translateFunction = (key: string) => key;
	const unsubscribe = translate.subscribe((fn) => {
		translateFunction = fn;
	});

	onDestroy(() => {
		unsubscribe();
	});
</script>

<SortFilter title={translateFunction('your_complaints')} />
<div class="flex h-full">
	<!-- Left Sidebar / Filter -->
	<div class="border-r-2 h-full">
		<CategoryFilter />
	</div>

	<!-- Center Container for Complaints List -->
	<div class="flex-grow overflow-y-auto">
		<ComplaintList>
			<div
				class="sticky top-0 grid lg:grid-cols-4 md:grid-cols-3 gap-y-4 w-full justify-items-center pb-8"
			>
				{#if $complaints.length !== 0}
					{#each $complaints as complaint}
						<ComplaintPreview
							userId={$userId}
							{shortPreview}
							{isGeneralUser}
							complaintObj={complaint}
							complaintCity={complaint.city}
							complaintId={complaint.complaint_id}
							complaintDesc={complaint.desc}
							complaintCatId={complaint.cat_id}
							complaintDateTime={complaint.created_at}
							complaintStatus={complaint.status}
						/>
					{/each}
				{:else}
					<div class="mx-auto w-screen p-8">
						<span class="text-4xl">No complaints found.</span>
					</div>
				{/if}
			</div>
		</ComplaintList>
	</div>
</div>
