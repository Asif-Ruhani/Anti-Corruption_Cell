<script>
	import { goto } from '$app/navigation';
	import { page } from '$app/stores';
	import { PUBLIC_API_URL } from '$env/static/public';
	import { langCode, translate } from '$lib/translate';
	import { formatDate } from '$lib/utils/dateUtils';
	import { updateComplaintStatus } from '$lib/utils/fetchUtils';
	import { onDestroy, onMount } from 'svelte';
	import { writable } from 'svelte/store';

	let modalOpen = false;
	let attachments = [];

	let selectedMedia = '';
	let mediaType = '';

	let videoElement = null;

	const urls = [
		'http://localhost:5173/videos/video.mp4',
		'http://localhost:5173/images/asif.jpg',
		'http://localhost:5173/audios/audio.mp3'
	];

	function getMediaType(filename) {
		const file_type = filename.split('/')[0];
		if (file_type === 'image') {
			return 'image';
		} else if (file_type === 'video') {
			return 'video';
		} else if (file_type === 'audio') {
			return 'video';
		} else {
			return 'unknown';
		}
	}

	function openModal(mediaUrl) {
		selectedMedia = PUBLIC_API_URL + '/' + mediaUrl.file_path;
		mediaType = getMediaType(mediaUrl.file_type);
		console.debug(selectedMedia);

		modalOpen = true;
	}

	// Function to close the modal
	function closeModal() {
		modalOpen = false;
	}

	let translateFunction = (key) => key;
	const unsubscribe = translate.subscribe((fn) => {
		translateFunction = fn;
	});

	onDestroy(() => {
		unsubscribe();
	});

	let feedbackId = writable(-1);
	let feedbackLevel = writable(0);

	let lawyerMode = writable(false);

	let commentId = writable(-1);
	let comments = writable('');
	let isSolved = writable(false);
	let roleId = writable('user');
	let userId = writable(-1);

	let complaint = null;
	let error = null;

	$: id = $page.url.pathname.split('/').pop();

	let mamunMode = writable(false);

	onMount(async () => {
		mamunMode.set(localStorage.getItem('mamun_user_id') === null);
		lawyerMode.set((localStorage.getItem('lawyer_mode') || 'false') === 'user');

		roleId.set(localStorage.getItem('role_id') || 'user');

		let tmp = localStorage.getItem('user_id') || '-1';
		userId.set(parseInt(tmp, 10));

		console.debug($lawyerMode, $roleId);

		try {
			const response = await fetch(`${PUBLIC_API_URL}/comments/${id}`);
			if (!response.ok) throw new Error('Failed to fetch comment data');
			const cmts = await response.json();
			console.debug(cmts);
			comments.set(cmts.comment || '');
			commentId.set(cmts.cmt_id || -1);
		} catch (err) {}

		try {
			const response = await fetch(`${PUBLIC_API_URL}/feedback/complaint/${id}`);
			if (!response.ok) throw new Error('Failed to fetch complaint data');
			const json = await response.json();
			console.debug(parseInt(json.level, 10));
			feedbackLevel.set(parseInt(json.level, 10) || 0);
		} catch (err) {}

		try {
			const response = await fetch(`${PUBLIC_API_URL}/complaints/${id}`);
			if (!response.ok) throw new Error('Failed to fetch complaint data');
			complaint = await response.json();
			isSolved.set(complaint.status === 'solved' || false);
		} catch (err) {
			error = err.message;
		}

		try {
			const response = await fetch(`${PUBLIC_API_URL}/attachments/complaint/${id}`);
			if (!response.ok) throw new Error('Failed to fetch complaint data');
			attachments = await response.json();
		} catch (err) {
			error = err.message;
		}
	});

	let likes = 8;
	let dislikes = 8;

	let liked = false;
	let disliked = false;

	const toggleLike = () => {
		if ($roleId !== 'user') return;

		if (liked) {
			likes--;
		} else {
			likes++;
			if (disliked) {
				disliked = false;
				dislikes--;
			}
		}
		liked = !liked;
	};

	const toggleDislike = () => {
		if (disliked) {
			dislikes--;
		} else {
			dislikes++;
			if (liked) {
				liked = false;
				likes--;
			}
		}
		disliked = !disliked;
	};

	async function handleUpdateStatus(complaintId, status) {
		try {
			complaint.status = status;
			const result = await updateComplaintStatus(complaintId, status);
			isSolved.set(status === 'solved');
			console.log(result.message);
		} catch (error) {
			console.error(error);
		}
	}

	// Function to update a comment
	async function updateComment() {
		const commentData = {
			complaint_id: id,
			comment_id: $commentId,
			comment: $comments
		};

		try {
			// Send PUT request to the server to update the comment
			const response = await fetch(PUBLIC_API_URL + `/comments`, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json'
				},
				body: JSON.stringify(commentData)
			});

			if (!response.ok) {
				throw new Error(`Failed to update comment: ${response.statusText}`);
			}

			const updatedComment = await response.json();

			return updatedComment;
		} catch (error) {
			console.error('Error updating comment:', error);
			throw error;
		}
	}

	async function createComment() {
		const commentData = {
			complaint_id: id,
			comment: $comments
		};

		try {
			const response = await fetch(PUBLIC_API_URL + `/comments`, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json'
				},
				body: JSON.stringify(commentData)
			});

			if (!response.ok) {
				throw new Error(`Failed to create comment: ${response.statusText}`);
			}

			const createdComment = await response.json();

			return createdComment;
		} catch (error) {
			console.error('Error creating comment:', error);
			throw error;
		}
	}

	let debounceTimer;
	const handleKeyPress = () => {
		clearTimeout(debounceTimer);
		debounceTimer = setTimeout(() => {
			handleSubmitComment();
		}, 500);
	};

	async function handleSubmitComment() {
		updateComment();
	}

	function getFileName(file_path) {
		return file_path.split('/').pop();
	}

	async function upsertFeedback(level) {
		const payload = {
			complaint_id: id,
			level: level.toString()
		};

		feedbackLevel.set(level);

		try {
			const response = await fetch(PUBLIC_API_URL + `/feedback/upsert`, {
				method: 'POST',
				headers: {
					'Content-Type': 'application/json'
				},
				body: JSON.stringify(payload)
			});

			if (!response.ok) {
				throw new Error(`Failed to create comment: ${response.statusText}`);
			}
		} catch (error) {
			console.error('Error creating comment:', error);
			throw error;
		}
	}
</script>

{#if error}
	<div class="error">{error}</div>
{:else if !complaint}
	<div class="container">Loading...</div>
{:else}
	{#if $mamunMode}
		<div
			on:click={() => {
				goto('/dashboard');
			}}
			class="inline-flex items-center border border-green-300 px-3 py-1.5 ml-4 mt-6 rounded-md text-green-600
		hover:bg-green-100 transition"
		>
			<svg
				xmlns="http://www.w3.org/2000/svg"
				fill="none"
				viewBox="0 0 24 24"
				stroke="currentColor"
				class="h-6 w-6"
			>
				<path
					stroke-linecap="round"
					stroke-linejoin="round"
					stroke-width="2"
					d="M7 16l-4-4m0 0l4-4m-4 4h18"
				>
				</path>
			</svg>
			<span class="ml-1 font-semibold text-lg">{translateFunction('dashboard')}</span>
		</div>
	{/if}

	<div class="p-4 bg-gray-50 flex flex-col items-center justify-center">
		<div class="pt-2 p-8 bg-gray-50 flex items-center justify-center">
			<div class="px-5 py-4 bg-white shadow rounded-lg max-w-lg">
				<div class="flex mb-4">
					<svg
						class="w-10 h-10 text-gray-400"
						aria-hidden="true"
						xmlns="http://www.w3.org/2000/svg"
						width="24"
						height="24"
						fill="currentColor"
						viewBox="0 0 24 24"
					>
						<path
							fill-rule="evenodd"
							d="M12 20a7.966 7.966 0 0 1-5.002-1.756l.002.001v-.683c0-1.794 1.492-3.25 3.333-3.25h3.334c1.84 0 3.333 1.456 3.333 3.25v.683A7.966 7.966 0 0 1 12 20ZM2 12C2 6.477 6.477 2 12 2s10 4.477 10 10c0 5.5-4.44 9.963-9.932 10h-.138C6.438 21.962 2 17.5 2 12Zm10-5c-1.84 0-3.333 1.455-3.333 3.25S10.159 13.5 12 13.5c1.84 0 3.333-1.455 3.333-3.25S13.841 7 12 7Z"
							clip-rule="evenodd"
						/>
					</svg>

					<div class="ml-2 mt-0.5">
						<span class="block font-medium text-base leading-snug text-gray-800"
							>{complaint.title}</span
						>
						<div>
							<span class="flex flex-row text-sm text-gray-500 font-light leading-snug"
								>{formatDate(complaint.created_at, $langCode)}
								<svg
									class="w-[16px] h-[16px] fill-[#8e8e8e] mx-1"
									viewBox="0 0 384 512"
									xmlns="http://www.w3.org/2000/svg"
								>
									<!--! Font Awesome Free 6.4.2 by @fontawesome - https://fontawesome.com License - https://fontawesome.com/license (Commercial License) Copyright 2023 Fonticons, Inc. -->
									<path
										d="M215.7 499.2C267 435 384 279.4 384 192C384 86 298 0 192 0S0 86 0 192c0 87.4 117 243 168.3 307.2c12.3 15.3 35.1 15.3 47.4 0zM192 128a64 64 0 1 1 0 128 64 64 0 1 1 0-128z"
									></path>
								</svg>
								{translateFunction(complaint.city.toLocaleLowerCase())}</span
							>
						</div>
					</div>
				</div>

				<p class="text-gray-800 leading-snug md:leading-normal py-4">
					<span class="font-semibold">{translateFunction('address')}:</span>
					{complaint.address}
				</p>

				<p class="text-gray-800 leading-snug md:leading-normal break-words">
					{complaint.desc}
				</p>

				<div class="flex items-center mt-5 space-x-6">
					<!-- Like Button -->
					<div class="hidden flex items-center cursor-pointer" on:click={toggleLike}>
						<svg
							class="w-6 h-6"
							aria-hidden="true"
							xmlns="http://www.w3.org/2000/svg"
							width="24"
							mollit
							anim
							id
							est
							laborum.
							height="24"
							fill={liked ? 'blue' : 'gray'}
							viewBox="0 0 24 24"
						>
							<path
								fill-rule="evenodd"
								d="M15.03 9.684h3.965c.322 0 .64.08.925.232.286.153.532.374.717.645a2.109 2.109 0 0 1 .242 1.883l-2.36 7.201c-.288.814-.48 1.355-1.884 1.355-2.072 0-4.276-.677-6.157-1.256-.472-.145-.924-.284-1.348-.404h-.115V9.478a25.485 25.485 0 0 0 4.238-5.514 1.8 1.8 0 0 1 .901-.83 1.74 1.74 0 0 1 1.21-.048c.396.13.736.397.96.757.225.36.32.788.269 1.211l-1.562 4.63ZM4.177 10H7v8a2 2 0 1 1-4 0v-6.823C3 10.527 3.527 10 4.176 10Z"
								clip-rule="evenodd"
							/>
						</svg>
						<span class="ml-1 text-gray-500 font-light">{likes}</span>
					</div>

					<!-- Dislike Button -->
					<div class="hidden flex items-center cursor-pointer" on:click={toggleDislike}>
						<svg
							class="w-6 h-6"
							aria-hidden="true"
							xmlns="http://www.w3.org/2000/svg"
							width="24"
							height="24"
							fill={disliked ? 'red' : 'gray'}
							viewBox="0 0 24 24"
						>
							<path
								fill-rule="evenodd"
								d="M8.97 14.316H5.004c-.322 0-.64-.08-.925-.232a2.022 2.022 0 0 1-.717-.645 2.108 2.108 0 0 1-.242-1.883l2.36-7.201C5.769 3.54 5.96 3 7.365 3c2.072 0 4.276.678 6.156 1.256.473.145.925.284 1.35.404h.114v9.862a25.485 25.485 0 0 0-4.238 5.514c-.197.376-.516.67-.901.83a1.74 1.74 0 0 1-1.21.048 1.79 1.79 0 0 1-.96-.757 1.867 1.867 0 0 1-.269-1.211l1.562-4.63ZM19.822 14H17V6a2 2 0 1 1 4 0v6.823c0 .65-.527 1.177-1.177 1.177Z"
								clip-rule="evenodd"
							/>
						</svg>
						<span class="ml-1 text-gray-500 font-light">{dislikes}</span>
					</div>
				</div>

				<div class="mt-2 border-t pt-4">
					<div class="ml-1 mb-2">
						<span class="block font-semibold text-gray-800">{translateFunction('evidences')}</span>
					</div>
					<div class="flex flex-wrap justify-between overflow-y-auto max-h-[45vh]">
						{#if attachments.length != 0}
							{#each attachments as url}
								<div class="w-1/2 p-0.5">
									<div class="border border-gray-200 rounded">
										{#if getMediaType(url.file_type) === 'video'}
											<!-- svelte-ignore a11y-media-has-caption -->
											<video
												on:click={(event) => {
													event.preventDefault();
													openModal(url);
												}}
												class="rounded"
												controls
												bind:this={videoElement}
											>
												<source src={PUBLIC_API_URL + '/' + url.file_path} type={url.file_type} />
												Your browser does not support the video tag.
											</video>
										{:else if getMediaType(url.file_type) === 'image'}
											<!-- svelte-ignore a11y-no-noninteractive-element-interactions -->
											<!-- svelte-ignore a11y-click-events-have-key-events -->
											<img
												on:click={() => openModal(url)}
												class="rounded"
												src={PUBLIC_API_URL + '/' + url.file_path}
												alt="Attachment"
											/>
										{:else if getMediaType(url.file_type) === 'audio'}
											<audio
												src={PUBLIC_API_URL + '/' + url.file_path}
												on:click={() => openModal(url)}
												controls
											>
												Your browser does not support the audio element.
											</audio>
										{:else}
											<div class="p-2 flex justify-center items-center mx-auto">
												<svg
													class="w-12 h-12 text-gray-800"
													aria-hidden="true"
													xmlns="http://www.w3.org/2000/svg"
													width="24"
													height="24"
													fill="currentColor"
													viewBox="0 0 24 24"
												>
													<path
														fill-rule="evenodd"
														d="M9 2.221V7H4.221a2 2 0 0 1 .365-.5L8.5 2.586A2 2 0 0 1 9 2.22ZM11 2v5a2 2 0 0 1-2 2H4v11a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V4a2 2 0 0 0-2-2h-7Z"
														clip-rule="evenodd"
													/>
												</svg>
											</div>
										{/if}

										<div class="my-1 text-sm text-center text-gray-600 text-wrap break-words">
											{getFileName(url.file_path)}
										</div>
									</div>
								</div>
							{/each}
						{:else}
							<span class="text-sm ml-1">no evidences uploaded</span>
						{/if}
					</div>
				</div>

				<div
					class="text-white leading-snug md:leading-normal p-1 rounded-md text-center m-4 mb-0 mx-20"
					class:bg-orange-500={complaint.status === 'processing'}
					class:bg-green-500={complaint.status === 'solved'}
					class:bg-red-500={complaint.status === 'rejected'}
					class:bg-indigo-500={complaint.status === 'pending'}
				>
					{translateFunction(complaint.status.toLocaleLowerCase())}
				</div>

				{#if $roleId === 'user'}
					{#if !$lawyerMode}
						<div class="flex flex-row items-end justify-center my-4 hidden">
							<button
								on:click={() => {
									goto('/lawyer/list');
								}}
								class="bg-green-500 hover:bg-green-700 transition text-white border-none rounded-md px-6 py-2"
							>
								Do you want to assign a lawyer?
							</button>
						</div>
					{/if}
				{/if}

				{#if $roleId !== 'user'}
					<div class="mt-2 border-t pt-4">
						<div class="flex flex-row items-end justify-center">
							{#if $roleId === 'admin'}
								<!-- Solved button -->
								<button
									on:click={handleUpdateStatus(complaint.complaint_id, 'solved')}
									class="bg-green-500 hover:bg-green-700 transition text-white border-none rounded-md px-6 py-2"
								>
									{#if $isSolved}
										{translateFunction('solved')}
									{:else}
										{translateFunction('mark_as_solved')}
									{/if}
								</button>
							{/if}

							<!-- Accept and Reject buttons -->

							{#if $roleId === 'regulatory'}
								<div class="flex space-x-4">
									<button
										on:click={handleUpdateStatus(complaint.complaint_id, 'processing')}
										class="bg-blue-500 hover:bg-blue-700 transition text-white border-none rounded-md px-6 py-2"
									>
										{translateFunction('accept')}
									</button>

									<button
										on:click={handleUpdateStatus(complaint.complaint_id, 'rejected')}
										class="bg-red-500 hover:bg-red-700 transition text-white border-none rounded-md px-6 py-2"
									>
										{translateFunction('reject')}
									</button>
								</div>
							{/if}
						</div>
					</div>
				{/if}

				<div
					class="mt-6"
					class:hidden={$comments.trim() === '' && $roleId === 'user'}
					class:block={$comments.trim() !== '' || $roleId !== 'user'}
				>
					<div class="mb-2">
						<label for="comments" class="mt-3 mb-2 block text-base font-semibold text-[#07074D]">
							{translateFunction('comments')}
						</label>
						{#if $roleId === 'user'}
							<textarea
								readonly
								name="comments"
								id="comments"
								bind:value={$comments}
								rows="3"
								class="w-full rounded-md transition border border-[#e0e0e0] bg-white p-2 text-base text-[#6B7280]"
							></textarea>
						{:else}
							<textarea
								name="comments"
								id="comments"
								on:keypress={handleKeyPress}
								bind:value={$comments}
								rows="3"
								class="w-full rounded-md transition border border-[#e0e0e0] bg-white p-2 text-base text-[#6B7280]"
							></textarea>
						{/if}
					</div>
				</div>

				{#if $isSolved}
					<div class="p-4 bg-white rounded-md flex flex-col items-center justify-center">
						<div class="mb-2">
							<label for="comments" class="mt-3 mb-2 block text-xl font-medium text-[#07074D]">
								{#if $langCode === 'en'}
									How satisfied are you?
								{:else}
									আপনি কতটা সন্তুষ্ট?
								{/if}
							</label>
						</div>

						<div class="flex items-center">
							<svg
								class="w-8 h-8 ms-3 text-gray-300"
								on:click={() => upsertFeedback(1)}
								class:text-yellow-300={$feedbackLevel >= 1}
								aria-hidden="true"
								xmlns="http://www.w3.org/2000/svg"
								fill="currentColor"
								viewBox="0 0 22 20"
							>
								<path
									d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
								/>
							</svg>
							<svg
								class="w-8 h-8 ms-3 text-gray-300"
								on:click={() => upsertFeedback(2)}
								class:text-yellow-300={$feedbackLevel >= 2}
								aria-hidden="true"
								xmlns="http://www.w3.org/2000/svg"
								fill="currentColor"
								viewBox="0 0 22 20"
							>
								<path
									d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
								/>
							</svg>
							<svg
								class="w-8 h-8 ms-3 text-gray-300"
								on:click={() => upsertFeedback(3)}
								class:text-yellow-300={$feedbackLevel >= 3}
								aria-hidden="true"
								xmlns="http://www.w3.org/2000/svg"
								fill="currentColor"
								viewBox="0 0 22 20"
							>
								<path
									d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
								/>
							</svg>
							<svg
								class="w-8 h-8 ms-3 text-gray-300"
								on:click={() => upsertFeedback(4)}
								class:text-yellow-300={$feedbackLevel >= 4}
								aria-hidden="true"
								xmlns="http://www.w3.org/2000/svg"
								fill="currentColor"
								viewBox="0 0 22 20"
							>
								<path
									d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
								/>
							</svg>
							<svg
								class="w-8 h-8 ms-3 text-gray-300"
								on:click={() => upsertFeedback(5)}
								class:text-yellow-300={$feedbackLevel >= 5}
								aria-hidden="true"
								xmlns="http://www.w3.org/2000/svg"
								fill="currentColor"
								viewBox="0 0 22 20"
							>
								<path
									d="M20.924 7.625a1.523 1.523 0 0 0-1.238-1.044l-5.051-.734-2.259-4.577a1.534 1.534 0 0 0-2.752 0L7.365 5.847l-5.051.734A1.535 1.535 0 0 0 1.463 9.2l3.656 3.563-.863 5.031a1.532 1.532 0 0 0 2.226 1.616L11 17.033l4.518 2.375a1.534 1.534 0 0 0 2.226-1.617l-.863-5.03L20.537 9.2a1.523 1.523 0 0 0 .387-1.575Z"
								/>
							</svg>
						</div>
					</div>
				{/if}
			</div>
		</div>
	</div>
{/if}

{#if modalOpen}
	<div class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
		<div class="bg-gray-100 p-0.5 rounded shadow-lg relative max-w-3xl z-40">
			<!-- Lower z-index for modal -->
			<button
				class="absolute top-0 right-0 px-2 py-0 m-1 text-white bg-red-500 hover:bg-red-400 rounded-full z-50"
				on:click={closeModal}
			>
				&times;
			</button>

			{#if mediaType === 'image'}
				<img class="max-w-full max-h-[80vh] rounded" src={selectedMedia} alt="Large View" />
			{:else if mediaType === 'video'}
				<video class="max-w-full max-h-[80vh] rounded" src={selectedMedia} controls autoplay />
			{:else if mediaType == 'audio'}
				<audio class="w-full" src={selectedMedia} controls autoplay>
					Your browser does not support the audio element.
				</audio>
			{/if}
		</div>
	</div>
{/if}
