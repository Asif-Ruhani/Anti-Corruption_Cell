<script lang="ts">
	import { goto } from '$app/navigation';
	import { PUBLIC_API_URL } from '$env/static/public';
	import LoginForm from '$lib/components/LoginForm.svelte';
	import { translate } from '$lib/translate';
	import { onDestroy } from 'svelte';

	let translateFunction = (key: string) => key;
	const unsubscribe = translate.subscribe((fn) => {
		translateFunction = fn;
	});

	onDestroy(() => {
		unsubscribe();
	});

	let username: string = '';
	let password: string = '';
	let passwordInput: HTMLInputElement;

	const isGeneralUser: boolean = false;
	let message: string;
	let error: string;

	const handleSubmit = async () => {
		if (username === 'lawyerdemo') {
			goto('/lawyer/dashboard');
			localStorage.setItem('lawyer_mode', 'user');
			return;
		}
		try {
			let response;
			const requestBody = { username: username, password: password };

			response = await fetch(
				`${PUBLIC_API_URL}/users/login/admin?username=${username}&password=${password}`,
				{
					method: 'POST',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify(requestBody)
				}
			);

			if (!response.ok) {
				error = 'Login failed. Please check your credentials or try again later.';
			}

			return response;
		} catch (err) {
			console.error('Error:', err);
			error = 'Network error. Please try again later.';
			throw err;
		}
	};

	let showPassword = false;
	function togglePassword() {
		showPassword = !showPassword;
		passwordInput.type = showPassword ? 'text' : 'password';
	}
</script>

<svelte:head>
	<title>{translateFunction('auth.login')} • ACC</title>
</svelte:head>

<LoginForm {handleSubmit} {message} {error} {isGeneralUser}>
	<div class="mb-4">
		<label for="username" class="mb-2 block text-sm font-semibold text-gray-700"
			>{translateFunction('auth.username')} *</label
		>
		<input
			type="text"
			id="username"
			bind:value={username}
			class="form-input w-full rounded-lg border px-4 py-2 text-gray-700 focus:ring-blue-500"
			required
		/>
	</div>

	<div class="mb-6">
		<label for="password" class="block text-gray-700 text-sm font-semibold mb-2"
			>{translateFunction('auth.password')} *</label
		>
		<div class="flex items-center">
			<input
				bind:this={passwordInput}
				type="password"
				id="password"
				bind:value={password}
				class="form-input w-full px-4 py-2 border rounded-lg text-gray-700 focus:ring-blue-500"
				required
				placeholder="*******"
			/>
			<button
				type="button"
				id="togglePassword"
				class="focus:outline-none -ml-8"
				on:click={togglePassword}
			>
				<img
					src={showPassword ? '/images/eye.png' : '/images/hidden.png'}
					alt="Toggle Password Visibility"
					class="w-4"
				/>
			</button>
		</div>
	</div>
</LoginForm>
