import { redirect, type RequestEvent } from '@sveltejs/kit';
import { loginUser, signUpUser } from '$lib/authService';

export const actions = {
	default: async ({ request, locals }: RequestEvent) => {
		const data = await request.formData();
		const email = data.get('email') as string;
		const password = data.get('password') as string;
		const confirmPassword = data.get('confirmPassword') as string;
		const isSignUp = data.get('isSignUp') === 'true';

		if (isSignUp) {
			const result = await signUpUser({ email, password, confirmPassword });
			if (result.success) {
				// locals.user = result.user;
				throw redirect(303, '/'); // Redirect to homepage or user-specific page
			}
			return { success: false, message: result.message };
		} else {
			const result = await loginUser({ email, password });
			if (result.success) {
				// locals.user = result.user;
				throw redirect(303, '/');
			}
			return { success: false, message: result.message };
		}
	}
};
