import { json, error as serverError } from '@sveltejs/kit';

export const POST = async ({ request }) => {
	try {
		const data = await request.json();
		const username = data.username;

		return json({ message: `User ${username} successfully submitted!` });
	} catch (err) {
		console.error(err);
		throw serverError(500, 'Failed to process the request');
	}
};
