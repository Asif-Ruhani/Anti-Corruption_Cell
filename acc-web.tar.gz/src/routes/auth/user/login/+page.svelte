<!-- <script lang="ts">
	import { translate } from '$lib/translate';
	import { onDestroy } from 'svelte';
	import { writable } from 'svelte/store';
	import { isLoggedIn } from '../../../../stores/auth';
	import { PUBLIC_API_URL } from '$env/static/public';

	let translateFunction = (key: string) => key;
	const unsubscribe = translate.subscribe((fn) => {
		translateFunction = fn;
	});

	onDestroy(() => {
		unsubscribe();
	});

	const showVerifyBtn = writable(false);

	const showNidForm = writable(false);
	const showBregForm = writable(false);

	const showOTP = writable(false);

	let nid_number: string = '';
	let otp_number: string = '';
	let phone_number: string = '';
	let bregNum: string = '';
	let dob: string = '';

	let message: string = '';
	let error: string = '';

	function toggleShowNidForm() {
		showNidForm.set(!$showNidForm);
		showBregForm.set(false);
		showVerifyBtn.set(!$showVerifyBtn);
	}

	function toggleShowBregForm() {
		showBregForm.set(!$showBregForm);
		showNidForm.set(false);
		showVerifyBtn.set(!$showVerifyBtn);
	}

	function setUserDataToLocalStorage(data) {
		localStorage.setItem('user_logged_in', 'true');
		localStorage.setItem('user_id', data.user_id);
		localStorage.setItem('role_id', data.role_id);
	}

	function clearUserDataFromLocalStorage() {
		localStorage.removeItem('user_logged_in');
		localStorage.removeItem('role_id');
		localStorage.removeItem('user_id');
	}

	const handleOTPSubmit = async () => {
		let verificationResponse = await fetch(`${PUBLIC_API_URL}/auth/verify-otp?otp=${otp_number}`, {
			method: 'GET',
			credentials: 'include'
		});

		if (verificationResponse.ok) {
			return verificationResponse;
		} else {
			const json = await verificationResponse.json();
			error = json.details;
		}
	};

	const handleSubmit = async () => {
		try {
			let verificationResponse;
			const requestBody = $showBregForm
				? { bregNum: bregNum, dob: dob, isNid: false }
				: { nid: nid_number, phone_num: phone_number, isNid: true };

			// verifying unique IDs
			if (requestBody.isNid) {
				verificationResponse = await fetch(`${PUBLIC_API_URL}/auth/nid/login`, {
					method: 'POST',
					credentials: 'include',
					headers: {
						Accept: 'application/json',
						'Content-Type': 'application/json'
					},
					body: JSON.stringify({
						nid: nid_number,
						phone_number: phone_number
					})
				});
			} else {
				verificationResponse = await fetch(`${PUBLIC_API_URL}/auth/brn/login`, {
					method: 'POST',
					headers: {
						Accept: 'application/json',
						'Content-Type': 'application/json'
					},
					body: JSON.stringify({
						brn: bregNum,
						dob: dob
					})
				});
			}

			if (verificationResponse.ok) {
				error = '';
				showOTP.set(true);
			} else {
				error = 'Verification failed.';
			}

			return verificationResponse;
		} catch (err) {
			console.error('Error:', err);
			error = 'Network error. Please try again later.';
			throw err;
		}
	};

	let loading: boolean;

	async function handleResponse(response: Response) {
		if (response.ok) {
			const data = await response.json();
			setUserDataToLocalStorage(data);

			isLoggedIn.set(true);
			window.location.href = '/dashboard';
			message = 'Success!';
			error = '';
		} else {
			isLoggedIn.set(false);
			clearUserDataFromLocalStorage();

			const errorData = await response.json().catch(() => ({ detail: 'An error occurred' }));
			error = errorData.detail;

			message = '';
		}
	}

	async function submitHandler() {
		try {
			loading = true;
			if ($showOTP) {
				const otp_resp = await handleOTPSubmit();
				await handleResponse(otp_resp);
			} else {
				await handleSubmit();
			}
		} catch (exception) {
			console.error(exception);
		} finally {
			loading = false;
		}
	}
</script>

<svelte:head>
	<title>{translateFunction('auth.login')} • ACC</title>
</svelte:head>

<div
	class="auth-login mt-2 flex items-center justify-center bg-gray-50"
	class:md:mt-32={!$showNidForm && !$showBregForm}
	class:md:mt-10={$showNidForm && !$showBregForm}
	class:md:mt-20={!$showNidForm && $showBregForm}
>
	<div class="w-full max-w-sm rounded-lg bg-white p-8 shadow-lg">
		<div class="mb-6 flex justify-center">
			<span class="inline-block rounded-full bg-gray-200 p-2">
				<svg
					class="h-16 w-16 text-gray-800"
					aria-hidden="true"
					xmlns="http://www.w3.org/2000/svg"
					width="48"
					height="48"
					fill="currentColor"
					viewBox="0 0 24 24"
				>
					<path
						fill-rule="evenodd"
						d="M12 20a7.966 7.966 0 0 1-5.002-1.756l.002.001v-.683c0-1.794 1.492-3.25 3.333-3.25h3.334c1.84 0 3.333 1.456 3.333 3.25v.683A7.966 7.966 0 0 1 12 20ZM2 12C2 6.477 6.477 2 12 2s10 4.477 10 10c0 5.5-4.44 9.963-9.932 10h-.138C6.438 21.962 2 17.5 2 12Zm10-5c-1.84 0-3.333 1.455-3.333 3.25S10.159 13.5 12 13.5c1.84 0 3.333-1.455 3.333-3.25S13.841 7 12 7Z"
						clip-rule="evenodd"
					/>
				</svg>
			</span>
		</div>
		<h1 class="mb-6 text-center font-semibold">
			{translateFunction('auth.user.provide_login_info')}
		</h1>
		<form on:submit|preventDefault={submitHandler}>
			<slot></slot>

			<div class="border-t">
				<div class="mt-6 mb-4 w-full bg-orange-200 p-1 rounded-md">
					<div class="font-semibold p-1">
						{translateFunction('identity_choose_msg')}
					</div>
				</div>
				<div class="flex items-center justify-center mb-4">
					<button
						on:click={toggleShowNidForm}
						type="button"
						class:bg-green-200={$showNidForm}
						class:hover:bg-green-300={$showNidForm}
						class:bg-gray-200={!$showNidForm}
						class:hover:bg-gray-300={!$showNidForm}
						class="flex w-full items-center justify-center rounded-lg px-4 py-2 text-black focus:outline-none transition"
					>
						<span class="ml-2">
							{translateFunction('national_id')}
						</span>
					</button>
				</div>
				<div class="flex items-center justify-center">
					<button
						on:click={toggleShowBregForm}
						type="button"
						class:bg-green-200={$showBregForm}
						class:hover:bg-green-300={$showBregForm}
						class:bg-gray-200={!$showBregForm}
						class:hover:bg-gray-300={!$showBregForm}
						class="flex w-full items-center justify-center rounded-lg px-4 py-2 text-black focus:outline-none transition"
					>
						<span class="ml-2">
							{translateFunction('birth_reg_cert')}
						</span>
					</button>
				</div>
			</div>

			{#if $showBregForm}
				<div class="mt-6 mb-4 w-full bg-orange-200 p-1 rounded-md">
					<div class="font-semibold p-1">{translateFunction('fill_form')}</div>
				</div>
				<div class="mb-4">
					<label for="bregNum" class="mb-2 block text-sm font-semibold text-gray-700"
						>{translateFunction('auth.birth_reg_num')} *</label
					>
					<input
						bind:value={bregNum}
						type="text"
						id="bregNum"
						class="form-input w-full rounded-lg border px-4 py-2 text-gray-700 focus:ring-blue-500"
						required
						maxlength="17"
						minlength="17"
						placeholder="201737459203847562"
					/>
				</div>
				<div class="mb-6">
					<label for="dob" class="mb-2 block text-sm font-semibold text-gray-700"
						>{translateFunction('auth.birthday')} *</label
					>
					<input
						bind:value={dob}
						type="date"
						id="dob"
						class="form-input w-full rounded-lg border px-4 py-2 text-gray-700 focus:ring-blue-500"
						required
						min="1924-12-31"
						max="2024-12-31"
					/>
				</div>
			{/if}

			{#if $showNidForm}
				<div class="mt-6 mb-4 w-full bg-orange-200 p-1 rounded-md">
					<div class="font-semibold p-1">{translateFunction('fill_form')}</div>
				</div>
				{#if $showOTP}
					<div class="mb-6">
						<label for="otp_number" class="mb-2 block text-sm font-semibold text-gray-700"
							>{translateFunction('auth.otp_number')} *</label
						>
						<input
							bind:value={otp_number}
							type="text"
							id="otp_number"
							class="form-input w-full rounded-lg border px-4 py-2 text-gray-700 focus:ring-blue-500"
							placeholder="123456"
						/>
						<p class="mt-1 text-xs text-gray-600">
							{translateFunction('auth.otp_number_msg')}
						</p>
					</div>
				{:else}
					<div class="mb-2.5">
						<label for="nid_number" class="mb-2 block text-sm font-semibold text-gray-700"
							>{translateFunction('auth.nid_number')} *</label
						>
						<input
							bind:value={nid_number}
							type="text"
							id="nid_number"
							class="form-input w-full rounded-lg border px-4 py-2 text-gray-700 focus:ring-blue-500"
							required
							placeholder="8002014992"
						/>
					</div>
					<div class="mb-2.5">
						<label for="phone_number" class="mb-2 block text-sm font-semibold text-gray-700"
							>{translateFunction('auth.phone_number')} *</label
						>
						<input
							bind:value={phone_number}
							type="text"
							id="phone_number"
							class="form-input w-full rounded-lg border px-4 py-2 text-gray-700 focus:ring-blue-500"
							required
							maxlength="11"
							minlength="11"
							placeholder="01289102235"
						/>
						<p class="mt-1 text-xs text-gray-600">
							{translateFunction('auth.phone_number_requirement')}
						</p>
					</div>
				{/if}
			{/if}

			{#if $showBregForm || $showNidForm}
				<div class="flex items-center justify-center mt-4">
					<button
						type="submit"
						class="flex w-full items-center justify-center rounded-lg bg-blue-500 px-4 py-2 text-white hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50"
					>
						<svg
							class:block={loading}
							class:hidden={!loading}
							class="h-5 w-5 animate-spin text-white"
							xmlns="http://www.w3.org/2000/svg"
							fill="none"
							viewBox="0 0 24 24"
						>
							<circle
								class="opacity-25"
								cx="12"
								cy="12"
								r="10"
								stroke="currentColor"
								stroke-width="4"
							></circle>
							<path
								class="opacity-75"
								fill="currentColor"
								d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
							></path>
						</svg>
						<span class="ml-2">
							{#if $showOTP}
								{translateFunction('auth.login')}
							{:else}
								{translateFunction('auth.verify')}
							{/if}
						</span>
					</button>
				</div>

				<div class="mb-4 flex space-x-4 p-1 bg-white rounded-lg shadow-md pt-4">
					<div
						class="flex flex-row w-full bg-green-600 rounded-md text-white items-center justify-center"
						class:bg-green-600={message.trim() !== ''}
						class:bg-red-600={error.trim() !== ''}
					>
						{#if message}
							<svg
								xmlns="http://www.w3.org/2000/svg"
								fill="none"
								viewBox="0 0 24 24"
								stroke-width="1.5"
								stroke="currentColor"
								class="size-6"
							>
								<path
									stroke-linecap="round"
									stroke-linejoin="round"
									d="M9 12.75 11.25 15 15 9.75m-3-7.036A11.959 11.959 0 0 1 3.598 6 11.99 11.99 0 0 0 3 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285Z"
								/>
							</svg>
							<span class="p-2">{translateFunction('verified_success_msg')}</span>
						{/if}

						{#if error}
							<svg
								xmlns="http://www.w3.org/2000/svg"
								fill="none"
								viewBox="0 0 24 24"
								stroke-width="1.5"
								stroke="currentColor"
								class="size-6"
							>
								<path
									stroke-linecap="round"
									stroke-linejoin="round"
									d="M12 9v3.75m0-10.036A11.959 11.959 0 0 1 3.598 6 11.99 11.99 0 0 0 3 9.75c0 5.592 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.57-.598-3.75h-.152c-3.196 0-6.1-1.25-8.25-3.286Zm0 13.036h.008v.008H12v-.008Z"
								/>
							</svg>
							<span class="p-2">{error}</span>
						{/if}
					</div>
				</div>
			{/if}
		</form>
	</div>
</div> -->

<script lang="ts">
	import { translate } from '$lib/translate';
	import { onDestroy } from 'svelte';
	import { writable } from 'svelte/store';
	import { isLoggedIn } from '../../../../stores/auth';
	import { PUBLIC_API_URL } from '$env/static/public';

	let translateFunction = (key: string) => key;
	const unsubscribe = translate.subscribe((fn) => {
		translateFunction = fn;
	});

	onDestroy(() => {
		unsubscribe();
	});

	const showVerifyBtn = writable(false);

	const showNidForm = writable(false);
	const showBregForm = writable(false);

	const showOTP = writable(false);

	let nid_number: string = '';
	let otp_number: string = '';
	let phone_number: string = '';
	let bregNum: string = '';
	let dob: string = '';

	let message: string = '';
	let error: string = '';

	function toggleShowNidForm() {
		showNidForm.set(!$showNidForm);
		showBregForm.set(false);
		showVerifyBtn.set(!$showVerifyBtn);
	}

	function toggleShowBregForm() {
		showBregForm.set(!$showBregForm);
		showNidForm.set(false);
		showVerifyBtn.set(!$showVerifyBtn);
	}

	function setUserDataToLocalStorage(data) {
		localStorage.setItem('user_logged_in', 'true');
		localStorage.setItem('user_id', data.user_id);
		localStorage.setItem('role_id', data.role_id);
	}

	function clearUserDataFromLocalStorage() {
		localStorage.removeItem('user_logged_in');
		localStorage.removeItem('role_id');
		localStorage.removeItem('user_id');
	}

	const handleVerifySubmit = async () => {
		try {
			let verificationResponse;
			const requestBody = $showBregForm
				? { bregNum: bregNum, dob: dob, isNid: false }
				: { nid: nid_number, phone_num: phone_number, isNid: true };

			// verifying unique IDs
			if (requestBody.isNid) {
				verificationResponse = await fetch(
					`${PUBLIC_API_URL}/users/verify/nid?nid=${nid_number}&phone_num=${phone_number}`,
					{
						method: 'GET',
						headers: { Accept: 'application/json' }
					}
				);
			} else {
				verificationResponse = await fetch(
					`${PUBLIC_API_URL}/users/verify/breg?breg_num=${bregNum}&dob=${dob}`,
					{
						method: 'GET',
						headers: { Accept: 'application/json' }
					}
				);
			}

			if (!verificationResponse.ok) {
				error = 'Verification failed.';
			} else {
				verificationResponse = await fetch(`${PUBLIC_API_URL}/users/otp/send`, {
					method: 'GET',
					credentials: 'include',
					headers: { Accept: 'application/json' }
				});

				if (verificationResponse.ok) {
					showOTP.set(true);
				} else {
					error = 'Failed to send OTP.';
				}
			}

			return verificationResponse;
		} catch (err) {
			console.error('Error:', err);
			error = 'Network error. Please try again later.';
			throw err;
		}
	};

	const handleOtpSubmit = async () => {
		try {
			let response;
			const requestBody = $showBregForm
				? { bregNum: bregNum, dob: dob, isNid: false }
				: { nid: nid_number, phone_num: phone_number, isNid: true };

			let verificationResponse = await fetch(
				`${PUBLIC_API_URL}/users/otp/verify?rial_code=${otp_number}`,
				{
					method: 'POST',
					credentials: 'include',
					headers: {
						Accept: 'application/json',
						'Content-Type': 'application/json'
					}
				}
			);

			if (!verificationResponse.ok) {
				error = 'Invalid OTP.';
			} else {
				response = await fetch(`${PUBLIC_API_URL}/users/getId?nid_num=${nid_number}`, {
					method: 'GET',
					headers: { 'Content-Type': 'application/json' },
				});

				// user not registered
				if (!response.ok) {
					// error = 'Login failed. Please try again later.';
					const requestBdy = {
						nid: nid_number,
						role_id: 'user',
						status: 'active',
						joint_at: new Date().toISOString()
					};
					response = await fetch(`${PUBLIC_API_URL}/users/create`, {
						method: 'POST',
						headers: {
							'Content-Type': 'application/json'
						},
						body: JSON.stringify(requestBdy)
					});
				} else {
					response = await fetch(`${PUBLIC_API_URL}/users/login`, {
						method: 'POST',
						headers: {
							'Content-Type': 'application/json'
						},
						body: JSON.stringify(requestBody)
					});
				}
				return response;
			}
		} catch (err) {
			console.error('Error:', err);
			error = 'Network error. Please try again later.';
			throw err;
		}
	};

	let loading: boolean;

	async function handleResponse(response: Response) {
		if (response.ok) {
			const data = await response.json();
			setUserDataToLocalStorage(data);

			isLoggedIn.set(true);
			window.location.href = '/dashboard';
			message = 'Success!';
			error = '';
		} else {
			isLoggedIn.set(false);
			clearUserDataFromLocalStorage();

			const errorData = await response.json().catch(() => ({ detail: 'An error occurred' }));
			error = errorData.detail;

			message = '';
		}
	}

	async function submitHandler() {
		try {
			loading = true;

			if ($showBregForm) {
				const response = await handleVerifySubmit();
				await handleResponse(response);
			} else {
				if ($showOTP) {
					const response = await handleOtpSubmit();
					await handleResponse(response);
				} else {
					await handleVerifySubmit();
				}
			}
		} catch (exception) {
			console.error(exception);
		} finally {
			loading = false;
		}
	}
</script>

<svelte:head>
	<title>{translateFunction('auth.login')} • ACC</title>
</svelte:head>

<div
	class="auth-login mt-2 flex items-center justify-center bg-gray-50"
	class:md:mt-32={!$showNidForm && !$showBregForm}
	class:md:mt-10={$showNidForm && !$showBregForm}
	class:md:mt-20={!$showNidForm && $showBregForm}
>
	<div class="w-full max-w-sm rounded-lg bg-white p-8 shadow-lg">
		<div class="mb-6 flex justify-center">
			<span class="inline-block rounded-full bg-gray-200 p-2">
				<svg
					class="h-16 w-16 text-gray-800"
					aria-hidden="true"
					xmlns="http://www.w3.org/2000/svg"
					width="48"
					height="48"
					fill="currentColor"
					viewBox="0 0 24 24"
				>
					<path
						fill-rule="evenodd"
						d="M12 20a7.966 7.966 0 0 1-5.002-1.756l.002.001v-.683c0-1.794 1.492-3.25 3.333-3.25h3.334c1.84 0 3.333 1.456 3.333 3.25v.683A7.966 7.966 0 0 1 12 20ZM2 12C2 6.477 6.477 2 12 2s10 4.477 10 10c0 5.5-4.44 9.963-9.932 10h-.138C6.438 21.962 2 17.5 2 12Zm10-5c-1.84 0-3.333 1.455-3.333 3.25S10.159 13.5 12 13.5c1.84 0 3.333-1.455 3.333-3.25S13.841 7 12 7Z"
						clip-rule="evenodd"
					/>
				</svg>
			</span>
		</div>
		<h1 class="mb-6 text-center font-semibold">
			{translateFunction('auth.user.provide_login_info')}
		</h1>
		<form on:submit|preventDefault={submitHandler}>
			<slot></slot>

			<div class="border-t">
				<div class="mt-6 mb-4 w-full bg-orange-200 p-1 rounded-md">
					<div class="font-semibold p-1">
						{translateFunction('identity_choose_msg')}
					</div>
				</div>
				<div class="flex items-center justify-center mb-4">
					<button
						on:click={toggleShowNidForm}
						type="button"
						class:bg-green-200={$showNidForm}
						class:hover:bg-green-300={$showNidForm}
						class:bg-gray-200={!$showNidForm}
						class:hover:bg-gray-300={!$showNidForm}
						class="flex w-full items-center justify-center rounded-lg px-4 py-2 text-black focus:outline-none transition"
					>
						<span class="ml-2">
							{translateFunction('national_id')}
						</span>
					</button>
				</div>
				<div class="flex items-center justify-center">
					<button
						on:click={toggleShowBregForm}
						type="button"
						class:bg-green-200={$showBregForm}
						class:hover:bg-green-300={$showBregForm}
						class:bg-gray-200={!$showBregForm}
						class:hover:bg-gray-300={!$showBregForm}
						class="flex w-full items-center justify-center rounded-lg px-4 py-2 text-black focus:outline-none transition"
					>
						<span class="ml-2">
							{translateFunction('birth_reg_cert')}
						</span>
					</button>
				</div>
			</div>

			{#if $showBregForm}
				<div class="mt-6 mb-4 w-full bg-orange-200 p-1 rounded-md">
					<div class="font-semibold p-1">{translateFunction('fill_form')}</div>
				</div>
				<div class="mb-4">
					<label for="bregNum" class="mb-2 block text-sm font-semibold text-gray-700"
						>{translateFunction('auth.birth_reg_num')} *</label
					>
					<input
						bind:value={bregNum}
						type="text"
						id="bregNum"
						class="form-input w-full rounded-lg border px-4 py-2 text-gray-700 focus:ring-blue-500"
						required
						maxlength="17"
						minlength="17"
						placeholder="201737459203847562"
					/>
				</div>
				<div class="mb-6">
					<label for="dob" class="mb-2 block text-sm font-semibold text-gray-700"
						>{translateFunction('auth.birthday')} *</label
					>
					<input
						bind:value={dob}
						type="date"
						id="dob"
						class="form-input w-full rounded-lg border px-4 py-2 text-gray-700 focus:ring-blue-500"
						required
						min="1924-12-31"
						max="2024-12-31"
					/>
				</div>
			{/if}

			{#if $showNidForm}
				<div class="mt-6 mb-4 w-full bg-orange-200 p-1 rounded-md">
					<div class="font-semibold p-1">{translateFunction('fill_form')}</div>
				</div>

				{#if $showOTP != true}
					<div class="mb-2.5">
						<label for="nid_number" class="mb-2 block text-sm font-semibold text-gray-700"
							>{translateFunction('auth.nid_number')} *</label
						>
						<input
							bind:value={nid_number}
							type="text"
							id="nid_number"
							class="form-input w-full rounded-lg border px-4 py-2 text-gray-700 focus:ring-blue-500"
							required
							placeholder="8002014992"
						/>
					</div>
					<div class="mb-2.5">
						<label for="phone_number" class="mb-2 block text-sm font-semibold text-gray-700"
							>{translateFunction('auth.phone_number')} *</label
						>
						<input
							bind:value={phone_number}
							type="text"
							id="phone_number"
							class="form-input w-full rounded-lg border px-4 py-2 text-gray-700 focus:ring-blue-500"
							required
							maxlength="11"
							minlength="11"
							placeholder="01289102235"
						/>
						<p class="mt-1 text-xs text-gray-600">
							{translateFunction('auth.phone_number_requirement')}
						</p>
					</div>
				{:else}
					<div class="mb-2.5">
						<label for="otp_number" class="mb-2 block text-sm font-semibold text-gray-700"
							>{translateFunction('auth.otp_number')} *</label
						>
						<input
							bind:value={otp_number}
							type="text"
							id="otp_number"
							class="form-input w-full rounded-lg border px-4 py-2 text-gray-700 focus:ring-blue-500"
							placeholder="123456"
						/>
						<p class="mt-1 text-xs text-gray-600">
							{translateFunction('auth.otp_number_msg')}
						</p>
					</div>
				{/if}
			{/if}

			{#if $showBregForm || $showNidForm}
				<div class="flex items-center justify-center mt-4">
					<button
						type="submit"
						class="flex w-full items-center justify-center rounded-lg bg-blue-500 px-4 py-2 text-white hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50"
					>
						<svg
							class:block={loading}
							class:hidden={!loading}
							class="h-5 w-5 animate-spin text-white"
							xmlns="http://www.w3.org/2000/svg"
							fill="none"
							viewBox="0 0 24 24"
						>
							<circle
								class="opacity-25"
								cx="12"
								cy="12"
								r="10"
								stroke="currentColor"
								stroke-width="4"
							></circle>
							<path
								class="opacity-75"
								fill="currentColor"
								d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
							></path>
						</svg>
						<span class="ml-2">
							{translateFunction('auth.login')}
						</span>
					</button>
				</div>

				<div class="mb-4 flex space-x-4 p-1 bg-white rounded-lg shadow-md pt-4">
					<div
						class="flex flex-row w-full bg-green-600 rounded-md text-white items-center justify-center"
						class:bg-green-600={message.trim() !== ''}
						class:bg-red-600={error.trim() !== ''}
					>
						{#if message}
							<svg
								xmlns="http://www.w3.org/2000/svg"
								fill="none"
								viewBox="0 0 24 24"
								stroke-width="1.5"
								stroke="currentColor"
								class="size-6"
							>
								<path
									stroke-linecap="round"
									stroke-linejoin="round"
									d="M9 12.75 11.25 15 15 9.75m-3-7.036A11.959 11.959 0 0 1 3.598 6 11.99 11.99 0 0 0 3 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285Z"
								/>
							</svg>
							<span class="p-2">{translateFunction('verified_success_msg')}</span>
						{/if}

						{#if error}
							<svg
								xmlns="http://www.w3.org/2000/svg"
								fill="none"
								viewBox="0 0 24 24"
								stroke-width="1.5"
								stroke="currentColor"
								class="size-6"
							>
								<path
									stroke-linecap="round"
									stroke-linejoin="round"
									d="M12 9v3.75m0-10.036A11.959 11.959 0 0 1 3.598 6 11.99 11.99 0 0 0 3 9.75c0 5.592 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.57-.598-3.75h-.152c-3.196 0-6.1-1.25-8.25-3.286Zm0 13.036h.008v.008H12v-.008Z"
								/>
							</svg>
							<span class="p-2">{error}</span>
						{/if}
					</div>
				</div>
			{/if}
		</form>
	</div>
</div>
