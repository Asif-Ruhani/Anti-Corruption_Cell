<script>
	import { goto } from '$app/navigation';
	import { PUBLIC_API_URL, PUBLIC_IS_MMH_MODE } from '$env/static/public';
	import { translate, langCode } from '$lib/translate';
	import { onDestroy, onMount } from 'svelte';

	let translateFunction = (key) => key;
	const unsubscribe = translate.subscribe((fn) => {
		translateFunction = fn;
	});

	onDestroy(() => {
		unsubscribe();
	});

	let total_user = '';
	let total_solved = '';
	let total_solved_users = '';

	onMount(async () => {
		const response = await fetch(`${PUBLIC_API_URL}/complaints/stats/all`);

		if (response.ok) {
			const jsn = await response.json();
			console.debug(jsn);
			total_user = jsn.users.total.toString() || '0';
			total_solved = jsn.complaints.solved || '0';
			total_solved_users = jsn.users.solved.toString() || '0';
		} else {
			console.error('Failed to load complaints');
		}
	});

	function translateEnNumToBnNum(text) {
		return text
			.replaceAll('1', '১')
			.replaceAll('2', '২')
			.replaceAll('3', '৩')
			.replaceAll('4', '৪')
			.replaceAll('5', '৫')
			.replaceAll('6', '৬')
			.replaceAll('7', '৭')
			.replaceAll('8', '৮')
			.replaceAll('9', '৯')
			.replaceAll('0', '০');
	}
</script>

<svelte:head>
	<title>Home • ACC</title>
</svelte:head>

<slot></slot>

<div
	class="h-[80vh] w-full flex flex-col justify-center items-center bg-[url('/images/corruption.jpg')] bg-cover bg-center"
>
	<div
		class="bg-black bg-opacity-50 w-full h-full flex flex-col justify-center items-center text-center px-4 md:px-12"
	>
		<h1 class="text-5xl font-bold text-white mb-4">"{translateFunction('homepage_slogan')}"</h1>
		<p class="text-xl text-white mb-4 bg-black rounded-md p-2 bg-opacity-60">
			{translateFunction('homepage_slogan_subtitle')}
		</p>
		{#if PUBLIC_IS_MMH_MODE === 'true'}
			<a
				on:click={() => {
					goto('/complaint-for-m');
				}}
				class="bg-yellow-500 text-black px-8 py-3 rounded-lg text-xl font-semibold hover:bg-yellow-400 transition duration-300"
			>
				{translateFunction('submit_complain')}
			</a>
		{:else}
			<a
				on:click={() => {
					goto('/auth/user/login');
				}}
				class="bg-yellow-500 text-black px-8 py-3 rounded-lg text-xl font-semibold hover:bg-yellow-400 transition duration-300"
			>
				{translateFunction('submit_complain')}
			</a>
		{/if}
	</div>
</div>

<div class="bg-gray-100 w-full pb-28">
	<div class="py-24 mx-auto max-w-screen-xl px-24 lg:px-8">
		<h2 class="text-center text-4xl font-bold tracking-tight text-gray-900 pb-14">
			{#if $langCode === 'en'}
				We are helping you with
			{:else}
				যে সকল সহায়তা পাবেন
			{/if}
		</h2>
		<div class="grid gap-16 lg:grid-cols-3">
			<div class="max-w-md sm:mx-auto sm:text-center">
				<div
					class="flex items-center justify-center w-28 h-28 mb-8 rounded-full bg-white mx-auto shadow-md shadow-md"
				>
					<svg
						xmlns="http://www.w3.org/2000/svg"
						fill="none"
						viewBox="0 0 24 24"
						stroke-width="1.5"
						stroke="currentColor"
						class="size-20 text-green-600"
					>
						<path
							stroke-linecap="round"
							stroke-linejoin="round"
							d="M17.982 18.725A7.488 7.488 0 0 0 12 15.75a7.488 7.488 0 0 0-5.982 2.975m11.963 0a9 9 0 1 0-11.963 0m11.963 0A8.966 8.966 0 0 1 12 21a8.966 8.966 0 0 1-5.982-2.275M15 9.75a3 3 0 1 1-6 0 3 3 0 0 1 6 0Z"
						/>
					</svg>
				</div>
				<h6 class="mb-3 text-2xl font-bold leading-5">
					{#if $langCode === 'en'}
						Anonymous Report
					{:else}
						বেনামে রিপোর্টিং
					{/if}
				</h6>
				<p class="mb-3 text-base text-gray-900">
					{#if $langCode === 'en'}
						Submit complaints without revealing your identity.
					{:else}
						পরিচয় প্রকাশ না করে অভিযোগ জমা দিন।
					{/if}
				</p>
			</div>
			<div class="max-w-md sm:mx-auto sm:text-center">
				<div
					class="flex items-center justify-center w-28 h-28 mb-8 rounded-full bg-white mx-auto shadow-md"
				>
					<svg
						xmlns="http://www.w3.org/2000/svg"
						fill="none"
						viewBox="0 0 24 24"
						stroke-width="1.5"
						stroke="currentColor"
						class="size-20 text-green-600"
					>
						<path
							stroke-linecap="round"
							stroke-linejoin="round"
							d="M12 6v6h4.5m4.5 0a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z"
						/>
					</svg>
				</div>
				<h6 class="mb-3 text-2xl font-bold leading-5">
					{#if $langCode === 'en'}
						Progress Tracking
					{:else}
						অগ্রগতি ট্র্যাকিং
					{/if}
				</h6>
				<p class="mb-3 text-base text-gray-900">
					{#if $langCode === 'en'}
						Monitor the status of your complaints in real-time.
					{:else}
						রিয়েল-টাইমে আপনার অভিযোগের অবস্থা পর্যবেক্ষণ করুন।
					{/if}
				</p>
			</div>

			<div class="max-w-md sm:mx-auto sm:text-center">
				<div
					class="flex items-center justify-center w-28 h-28 mb-8 rounded-full bg-white mx-auto shadow-md"
				>
					<svg
						xmlns="http://www.w3.org/2000/svg"
						fill="none"
						viewBox="0 0 24 24"
						stroke-width="1.5"
						stroke="currentColor"
						class="size-20 text-green-600"
					>
						<path
							stroke-linecap="round"
							stroke-linejoin="round"
							d="M9 12.75 11.25 15 15 9.75m-3-7.036A11.959 11.959 0 0 1 3.598 6 11.99 11.99 0 0 0 3 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285Z"
						/>
					</svg>
				</div>
				<h6 class="mb-3 text-2xl font-bold leading-5">
					{#if $langCode === 'en'}
						Data Privacy
					{:else}
						তথ্য গোপনীয়তা
					{/if}
				</h6>
				<p class="mb-3 text-base text-gray-900">
					{#if $langCode === 'en'}
						Guaranteed confidentiality of all personal and complaint details.
					{:else}
						সমস্ত ব্যক্তিগত এবং অভিযোগের বিবরণের গ্যারান্টিযুক্ত গোপনীয়তা।
					{/if}
				</p>
			</div>
		</div>
	</div>

	<div class="mx-auto lg:max-w-screen-xl">
		<h2 class="text-center text-5xl font-bold tracking-tight text-gray-900 sm:text-4xl pb-10">
			{#if $langCode === 'en'}
				We have so far
			{:else}
				এখন পর্যন্ত
			{/if}
		</h2>

		<div class="grid grid-cols-1 gap-20 sm:grid-cols-3 mt-4">
			<div class="bg-white overflow-hidden shadow sm:rounded-lg">
				<div class="px-10 py-8">
					<dl>
						<dt class="pt-2 text-xl leading-5 font-medium text-gray-800 truncate">
							{#if $langCode === 'en'}
								Solved
							{:else}
								সমাধান হয়েছে
							{/if}
						</dt>
						<dd class="mt-1 text-3xl leading-9 font-semibold text-green-600">
							{#if $langCode === 'en'}
								{total_solved}
							{:else}
								{translateEnNumToBnNum(total_solved)}
							{/if}
							<span class="text-base text-gray-800"
								>{#if $langCode === 'en'}
									complaints
								{:else}
									অভিযোগ
								{/if}</span
							>
						</dd>
					</dl>
				</div>
			</div>
			<div class="bg-white overflow-hidden shadow sm:rounded-lg">
				<div class="px-10 py-8">
					<dl>
						<dt class="pt-2 text-xl leading-5 font-medium text-gray-800 truncate">
							{#if $langCode === 'en'}
								Helped
							{:else}
								সাহায্য পেয়েছেন
							{/if}
						</dt>
						<dd class="mt-1 text-3xl leading-9 font-semibold text-green-600">
							{#if $langCode === 'en'}
								{total_solved_users}
							{:else}
								{translateEnNumToBnNum(total_solved_users)}
							{/if}
							<span class="text-base text-gray-800"
								>{#if $langCode === 'en'}
									people
								{:else}
									জন
								{/if}</span
							>
						</dd>
					</dl>
				</div>
			</div>
			<div class="bg-white overflow-hidden shadow sm:rounded-lg">
				<div class="px-10 py-8">
					<dl>
						<dt class="pt-2 text-xl leading-5 font-medium text-gray-800 truncate">
							{#if $langCode === 'en'}
								Processed Complaints of
							{:else}
								অভিযোগ করেছেন
							{/if}
						</dt>
						<dd class="mt-1 text-3xl leading-9 font-semibold text-green-600">
							{#if $langCode === 'en'}
								{total_user}
							{:else}
								{translateEnNumToBnNum(total_user)}
							{/if}
							<span class="text-base text-gray-800"
								>{#if $langCode === 'en'}
									people
								{:else}
									জন
								{/if}</span
							>
						</dd>
					</dl>
				</div>
			</div>
		</div>
	</div>
</div>
