<script>
	import { onMount } from 'svelte';
	import RegulatoryDashboard from '../../lib/components/dashboard/regulatory/RegulatoryDashboard.svelte';
	import UserDashboard from '../../lib/components/dashboard/user/UserDashboard.svelte';

	export let role;

	let DashboardComponent;

	onMount(() => {
		role = localStorage.getItem('role_id');
		console.debug('role', role);
		if (role === 'user') {
			DashboardComponent = UserDashboard;
		} else {
			DashboardComponent = RegulatoryDashboard;
		}
	});
</script>

{#if DashboardComponent}
	<div class="fixed">
		<svelte:component this={DashboardComponent} />
	</div>
{/if}
