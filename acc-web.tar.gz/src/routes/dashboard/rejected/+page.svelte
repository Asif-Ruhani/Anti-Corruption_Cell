<script>
	import RegulatoryDashboard from '../../../lib/components/dashboard/regulatory/RegulatoryDashboard.svelte';

	export let role;
</script>

<RegulatoryDashboard isRejectedList={true} />
