<script>
	import { goto } from '$app/navigation';
	import { PUBLIC_API_URL } from '$env/static/public';
	import LoginChoose from '$lib/components/LoginChoose.svelte';
	import { translate } from '$lib/translate';
	import { onDestroy, onMount } from 'svelte';
	import { writable } from 'svelte/store';

	let translateFunction = (key) => key;
	const unsubscribe = translate.subscribe((fn) => {
		translateFunction = fn;
	});

	onDestroy(() => {
		unsubscribe();
	});

	let user_id = writable('');
	onMount(() => {
		user_id.set(localStorage.getItem('mamun_user_id') || '-1');
		loadCategories();
		loadCities();
	});

	let title = '';
	let categories = [];
	let cities = [];
	let cat_id = '';
	let desc = '';
	let city = '';
	let address = '';
	let status = 'pending';

	const loadCategories = async () => {
		try {
			const response = await fetch(PUBLIC_API_URL + '/categories/');
			if (response.ok) {
				categories = await response.json();
			} else {
				console.error('Failed to load categories');
			}
		} catch (error) {
			console.error('Error fetching categories:', error);
		}
	};

	const loadCities = async () => {
		try {
			const response = await fetch(PUBLIC_API_URL + '/complaints/city');
			if (response.ok) {
				cities = await response.json();
			} else {
				console.error('Failed to load categories');
			}
		} catch (error) {
			console.error('Error fetching categories:', error);
		}
	};

	async function uploadEvidences(complaintId) {
		console.debug(complaintId);
		const formData = new FormData();
		files.forEach((file) => {
			formData.append('files', file);
		});

		try {
			const response = await fetch(
				PUBLIC_API_URL + `/attachments/upload?complaint_id=${complaintId}`,
				{
					method: 'POST',
					body: formData
				}
			);

			if (!response.ok) {
				throw new Error('File upload failed');
			}

			const uploadedAttachment = await response.json();
			console.log('Uploaded Attachment:', uploadedAttachment);
			goto(`/complaints/${complaintId}`);
		} catch (error) {
			console.error('Error uploading file:', error);
		}
	}

	const submitComplaint = async () => {
		const complaintData = {
			user_id: $user_id,
			title: title,
			cat_id: parseInt(cat_id, 10),
			desc: desc,
			city: city,
			address: address,
			status: status,
			created_at: new Date().toISOString(),
			modified_at: new Date().toISOString()
		};

		const response = await fetch(PUBLIC_API_URL + '/complaints/create', {
			method: 'POST',
			headers: {
				'Content-Type': 'application/json'
			},
			body: JSON.stringify(complaintData)
		});

		if (!response.ok) {
			console.error('Failed to submit complaint');
		} else {
			const result = await response.json();
			console.debug(result.complaint_id);
			uploadEvidences(result.complaint_id);

			console.log('Complaint created:', result);
		}
	};

	const MAX_FILE_SIZE_MB = 25; // Maximum file size in MB
	const MAX_FILE_SIZE_BYTES = MAX_FILE_SIZE_MB * 1024 * 1024; // Convert to bytes

	let files = []; // Array to hold valid files
	let error = ''; // To display error messages

	// Handle file selection
	function handleFileChange(event) {
		const selectedFiles = Array.from(event.target.files); // Convert FileList to array
		const validFiles = [];
		let invalidFile = null;

		// Validate each file
		for (const file of selectedFiles) {
			if (file.size > MAX_FILE_SIZE_BYTES) {
				invalidFile = file.name; // Record the first invalid file
				break;
			} else {
				validFiles.push(file);
			}
		}

		// Update state
		if (invalidFile) {
			error = `File "${invalidFile}" exceeds the 25MB size limit.`;
		} else {
			error = ''; // Clear errors
			files = validFiles; // Update valid files list
		}
	}

	function removeFile(fileToRemove) {
		files = files.filter((file) => file !== fileToRemove);
	}

	let verifySuccess = writable(false);
</script>

<div class="flex items-center justify-center p-12">
	<div class="mx-auto w-full max-w-[500px] p-8 border border-gray-200 rounded-lg shadow-md">
		<div class="text-xl text-gray-600 text-center py-4 mb-4">
			<h2 class="font-semibold text-xl text-gray-600">Please fill out all the fields.</h2>
		</div>
		<form on:submit|preventDefault={submitComplaint}>
			<LoginChoose {verifySuccess} />
			<div class="mb-5">
				<label for="title" class="mb-3 block text-base font-medium text-[#07074D]">
					{translateFunction('title')}
				</label>
				<input
					required
					type="text"
					name="title"
					id="title"
					bind:value={title}
					placeholder={translateFunction('title_msg')}
					class="w-full rounded-md transition border border-[#e0e0e0] bg-white py-3 px-6 text-base font-medium text-[#6B7280] outline-none focus:border-[#6A64F1] focus:shadow-md"
				/>
			</div>

			<div class="mb-5">
				<label for="category" class="mb-3 block text-base font-medium text-[#07074D]">
					{translateFunction('category')}
				</label>

				<select
					required
					id="category"
					bind:value={cat_id}
					class="w-full rounded-md transition border border-[#e0e0e0] bg-white py-3 px-6 text-base font-medium text-[#6B7280] outline-none focus:border-[#6A64F1] focus:shadow-md"
				>
					{#each categories as category (category.cat_id)}
						<option value={category.cat_id}
							>{translateFunction(
								category.cat_name.toLocaleLowerCase().replaceAll(' ', '_')
							)}</option
						>
					{/each}
				</select>
			</div>

			<div class="mb-5">
				<label for="desc" class="mb-3 block text-base font-medium text-[#07074D]">
					{translateFunction('description')}
				</label>
				<textarea
					required
					rows="4"
					name="desc"
					id="desc"
					bind:value={desc}
					placeholder={translateFunction('describe_msg')}
					class="w-full resize-none transition rounded-md border border-[#e0e0e0] bg-white py-3 px-6 text-base font-medium text-[#6B7280] outline-none focus:border-[#6A64F1] focus:shadow-md"
				></textarea>
			</div>

			<div class="mb-5">
				<label for="category" class="mb-3 block text-base font-medium text-[#07074D]">
					{translateFunction('incident_city')}
				</label>

				<select
					required
					id="countries"
					bind:value={city}
					class="w-full rounded-md transition border border-[#e0e0e0] bg-white py-3 px-6 text-base font-medium text-[#6B7280] outline-none focus:border-[#6A64F1] focus:shadow-md"
				>
					{#each cities as city}
						<option value={city}>{translateFunction(city.toLocaleLowerCase())}</option>
					{/each}
				</select>
			</div>

			<div class="mb-5">
				<label for="address" class="mb-3 block text-base font-medium text-[#07074D]">
					{translateFunction('incident_addr')}
				</label>
				<input
					required
					type="text"
					name="address"
					id="address"
					bind:value={address}
					placeholder="Enter the Address"
					class="w-full transition rounded-md border border-[#e0e0e0] bg-white py-3 px-6 text-base font-medium text-[#6B7280] outline-none focus:border-[#6A64F1] focus:shadow-md"
				/>
			</div>

			<div class="mb-8">
				<input
					type="file"
					name="file"
					id="file"
					required
					class="sr-only"
					multiple
					on:change={handleFileChange}
				/>
				<label
					for="file"
					class="bg-white relative flex min-h-[80px] items-center justify-center rounded-md border border-dashed border-[#e0e0e0] p-12 text-center"
				>
					<div>
						<span class="mb-2 block text-xl font-semibold text-[#07074D]">
							{translateFunction('drop_file')}
						</span>
						<span class="mb-2 block text-base font-medium text-[#6B7280]">
							{translateFunction('or')}
						</span>

						<span
							class="bg-blue-600 hover:bg-blue-500 inline-flex border border-[#e0e0e0] py-2 px-7 text-base font-medium text-white rounded-md"
						>
							{translateFunction('browse')}
						</span>
					</div>
				</label>
			</div>

			<!-- Error Message -->
			{#if error}
				<p class="text-red-500 mt-2">{error}</p>
			{/if}

			<!-- File List -->
			<div id="file-list" class="mt-4">
				{#if files.length > 0}
					{#each files as file}
						<div class="border mb-2 rounded-md bg-white py-4 px-8">
							<div class="flex items-center justify-between">
								<span class="pr-3 text-base font-medium text-[#07074D] break-all">
									{file.name} ({(file.size / (1024 * 1024)).toFixed(2)} MB)
								</span>
								<button type="button" class="text-[#07074D]" on:click={removeFile(file)}>
									<svg
										width="10"
										height="10"
										viewBox="0 0 10 10"
										fill="none"
										xmlns="http://www.w3.org/2000/svg"
									>
										<path
											fill-rule="evenodd"
											clip-rule="evenodd"
											d="M0.279337 0.279338C0.651787 -0.0931121 1.25565 -0.0931121 1.6281 0.279338L9.72066 8.3719C10.0931 8.74435 10.0931 9.34821 9.72066 9.72066C9.34821 10.0931 8.74435 10.0931 8.3719 9.72066L0.279337 1.6281C-0.0931125 1.25565 -0.0931125 0.651788 0.279337 0.279338Z"
											fill="currentColor"
										/>
										<path
											fill-rule="evenodd"
											clip-rule="evenodd"
											d="M0.279337 9.72066C-0.0931125 9.34821 -0.0931125 8.74435 0.279337 8.3719L8.3719 0.279338C8.74435 -0.0931127 9.34821 -0.0931123 9.72066 0.279338C10.0931 0.651787 10.0931 1.25565 9.72066 1.6281L1.6281 9.72066C1.25565 10.0931 0.651787 10.0931 0.279337 9.72066Z"
											fill="currentColor"
										/>
									</svg>
								</button>
							</div>
						</div>
					{/each}
				{:else}
					<p class="border mb-5 rounded-md bg-white py-4 px-8 text-gray-500">No files selected</p>
				{/if}
			</div>

			<div class="flex justify-center mt-4">
				<button
					class="hover:shadow-form rounded-md bg-blue-600 hover:bg-blue-500 transition py-3 px-6 text-base font-semibold text-white outline-none"
				>
					{translateFunction('submit')}
				</button>
			</div>
		</form>
	</div>
</div>
