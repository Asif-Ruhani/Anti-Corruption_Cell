<script>
	import { langCode } from '$lib/translate';
</script>

<svelte:head>
	<title>About • ACC</title>
</svelte:head>

<head>
	<meta charset="UTF-8" />
	<style>
		body {
			font-family: Arial, sans-serif;
			margin: 0;
			padding: 0;
			line-height: 1.6;
			color: #333;
		}

		header h1 {
			margin: 0;
			font-size: 2.5rem;
		}
		header p {
			margin: 5px 0 15px;
			font-size: 1.2rem;
		}
		.content {
			padding: 20px;
			max-width: 800px;
			margin: 0 auto;
		}
		h2 {
			color: #0047ab;
		}
		blockquote {
			background: #f9f9f9;
			border-left: 10px solid #0047ab;
			margin: 20px 0;
			padding: 10px 20px;
			font-style: italic;
			color: #555;
		}
		footer {
			text-align: center;
			padding: 10px 0;
			background-color: #f4f4f4;
			margin-top: 20px;
			font-size: 0.9rem;
		}
	</style>
</head>

<body>
	<header class="bg-[#0047ab] text-white text-center py-2">
		<h1 class="font-semibold mt-4">{$langCode === 'en' ? 'About Us' : 'আমাদের সম্পর্কে'}</h1>
		<p>
			{$langCode === 'en'
				? `“Together Against Corruption: Paving the Way for Integrity and Sustainable Progress.”`
				: `“দুর্নীতির বিরুদ্ধে একত্রে: সততা ও টেকসই উন্নয়নের জন্য।”`}
		</p>
	</header>
	<div class="content">
		<h2 class="font-semibold text-2xl my-6">
			{$langCode === 'en'
				? `What Great Minds Think About Corruption`
				: `দুর্নীতি নিয়ে মহান মনিষীদের চিন্তা`}
		</h2>
		<blockquote>
			{$langCode === 'en'
				? `"Power tends to corrupt, and absolute power corrupts absolutely." — *Lord Acton*`
				: `"শক্তি দুর্নীতিগ্রস্ত করে, এবং সম্পূর্ণ শক্তি পুরোপুরি দুর্নীতিগ্রস্ত করে দেয়।" — *লর্ড অ্যাকটন*`}
		</blockquote>

		<blockquote>
			{$langCode === 'en'
				? `"The road to justice may be long, but the end of corruption is worth every step." — *unknown*`
				: `"ন্যায়বিচারের রাস্তা দীর্ঘ হতে পারে, কিন্তু দুর্নীতির অবসানের প্রতিটি পদক্ষেপ মূল্যবান।" — *অজ্ঞাত*`}
		</blockquote>

		<blockquote>
			{$langCode === 'en'
				? `"If a country is to be corruption-free and become a nation of beautiful minds, I strongly feel
			there are three key societal members who can make a difference. They are the father, the
			mother, and the teacher." — *Dr. A.P.J. Abdul Kalam*`
				: `"যদি একটি দেশ দুর্নীতিমুক্ত হতে চায় এবং সুন্দর মননের জাতিতে পরিণত হতে চায়, আমি দৃঢ়ভাবে বিশ্বাস করি যে সমাজের তিনটি মূল সদস্য পার্থক্য আনতে পারে। তারা হলেন বাবা, মা, এবং শিক্ষক।" — *ড. এ.পি.জি. আবদুল কালাম*`}
		</blockquote>

		<h2 class="font-semibold text-2xl mt-8 mb-4">
			{$langCode === 'en'
				? `Why We Stand Against Corruption`
				: `কেন আমরা দুর্নীতির বিরুদ্ধে দাঁড়িয়ে আছি`}
		</h2>
		<p>
			{$langCode === 'en'
				? `Corruption is one of the greatest obstacles to development and prosperity, especially in
			countries like Bangladesh, where every resource counts. Studies show that corruption drains <strong
				>2-5% of the national GDP annually</strong
			>, limiting growth opportunities and exacerbating inequality.`
				: `দুর্নীতি একটি মহৎ প্রতিবন্ধকতা যা বাংলাদেশের মতো উন্নয়নশীল দেশে উন্নতি এবং সমৃদ্ধির পথে অন্তরায়। গবেষণায় দেখা গেছে, দুর্নীতি প্রতি বছর জাতীয় জিডিপির ২-৫% ক্ষতি করে, যার ফলে বিকাশের সুযোগ সীমিত হয় এবং অমীমাংসিত অসমতা বাড়ে।`}
		</p>
		<p class="pt-4">
			{#if $langCode === 'en'}
				According to the <a
					href="https://www.transparency.org/en/countries/bangladesh"
					target="_blank"
					class="text-blue-700 underline">Transparency International</a
				>, Bangladesh consistently struggles with high corruption levels, especially in public
				sectors such as health, education, and law enforcement. This deprives citizens of their
				rights and hinders the nation's progress toward becoming a developed country by 2041.
			{:else}
				<a
					href="https://www.transparency.org/en/countries/bangladesh"
					target="_blank"
					class="text-blue-700 underline">ট্রান্সপারেন্সি ইন্টারন্যাশনাল</a
				> এর মতে, বাংলাদেশ প্রতিনিয়ত দুর্নীতির উচ্চ মাত্রায় ভুগছে, বিশেষত স্বাস্থ্য, শিক্ষা এবং আইন প্রয়োগের
				মতো সরকারি সেক্টরে। এটি নাগরিকদের অধিকার থেকে বঞ্চিত করে এবং দেশের উন্নতির পথে বাধা সৃষ্টি করে,
				বিশেষত ২০৪১ সালের মধ্যে একটি উন্নত দেশ হিসেবে প্রতিষ্ঠিত হওয়ার লক্ষ্যে।
			{/if}
		</p>

		<h2 class="font-semibold text-2xl mt-8 mb-4">
			{$langCode === 'en' ? `Our Mission` : `আমাদের লক্ষ্য`}
		</h2>
		<p>
			{$langCode === 'en'
				? `We are committed to creating a transparent and accountable society in Bangladesh. By providing
			a platform where citizens can easily report instances of corruption, we aim to empower
			individuals, reduce malpractice, and promote good governance.`
				: `আমরা বাংলাদেশের সমাজে স্বচ্ছতা ও জবাবদিহি তৈরি করতে প্রতিশ্রুতিবদ্ধ। আমরা একটি প্ল্যাটফর্ম প্রদান করছি যেখানে নাগরিকরা সহজে দুর্নীতি সংক্রান্ত অভিযোগ জমা দিতে পারেন, যাতে জনগণের ক্ষমতায়ন হয়, দুর্নীতির বিরুদ্ধে কাজ করা হয় এবং সুশাসন প্রতিষ্ঠিত হয়।`}
		</p>
		<h2 class="font-semibold text-2xl mt-8 mb-4">
			{$langCode === 'en' ? `What We Offer` : `আমরা কী প্রদান করি`}
		</h2>
		<ul class="list-disc pl-10 space-y-2">
			<li>
				{#if $langCode === 'en'}
					<strong>Easy Complaint Filing:</strong> Submit complaints about corruption in any government
					or private organization with detailed categorization.
				{:else}
					<strong>সহজ অভিযোগ জমা:</strong> যে কোন সরকারি বা বেসরকারি সংস্থা সম্পর্কে দুর্নীতি অভিযোগ
					জমা দেওয়ার জন্য বিস্তারিত শ্রেণীবিভাগ সহ সুবিধা।
				{/if}
			</li>
			<li>
				{#if $langCode === 'en'}
					<strong>Tracking System:</strong> Track the status of your complaint in real-time.
				{:else}
					<strong>ট্র্যাকিং সিস্টেম:</strong> আপনার অভিযোগের স্ট্যাটাস রিয়েল-টাইমে ট্র্যাক করুন।
				{/if}
			</li>
			<li>
				{#if $langCode === 'en'}
					<strong>Secure & Anonymous Reporting:</strong> Report corruption without fear of retaliation.
				{:else}
					<strong>নিরাপদ ও গোপনীয় রিপোর্টিং:</strong> প্রতিশোধের ভয় ছাড়াই দুর্নীতি রিপোর্ট করুন।
				{/if}
			</li>
			<li>
				{#if $langCode === 'en'}
					<strong>Awareness & Advocacy:</strong> Learn more about anti-corruption efforts and join our
					initiatives to promote transparency.
				{:else}
					<strong>জ্ঞান এবং সচেতনতা:</strong> দুর্নীতি বিরোধী প্রচারণায় অংশগ্রহণ এবং সুশাসনের প্রচারে
					সহায়তা করুন।
				{/if}
			</li>
		</ul>

		<h2 class="font-semibold text-2xl mt-8 mb-4">
			{$langCode === 'en' ? `Why We Are Here` : `কেন আমরা এখানে আছি`}
		</h2>
		<p>
			{$langCode === 'en'
				? `We believe that fighting corruption is not just the responsibility of governments but of every
			citizen. With your participation, we can expose malpractice, hold offenders accountable, and
			pave the way for a brighter future for Bangladesh. Together, let’s build a society where
			integrity, fairness, and accountability prevail.`
				: `আমরা বিশ্বাস করি, দুর্নীতির বিরুদ্ধে লড়াই শুধু সরকারের দায়িত্ব নয়, এটি প্রতিটি নাগরিকের দায়িত্বও। আপনার অংশগ্রহণের মাধ্যমে আমরা অনৈতিক কাজগুলো উন্মোচন করতে, অপরাধীদের দায়বদ্ধ করতে এবং বাংলাদেশের একটি উজ্জ্বল ভবিষ্যৎ গড়ে তুলতে সক্ষম হবো। আসুন, একসাথে এমন একটি সমাজ গড়ে তুলি যেখানে সততা, ন্যায্যতা এবং জবাবদিহিতা প্রতিষ্ঠিত হবে।`}
		</p>
	</div>
	<footer>&copy; 2024 Anti-Corruption Website | Designed for a Better Bangladesh</footer>
</body>
