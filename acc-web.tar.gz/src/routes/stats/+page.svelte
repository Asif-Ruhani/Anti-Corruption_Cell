<script>
	import { PUBLIC_API_URL } from '$env/static/public';
	import { langCode, translate } from '$lib/translate';
	import { onDestroy, onMount } from 'svelte';
	import { writable } from 'svelte/store';

	let translateFunction = (key) => key;
	const unsubscribe = translate.subscribe((fn) => {
		translateFunction = fn;
	});

	onDestroy(() => {
		unsubscribe();
	});

	let users = writable([]);
	let userStats = {};
	let filteredUsers = writable([]);
	let userRole = writable('user');
	let modalOpen = false;

	// Function to toggle user status
	async function toggleStatus(userId, status) {
		const response = await fetch(PUBLIC_API_URL + `/users/${userId}/status?status=${status}`, {
			method: 'PUT',
			headers: { 'Content-Type': 'application/json' }
		});

		if (!response.ok) {
			const errorData = await response.json();
			throw new Error(errorData.detail || 'Failed to update user status');
		}
	}

	function filterUsers(users, role_id = '') {
		return users.filter((user) => {
			const excludeAdmin = user.role_id !== 'admin';
			const roleMatches = role_id ? user.role_id === role_id : true;
			return excludeAdmin && roleMatches;
		});
	}

	$: {
		console.debug($userRole);
		console.debug(filterUsers($users, $userRole));
		filteredUsers.set(filterUsers($users, $userRole));
	}

	onMount(async () => {
		try {
			const response = await fetch(`${PUBLIC_API_URL}/users/users`);
			if (!response.ok) throw new Error('Failed to fetch comment data');
			const json = await response.json();

			for (const x of json) {
				const resp = await fetch(`${PUBLIC_API_URL}/complaints/stats?user_id=${x.user_id}`);
				if (resp.ok) {
					const usrjsn = await resp.json();
					userStats[x.user_id] = usrjsn;
				}
			}
			users.set(json);
		} catch (err) {}
	});

	function closeModal() {
		modalOpen = false;
	}

	function translateEnNumToBnNum(text) {
		return text
			.replaceAll('1', '১')
			.replaceAll('2', '২')
			.replaceAll('3', '৩')
			.replaceAll('4', '৪')
			.replaceAll('5', '৫')
			.replaceAll('6', '৬')
			.replaceAll('7', '৭')
			.replaceAll('8', '৮')
			.replaceAll('9', '৯')
			.replaceAll('0', '০');
	}
</script>

<main>
	<div class="min-h-screen bg-gray-100 mx-auto">
		<!-- Navbar -->
		<nav class="bg-green-600 text-white p-6">
			<span class="text-2xl font-semibold text-white">
				{#if $langCode === 'en'}
					Admin Dashboard
				{:else}
					ইউজার ম্যানেজমেন্ট ড্যাশবোর্ড
				{/if}
			</span>
		</nav>

		<!-- <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 w-full min-w-0 pt-8 px-6">
			In use
			<div class="flex flex-col px-6 py-2 bg-white shadow rounded-lg overflow-hidden">
				<div class="flex flex-col items-center space-y-2">
					<div class="text-6xl font-bold tracking-tight leading-none text-blue-500">21</div>
					<div class="text-lg font-medium text-blue-500">In use</div>
				</div>
			</div>
			renovation
			<div class="flex flex-col px-6 py-2 bg-white shadow rounded-lg overflow-hidden">
				<div class="flex flex-col items-center space-y-2">
					<div class="text-6xl font-bold tracking-tight leading-none text-amber-500">17</div>
					<div class="text-lg font-medium text-amber-600">Under renovation</div>
				</div>
			</div>
			Suspended
			<div class="flex flex-col px-6 py-2 bg-white shadow rounded-lg overflow-hidden">
				<div class="flex flex-col items-center space-y-2">
					<div class="text-6xl font-bold tracking-tight leading-none text-red-500">24</div>
					<div class="text-lg font-medium text-red-600">Suspended</div>
				</div>
			</div>
		</div> -->

		<!-- Main Content -->
		<main class="p-6">
			<div class="mb-6 flex items-center justify-end hidden">
				<!-- Filters Section (Left) -->
				<div class="flex flex-row justify-start border bg-stone-100 rounded-md items-center">
					<select id="filter-select" class="rounded-md px-8 py-2" bind:value={$userRole}>
						<option value="regulatory">
							{#if $langCode === 'en'}
								Regulatory
							{:else}
								রেগুলেটরি
							{/if}</option
						>
						<option value="user">
							{#if $langCode === 'en'}
								General User
							{:else}
								সাধারণ ইউজার
							{/if}</option
						>
					</select>
				</div>

				<!-- Add New User Button (Right) -->
				<div class="flex justify-end">
					<button class="bg-blue-500 text-white py-2 px-4 rounded">Add New User</button>
				</div>
			</div>

			<!-- User Table -->
			<table class="min-w-full bg-white rounded-lg shadow-md text-center">
				<thead>
					<tr class="bg-gray-200">
						<th class="text-center px-4 py-2">
							{#if $langCode === 'en'}
								User ID
							{:else}
								ইউজার আইডি
							{/if}
						</th>
						<!-- <th class="text-center px-4 py-2">Role</th> -->
						<th class="text-center px-4 py-2">
							{#if $langCode === 'en'}
								Submitted
							{:else}
								জমা দিয়েছেন
							{/if}
						</th>
						<th class="text-center px-4 py-2">
							{#if $langCode === 'en'}
								Solved
							{:else}
								সমাধান হয়েছে
							{/if}
						</th>
						<th class="text-center px-4 py-2">
							{#if $langCode === 'en'}
								Rejected
							{:else}
								প্রত্যাখ্যান হয়েছে
							{/if}
						</th>
						<th class="text-center px-4 py-2">
							{#if $langCode === 'en'}
								Status
							{:else}
								স্ট্যাটাস
							{/if}
						</th>
						<th class="text-center px-4 py-2">
							{#if $langCode === 'en'}
								Actions
							{:else}
								অ্যাকশন
							{/if}
						</th>
					</tr>
				</thead>
				<tbody>
					{#each $filteredUsers as user}
						<tr>
							<td class="px-4 py-2">
								{#if $langCode === 'bn'}
									{translateEnNumToBnNum(user.user_id.toString())}
								{:else}
									{user.user_id.toString()}
								{/if}
							</td>
							<!-- <td class="px-4 py-2"
								><span
									class={`inline-block px-2 py-1 rounded text-white`}
									class:bg-blue-500={user.role_id === 'user'}
									class:bg-red-500={user.role_id === 'admin'}
									class:bg-orange-500={user.role_id === 'regulatory'}
								>
									{user.role_id}
								</span></td
							> -->
							<td class="px-4 py-2">
								{#if $langCode === 'bn'}
									{translateEnNumToBnNum(userStats[user.user_id].total_complaints.toString())}
								{:else}
									{userStats[user.user_id].total_complaints.toString()}
								{/if}
							</td>
							<td class="px-4 py-2">
								{#if $langCode === 'bn'}
									{translateEnNumToBnNum(userStats[user.user_id].statuses.solved.toString())}
								{:else}
									{userStats[user.user_id].statuses.solved.toString()}
								{/if}</td
							>
							<td class="px-4 py-2">
								{#if $langCode === 'bn'}
									{translateEnNumToBnNum(userStats[user.user_id].statuses.rejected.toString())}
								{:else}
									{userStats[user.user_id].statuses.rejected.toString()}
								{/if}
							</td>
							<td class="px-4 py-2">
								<span
									class={`inline-block px-2 py-1 rounded text-white`}
									class:bg-green-500={user.status === 'active'}
									class:bg-red-500={user.status === 'disabled'}
								>
									{translateFunction(user.status)}
								</span>
							</td>
							<td class="px-4 py-2">
								<select
									id="filter-select"
									class="bg-gray-50 border border-gray-300 rounded-md px-8 py-2 w-fit"
									bind:value={user.status}
									on:change={() => toggleStatus(user.user_id, user.status)}
								>
									<option value="active">
										{translateFunction('active')}
									</option>
									<option value="disabled">
										{translateFunction('disabled')}
									</option>
								</select>
							</td>
						</tr>
					{/each}
				</tbody>
			</table>
		</main>
	</div>
</main>