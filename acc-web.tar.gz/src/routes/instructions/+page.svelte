<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1.0" />
	<title>Instructions - Anti-Corruption Website</title>
	<style>
		body {
			font-family: Arial, sans-serif;
			margin: 0;
			padding: 0;
			line-height: 1.6;
			color: #333;
		}

		header h1 {
			margin: 0;
			font-size: 2.5rem;
		}

		.content {
			padding: 20px;
			max-width: 800px;
			margin: 0 auto;
			flex: 1;
		}

		h2 {
			color: #0047ab;
		}

		footer {
			text-align: center;
			padding: 10px 0;
			background-color: #f4f4f4;
			font-size: 0.9rem;
			position: relative;
		}
	</style>
</head>

<svelte:head>
	<title>Instructions • ACC</title>
</svelte:head>

<body>
	<header>
		<h1 class="text-4xl font-bold text-center py-6 bg-[#0047ab] text-white">Instructions</h1>
	</header>

	<div class="content">
		<h2 class="font-semibold text-2xl mt-8 mb-6">How to Use the Anti-Corruption Cell Platform</h2>
		<ul class="list-disc ml-6 space-y-4 text-lg">
			<li>
				<strong>Visit the Website:</strong> Open the Anti-Corruption Cell platform on any internet browser.
			</li>
			<li>
				<strong>Register or Log In:</strong> New users can register by filling out the required details,
				while existing users can log in with their credentials.
			</li>
			<li>
				<strong>Submit a Complaint:</strong> Navigate to the "Report Corruption" section, provide details
				of the incident, and optionally attach evidence.
			</li>
			<li>
				<strong>Track Complaint Status:</strong> Use the "Complaint Tracking" feature to monitor the
				progress of your report with the assigned ID.
			</li>
			<li>
				<strong>View Corruption Statistics:</strong> Explore real-time data on complaints, trends, and
				resolutions through interactive charts in the "Statistics" section.
			</li>
			<li>
				<strong>Access Resources:</strong> Learn about anti-corruption practices, prevention tips, and
				other resources to combat corruption effectively.
			</li>
			<li>
				<strong>Provide Feedback:</strong> Use the feedback form to share your experience or rate the
				platform's services.
			</li>
		</ul>
	</div>
</body>
