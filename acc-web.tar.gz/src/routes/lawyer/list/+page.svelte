<script>
	const lawyers = [
		{
			name: 'A.B.M. Hamidul Mishbah',
			designation: 'Managing Partner, Old Bailey Chambers',
			practiceAreas: ['Family Law', 'Corporate Law', 'Intellectual Property'],
			court: 'Supreme Court of Bangladesh',
			experience: '16+ years',
			specialties: ['IP rights', 'corporate disputes', 'mergers & acquisitions'],
			fees: 'Negotiable',
			contact: '+880 1727 444 888 / mishbah@oldbaileybd.com'
		},
		{
			name: 'Mohammed Forrukh Rahman',
			designation: 'Head of Rahman’s Chambers',
			practiceAreas: ['Corporate Law', 'Banking', 'Aviation'],
			court: 'Supreme Court and other commercial courts',
			experience: 'Extensive corporate expertise',
			specialties: ['Regulatory advice', 'commercial disputes'],
			fees: 'Variable based on case type',
			contact: 'info@rahmansc.com'
		},
		{
			name: 'Sara Hossain',
			designation: 'Partner, Dr. Kamal Hossain & Associates',
			practiceAreas: ['Human Rights', 'Constitutional Law'],
			court: 'Supreme Court of Bangladesh',
			experience: '20+ years in high-profile cases',
			specialties: ['Human rights', 'public interest litigation'],
			fees: 'Negotiable',
			contact: '+880 1234 567 890'
		},
		{
			name: 'Rashna Imam',
			designation: 'Managing Partner, Akhtar Imam & Associates',
			practiceAreas: ['Commercial Law', 'Arbitration'],
			court: 'Supreme Court of Bangladesh',
			experience: '15+ years',
			specialties: ['Corporate disputes', 'arbitration'],
			fees: 'Depends on case type',
			contact: '+880 555 666 777'
		},
		{
			name: 'Anita Rahman',
			designation: 'Founder, The Legal Circle',
			practiceAreas: ['Corporate Law', 'Banking', 'Commercial Disputes'],
			court: 'Supreme Court of Bangladesh',
			experience: '12+ years',
			specialties: ['Legal advisory for startups', 'corporate litigation'],
			fees: 'Negotiable',
			contact: 'contact@thelegalcircle.com'
		},
		{
			name: 'Nasir Uddin Doulah',
			designation: 'Managing Partner, Doulah & Doulah',
			practiceAreas: ['Corporate Law', 'Foreign Direct Investment'],
			court: 'Supreme Court of Bangladesh',
			experience: '18+ years',
			specialties: ['Structuring foreign investments', 'cross-border disputes'],
			fees: 'Case dependent',
			contact: 'doulah@doulah.com.bd'
		},
		{
			name: 'Al-Amin Rahman',
			designation: 'Partner, FM Associates',
			practiceAreas: ['Arbitration', 'Corporate', 'Aviation'],
			court: 'Supreme Court of Bangladesh',
			experience: '14+ years',
			specialties: ['International arbitration', 'foreign investments'],
			fees: 'Available on request',
			contact: 'Dhaka@fma.com.bd'
		},
		{
			name: 'Shawn S. Novel',
			designation: 'Founder, Shawn Novel & Associates',
			practiceAreas: ['Intellectual Property', 'Venture Capital'],
			court: 'Supreme Court of Bangladesh',
			experience: '10+ years',
			specialties: ['Emerging tech', 'startup legal services'],
			fees: 'Case-based',
			contact: 'info@novelbd.com'
		},
		{
			name: 'Sameer Sattar',
			designation: 'Founder, Sattar & Co',
			practiceAreas: ['Corporate Finance', 'Commercial Law'],
			court: 'Supreme Court of Bangladesh',
			experience: '15+ years',
			specialties: ['Financing', 'mergers, and acquisitions'],
			fees: 'Variable',
			contact: 'sattar@sattarco.com'
		},
		{
			name: 'Shahdeen Malik',
			designation: 'Counsel, Ergo Legal',
			practiceAreas: ['Corporate Law', 'Anti-Corruption'],
			court: 'Supreme Court of Bangladesh',
			experience: '22+ years',
			specialties: ['Anti-corruption advisory', 'complex litigation'],
			fees: 'Negotiable',
			contact: 'malik@ergolegal.com'
		}
	];

	import { createEventDispatcher } from 'svelte';

	let showModal = false; // State to toggle modal visibility
	let selectedLawyer = ''; // To store the selected lawyer's name

	const dispatch = createEventDispatcher();

	function assignLawyer(lawyerName) {
		selectedLawyer = lawyerName;
		showModal = true; // Show the modal
	}

	function closeModal() {
		showModal = false; // Close the modal
	}

	function handleAction(action) {
		dispatch('action', { action, lawyer: selectedLawyer });
		closeModal(); // Close the modal after the action
	}
</script>

<svelte:head>
	<meta charset="UTF-8" />
	<title>Lawyer List</title>
	<style>
		.lawyer-card {
			background: #fff;
			margin: 15px 0;
			padding: 20px;
			border: 1px solid #ddd;
			border-radius: 8px;
			box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
		}
		.lawyer-card h2 {
			margin: 0;
			color: #333;
		}
		.lawyer-card p {
			margin: 8px 0;
			color: #555;
		}
		.btn-group {
			margin-top: 10px;
		}
		.btn {
			padding: 10px 15px;
			margin-right: 10px;
			border: none;
			border-radius: 5px;
			cursor: pointer;
			font-size: 14px;
		}
		.btn-accept {
			background-color: #28a745;
			color: #fff;
		}
		.btn-reject {
			background-color: #dc3545;
			color: #fff;
		}
		.btn:hover {
			opacity: 0.9;
		}

		/* Optional Tailwind override for custom modal styling */
		.modal-backdrop {
			@apply fixed inset-0 bg-gray-800 bg-opacity-50 flex items-center justify-center z-50;
		}

		.modal-content {
			@apply bg-white rounded-lg shadow-xl p-6 max-w-lg w-full;
		}
	</style>
</svelte:head>

<main>
	<h1 class="text-3xl font-semibold text-center pt-10 pb-4">List of Lawyers in Bangladesh</h1>
	<div class="mx-auto w-fit">
		<div class="mx-20">
			{#each lawyers as lawyer}
				<div class="lawyer-card">
					<h2>{lawyer.name}</h2>
					<p><strong>Designation:</strong> {lawyer.designation}</p>
					<p><strong>Practice Areas:</strong> {lawyer.practiceAreas.join(', ')}</p>
					<p><strong>Court:</strong> {lawyer.court}</p>
					<p><strong>Experience:</strong> {lawyer.experience}</p>
					<p><strong>Specialties:</strong> {lawyer.specialties.join(', ')}</p>
					<p><strong>Fees:</strong> {lawyer.fees}</p>
					<p><strong>Contact:</strong> {lawyer.contact}</p>
					<button class="btn btn-accept" on:click={() => assignLawyer(lawyer.name)}
						>Interested</button
					>
				</div>
			{/each}
		</div>
	</div>
</main>

<!-- Modal -->
{#if showModal}
	<div class="modal-backdrop">
		<div class="modal-content">
			<h3 class="text-xl font-bold">Request for a Complaint Assignment</h3>
			<p class="my-4">{`Someone wants to assign ${selectedLawyer} for their complaint.`}</p>
			<div class="flex justify-end space-x-4">
				<button class="btn btn-see" on:click={() => closeModal()}>See Complaint</button>
				<button class="btn btn-accept" on:click={() => closeModal()}>Accept</button>
				<button class="btn btn-reject" on:click={() => closeModal()}>Reject</button>
			</div>
		</div>
	</div>
{/if}
