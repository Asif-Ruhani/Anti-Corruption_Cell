<svelte:head>
	<meta charset="UTF-8" />
	<title>Lawyer Registration Form</title>
	<style>
		.form-container {
			background: #fff;
			padding: 20px;
			border-radius: 8px;
			max-width: 600px;
			margin: 0 auto;
			box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
		}
		.form-container h1 {
			margin-bottom: 20px;
			color: #333;
			text-align: center;
		}
		.form-group {
			margin-bottom: 20px;
		}
		.form-group label {
			display: block;
			margin-bottom: 5px;
			font-weight: bold;
		}
		.form-group input,
		.form-group select,
		.form-group textarea {
			width: 96%;
			padding: 10px;
			border: 1px solid #ddd;
			border-radius: 5px;
			font-size: 14px;
		}
		.form-group input[type='checkbox'] {
			width: auto;
		}
		.form-group .checkbox-group {
			display: flex;
			flex-wrap: wrap;
			gap: 10px;
		}
		.form-group .checkbox-group label {
			font-weight: normal;
		}
		.form-group select {
			padding: 10px;
			width: 96%;
		}
		.form-group button {
			width: 100%;
			padding: 10px 15px;
			background-color: #007bff;
			color: #fff;
			border: none;
			border-radius: 5px;
			font-size: 14px;
			cursor: pointer;
		}
		.form-group button:hover {
			opacity: 0.9;
		}
	</style>
</svelte:head>
<body>
	<div class="form-container mt-4">
		<h1 class="text-lg font-semibold mb-4">Professional Information</h1>
		<form>
			<!-- Name -->
			<div class="form-group">
				<label for="name">Name</label>
				<input type="text" id="name" name="name" required value="A.B.M. Hamidul Mishbah" />
			</div>

			<!-- Study Institution -->
			<div class="form-group">
				<label for="institution">Institution Name</label>
				<select id="institution" name="institution" required value="Others">
					<option value="" disabled selected>Select your institution</option>
					<option value="University of Dhaka - Department of Law"
						>University of Dhaka - Department of Law</option
					>
					<option value="Bangladesh University of Professionals (BUP) - Law Faculty"
						>Bangladesh University of Professionals (BUP) - Law Faculty</option
					>
					<option value="BRAC University - School of Law">BRAC University - School of Law</option>
					<option value="North South University - Department of Law"
						>North South University - Department of Law</option
					>
					<option value="Eastern University - Department of Law"
						>Eastern University - Department of Law</option
					>
					<option value="Rajshahi University - Department of Law"
						>Rajshahi University - Department of Law</option
					>
					<option value="University of Chittagong - Department of Law"
						>University of Chittagong - Department of Law</option
					>
					<option value="Jagannath University - Faculty of Law"
						>Jagannath University - Faculty of Law</option
					>
					<option value="Khulna University - Department of Law"
						>Khulna University - Department of Law</option
					>
					<option value="Bangladesh National University - Law Program"
						>Bangladesh National University - Law Program</option
					>
					<option value="Others">Others</option>
				</select>
			</div>

			<!-- Designation -->
			<div class="form-group">
				<label for="designation">Designation</label>
				<select id="designation" name="designation" required value="Senior Advocate">
					<option value="" disabled selected>Select your designation</option>
					<option value="Senior Advocate">Senior Advocate</option>
					<option value="Junior Advocate">Junior Advocate</option>
					<option value="Associate Lawyer">Associate Lawyer</option>
					<option value="Legal Consultant">Legal Consultant</option>
					<option value="Partner">Partner</option>
					<option value="Managing Partner">Managing Partner</option>
					<option value="Counsel">Counsel</option>
				</select>
			</div>

			<!-- Practice Area -->
			<div class="form-group">
				<label>Practice Area</label>
				<div class="checkbox-group">
					<label><input type="checkbox" name="practice-area" value="Family Law" /> Family Law</label
					>
					<label
						><input type="checkbox" name="practice-area" value="Corporate Law" checked /> Corporate Law</label
					>
					<label
						><input type="checkbox" name="practice-area" value="Criminal Law" /> Criminal Law</label
					>
					<label
						><input type="checkbox" name="practice-area" value="Intellectual Property" checked /> Intellectual
						Property</label
					>
					<label><input type="checkbox" name="practice-area" value="Tax Law" /> Tax Law</label>
					<label
						><input type="checkbox" name="practice-area" value="Banking Law" /> Banking Law</label
					>
				</div>
			</div>

			<!-- Practice of Court -->
			<div class="form-group">
				<label for="practice-court">Practice of Court</label>
				<input type="text" id="practice-court" name="practice-court" required />
			</div>

			<!-- Specialist -->
			<div class="form-group">
				<label for="specialist">Specialist</label>
				<select id="specialist" name="specialist" required>
					<option value="" disabled selected>Select specialization</option>
					<option value="Litigation">Litigation</option>
					<option value="Negotiation">Negotiation</option>
					<option value="Contracts">Contracts</option>
					<option value="Legal Drafting">Legal Drafting</option>
					<option value="Arbitration">Arbitration</option>
				</select>
			</div>

			<!-- Years of Experience -->
			<div class="form-group">
				<label for="experience">Years of Experience</label>
				<input type="number" id="experience" name="experience" min="0" value="16" required />
			</div>

			<!-- Total Solved Cases -->
			<div class="form-group">
				<label for="cases">Total Solved Cases</label>
				<input type="number" id="cases" name="cases" min="0" value="251" required />
			</div>

			<!-- Fees -->
			<div class="form-group">
				<label for="fees">Fees</label>
				<input type="text" id="fees" name="fees" value="Negotiable" required />
			</div>

			<!-- Contact -->
			<div class="form-group">
				<label for="contact">Contact</label>
				<input type="text" id="contact" name="contact" value="+880 1727 444 888 / mishbah@oldbaileybd.com" required />
			</div>

			<!-- Submit Button -->
			<div class="form-group">
				<button type="submit" disabled>Submit</button>
			</div>
		</form>
	</div>
</body>
