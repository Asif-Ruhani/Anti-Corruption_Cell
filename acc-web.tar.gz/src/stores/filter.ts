import { writable } from 'svelte/store';

export let selectedStatus = writable('');
export let selectedCategory = writable('');
export let selectedCity = writable('');

export const filters = writable({
	status: '',
	cat_id: '',
	city: ''
});

export const complaints = writable([]);
