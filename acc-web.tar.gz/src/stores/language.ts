import { writable } from 'svelte/store';

export type LanguageKey = 'en' | 'bn';

export const language = writable<string>('en');
