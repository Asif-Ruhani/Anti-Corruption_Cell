<script lang="ts">
	import { goto } from '$app/navigation';
	import { isLoggedIn } from '../../stores/auth';

	function logout() {
		localStorage.removeItem('user_logged_in');
		localStorage.removeItem('role_id');
		localStorage.removeItem('user_id');
		isLoggedIn.set(false);
		goto('/');
		// window.location.href = '/';
	}
</script>

<button on:click={logout}>
	<svg
		class="h-8 w-8 text-gray-800 hover:text-green-500 duration-200"
		aria-hidden="true"
		xmlns="http://www.w3.org/2000/svg"
		width="24"
		height="24"
		fill="none"
		viewBox="0 0 24 24"
	>
		<path
			stroke="currentColor"
			stroke-linecap="round"
			stroke-linejoin="round"
			stroke-width="2"
			d="M20 12H8m12 0-4 4m4-4-4-4M9 4H7a3 3 0 0 0-3 3v10a3 3 0 0 0 3 3h2"
		/>
	</svg>
</button>
