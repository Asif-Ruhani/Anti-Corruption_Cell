<script lang="ts">
	import LanguageSelector from './LanguageSelector.svelte';
	import { translate, langCode } from '$lib/translate';
	import { onDestroy, onMount } from 'svelte';
	import LogoutButton from './LogoutButton.svelte';
	import { writable } from 'svelte/store';
	import { goto } from '$app/navigation';
	import { isLoggedIn } from '../../stores/auth';
	import { PUBLIC_IS_MMH_MODE } from '$env/static/public';

	let lawyerMode = writable(false);
	//asd
	const navItems = [
		{ name: 'home', href: '/' },
		{ name: 'about', href: '/about' }
		// { name: 'reports', href: '#' },
		// { name: 'resources', href: '#' },
		// { name: 'instructions', href: '/instructions' }
	];

	let translateFunction = (key: string) => key;
	const unsubscribe = translate.subscribe((fn) => {
		translateFunction = fn;
	});

	onDestroy(() => {
		unsubscribe();
	});

	let roleId = writable('user');
	onMount(() => {
		console.debug(typeof PUBLIC_IS_MMH_MODE);
		roleId.set(localStorage.getItem('role_id') || 'user');
		lawyerMode.set((localStorage.getItem('lawyer_mode') || 'false') === 'true');
		isLoggedIn.set(localStorage.getItem('user_logged_in') === 'true' || false);
	});
</script>

<!--https://www.creative-tim.com/twcomponents/component/sticky-header-desktop-->
<header class="header sticky top-0 bg-white shadow-md flex items-center justify-between px-8 pr-2">
	<h1 class="w-3/12">
		{#if $langCode == 'en'}
			<img class="h-12" src="/images/en.trans.png" alt="Anti Corruption Cell" />
		{:else}
			<img class="h-12" src="/images/bn.trans.png" alt="দুর্নীতি বিরোধী সেল" />
		{/if}
	</h1>

	<nav class="nav font-semibold text-lg flex items-center justify-between">
		<!-- Left Side: Navigation Links -->
		<ul class="flex items-center">
			{#each navItems as item}
				<li class="p-4 hover:text-green-500 duration-200 cursor-pointer">
					<button
						on:click={() => {
							// window.location.href = item.href;
							goto(item.href);
						}}>{translateFunction(item.name)}</button
					>
				</li>
			{/each}
			{#if $isLoggedIn}
				<li class="p-4 hover:text-green-500 duration-200 cursor-pointer">
					<button
						on:click={() => {
							goto('/dashboard');
						}}>{translateFunction('dashboard')}</button
					>
				</li>
			{/if}

			{#if PUBLIC_IS_MMH_MODE === 'true'}
				<li class="p-4 hover:text-green-500 duration-200 cursor-pointer">
					<button
						on:click={() => {
							// window.location.href = item.href;
							goto('/track-complaints');
						}}>{translateFunction('my_complaints')}</button
					>
				</li>
			{/if}

			{#if $roleId === 'admin'}
				<li class="p-4 hover:text-green-500 duration-200 cursor-pointer">
					<button
						on:click={() => {
							goto('/stats');
						}}>{translateFunction('manage_users')}</button
					>
				</li>
			{/if}

			{#if $lawyerMode}
				<li class="p-4 hover:text-green-500 duration-200 cursor-pointer">
					<button
						on:click={() => {
							goto('/lawyer/profile');
						}}>Profile</button
					>
				</li>
			{/if}
		</ul>

		<!-- Right Side: Actions -->
		<div class="flex items-center ml-auto">
			<!-- Submit Complaint Button -->

			{#if PUBLIC_IS_MMH_MODE === 'true'}
				{#if $roleId === 'user'}
					<a
						href="/complaint-for-m"
						class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 duration-200"
					>
						{translateFunction('submit_complain')}
					</a>
				{/if}
			{:else if $roleId === 'user'}
				<a
					href={$isLoggedIn ? '/complaint-form' : '/auth/user/login'}
					class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 duration-200"
				>
					{translateFunction('submit_complain')}
				</a>
			{/if}

			<!-- Language Selector -->
			<div class="ml-2">
				<LanguageSelector />
			</div>

			<!-- Notification Button -->
			<!-- <div class="relative inline-block hidden">
				<button>
					<span class="absolute top-2 right-2 h-2 w-2 rounded-full bg-red-500 animate-ping"></span>
					<span class="absolute top-2 right-2 h-2 w-2 rounded-full bg-red-500"></span>
					<svg
						class="h-10 w-10 text-gray-800 p-1 hover:text-green-500 duration-200"
						aria-hidden="true"
						xmlns="http://www.w3.org/2000/svg"
						width="24"
						height="24"
						fill="none"
						viewBox="0 0 24 24"
					>
						<path
							stroke="currentColor"
							stroke-linecap="round"
							stroke-linejoin="round"
							stroke-width="2"
							d="M12 5.365V3m0 2.365a5.338 5.338 0 0 1 5.133 5.368v1.8c0 2.386 1.867 2.982 1.867 4.175 0 .593 0 1.292-.538 1.292H5.538C5 18 5 17.301 5 16.708c0-1.193 1.867-1.789 1.867-4.175v-1.8A5.338 5.338 0 0 1 12 5.365ZM8.733 18c.094.852.306 1.54.944 2.112a3.48 3.48 0 0 0 4.646 0c.638-.572 1.236-1.26 1.33-2.112h-6.92Z"
						/>
					</svg>
				</button>
			</div> -->

			<!-- User Profile Button -->
			<!-- <button class="hidden">
				<svg
					class="h-10 w-10 text-gray-800 p-1 hover:text-green-500 duration-200"
					fill="none"
					viewBox="0 0 24 24"
					stroke="currentColor"
				>
					<path
						stroke-linecap="round"
						stroke-linejoin="round"
						stroke-width="2"
						d="M5.121 17.804A13.937 13.937 0 0112 16c2.5 0 4.847.655 6.879 1.804M15 10a3 3 0 11-6 0 3 3 0 016 0zm6 2a9 9 0 11-18 0 9 9 0 0118 0z"
					/>
				</svg>
			</button> -->
		</div>
		<!-- Logout Button -->
		{#if $isLoggedIn}
			<LogoutButton />
		{/if}
	</nav>
</header>
