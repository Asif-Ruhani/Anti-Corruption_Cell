<script lang="ts">
	import { PUBLIC_API_URL } from '$env/static/public';
	import { translate } from '$lib/translate';
	import { onDestroy } from 'svelte';
	import { writable } from 'svelte/store';
	import { load } from '../../routes/+layout';

	let translateFunction = (key) => key;
	const unsubscribe = translate.subscribe((fn) => {
		translateFunction = fn;
	});

	onDestroy(() => {
		unsubscribe();
	});

	export let verifySuccess: any;

	const error = writable('');
	const showNid = writable(true);
	const showBreg = writable(false);

	let nidNumber = writable('');
	let nidPhoneNumber = writable('');
	let otp = writable('');

	let bRegidNumber = writable('');
	let Dob = writable('');

	let loading = writable(false);
	let showStatusBanner = writable(false);

	async function handleLogin() {
		try {
			let response;
			let verificationResponse;
			const requestBody = $showBreg
				? { bregNum: $bRegidNumber, dob: $Dob, isNid: false }
				: { nid: $nidNumber, phone_num: $nidPhoneNumber, isNid: true };

			loading.set(true);
			// verifying unique IDs
			if (requestBody.isNid) {
				verificationResponse = await fetch(
					`${PUBLIC_API_URL}/users/verify/nid?nid=${$nidNumber}&phone_num=${$nidPhoneNumber}`,
					{
						method: 'GET',
						headers: { Accept: 'application/json' }
					}
				);
			} else {
				verificationResponse = await fetch(
					`${PUBLIC_API_URL}/users/verify/breg?breg_num=${$bRegidNumber}&dob=${$Dob}`,
					{
						method: 'GET',
						headers: { Accept: 'application/json' }
					}
				);
			}

			let nid_numm;
			if (!verificationResponse.ok) {
				error.set('Verification failed.');
				showStatusBanner.set(true);
				verifySuccess.set(false);
			} else {
				showStatusBanner.set(true);
				verifySuccess.set(true);

				nid_numm = await verificationResponse.json();
				response = await fetch(`${PUBLIC_API_URL}/users/getId?nid_num=${nid_numm}`, {
					method: 'POST',
					headers: { 'Content-Type': 'application/json' },
					body: JSON.stringify(requestBody)
				});

				// user not registered
				if (!response.ok) {
					// error = 'Login failed. Please try again later.';
					const requestBdy = {
						nid: nid_numm,
						role_id: 'user',
						status: 'active',
						joint_at: new Date().toISOString()
					};
					response = await fetch(`${PUBLIC_API_URL}/users/create`, {
						method: 'POST',
						headers: {
							'Content-Type': 'application/json'
						},
						body: JSON.stringify(requestBdy)
					});
				} else {
					response = await fetch(`${PUBLIC_API_URL}/users/login`, {
						method: 'POST',
						headers: {
							'Content-Type': 'application/json'
						},
						body: JSON.stringify(requestBody)
					});
				}

				response = await response.json();
				if (response.user_id) {
					localStorage.setItem('mamun_user_id', response.user_id);
				} else {
					localStorage.removeItem('mamun_user_id');
					throw new Error(response);
				}

				return response;
			}
		} catch (err) {
			showStatusBanner.set(true);
			verifySuccess.set(false);
			console.error('Error:', err);
			error.set('Network error. Please try again later.');
			throw err;
		} finally {
			loading.set(false);
		}
	}
</script>

{#if $showStatusBanner}
	<div class="mb-4 flex space-x-4 p-1 bg-white rounded-lg shadow-md">
		<div
			class="flex flex-row w-full bg-green-600 rounded-md text-white items-center justify-center"
			class:bg-green-600={$verifySuccess}
			class:bg-red-600={!$verifySuccess}
		>
			{#if $verifySuccess}
				<svg
					xmlns="http://www.w3.org/2000/svg"
					fill="none"
					viewBox="0 0 24 24"
					stroke-width="1.5"
					stroke="currentColor"
					class="size-6"
				>
					<path
						stroke-linecap="round"
						stroke-linejoin="round"
						d="M9 12.75 11.25 15 15 9.75m-3-7.036A11.959 11.959 0 0 1 3.598 6 11.99 11.99 0 0 0 3 9.749c0 5.592 3.824 10.29 9 11.623 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.285Z"
					/>
				</svg>
				<span class="p-2">{translateFunction('verified_success_msg')}</span>
			{:else}
				<svg
					xmlns="http://www.w3.org/2000/svg"
					fill="none"
					viewBox="0 0 24 24"
					stroke-width="1.5"
					stroke="currentColor"
					class="size-6"
				>
					<path
						stroke-linecap="round"
						stroke-linejoin="round"
						d="M12 9v3.75m0-10.036A11.959 11.959 0 0 1 3.598 6 11.99 11.99 0 0 0 3 9.75c0 5.592 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.57-.598-3.75h-.152c-3.196 0-6.1-1.25-8.25-3.286Zm0 13.036h.008v.008H12v-.008Z"
					/>
				</svg>
				<span class="p-2">{translateFunction('verified_failed_msg')}</span>
			{/if}
		</div>
	</div>
{/if}
{#if !$verifySuccess}
	<div class="mb-4 flex space-x-4 p-2 bg-white rounded-lg shadow-md">
		<button
			type="button"
			on:click={() => {
				showNid.set(!$showNid);
				showBreg.set(false);
			}}
			class="flex-1 py-2 px-4 rounded-md transition-all duration-300"
			class:bg-blue-600={$showNid}
			class:text-white={$showNid}>{translateFunction('auth.nid_number')}</button
		>
		<button
			type="button"
			on:click={() => {
				showBreg.set(!$showBreg);
				showNid.set(false);
			}}
			class="flex-1 py-2 px-4 rounded-md transition-all duration-300"
			class:bg-blue-600={$showBreg}
			class:text-white={$showBreg}>{translateFunction('auth.birth_reg_num')}</button
		>
	</div>

	<div class="transition-all duration-300 bg-white p-4 rounded-lg shadow-md border mb-4">
		<form on:submit|preventDefault={handleLogin}>
			{#if $showBreg}
				<div class="mb-5">
					<label for="birth_regid" class="mb-3 block text-base font-medium text-[#07074D]">
						{translateFunction('auth.birth_registration_num')}
					</label>
					<input
						required
						type="text"
						name="birth_regid"
						id="birth_regid"
						bind:value={$bRegidNumber}
						placeholder={translateFunction('auth.birth_reg_num')}
						class="w-full rounded-md transition border border-[#e0e0e0] bg-white py-3 px-6 text-base font-medium text-[#6B7280] outline-none focus:border-[#6A64F1] focus:shadow-md"
					/>
				</div>

				<div class="mb-5">
					<div class="flex flex-row">
						<div class="w-full">
							<label for="phone_number" class="mb-3 block text-base font-medium text-[#07074D]">
								{translateFunction('auth.birthday')}
							</label>

							<input
								bind:value={$Dob}
								type="date"
								id="dob"
								class="w-full rounded-lg border border-[#e0e0e0] px-4 py-2 text-gray-700 focus:ring-blue-500 transition"
								required
								min="1924-12-31"
								max="2024-12-31"
							/>
						</div>
					</div>
				</div>
			{:else}
				<div class="mb-5">
					<label for="nid_number" class="mb-3 block text-base font-medium text-[#07074D]">
						{translateFunction('auth.nid_number')}
					</label>
					<input
						required
						type="text"
						name="nid_number"
						id="nid_number"
						bind:value={$nidNumber}
						placeholder={translateFunction('auth.nid_number')}
						class="w-full rounded-md transition border border-[#e0e0e0] bg-white py-3 px-6 text-base font-medium text-[#6B7280] outline-none focus:border-[#6A64F1] focus:shadow-md"
					/>
				</div>

				<div class="mb-5">
					<div class="flex flex-row">
						<div class="w-full">
							<label for="phone_number" class="mb-3 block text-base font-medium text-[#07074D]">
								{translateFunction('auth.phone_number')}
							</label>
							<input
								required
								type="text"
								name="number"
								id="phone_number"
								bind:value={$nidPhoneNumber}
								placeholder={translateFunction('auth.phone_number')}
								class="w-full rounded-md transition border border-[#e0e0e0] bg-white py-3 px-6 text-base font-medium text-[#6B7280] outline-none focus:border-[#6A64F1] focus:shadow-md"
							/>
							<p class="ml-1 mt-2 text-xs text-gray-600">
								{translateFunction('auth.phone_number_requirement')}
							</p>
						</div>
						<div class="px-2 w-32">
							<label for="otp_number" class="mb-3 block text-base font-medium text-[#07074D]">
								{translateFunction('auth.otp')}
							</label>
							<input
								required
								type="text"
								name="otp_number"
								id="otp_number"
								bind:value={$otp}
								placeholder={translateFunction('auth.otp')}
								class="w-full rounded-md transition border border-[#e0e0e0] bg-white py-3 pl-4 text-base font-medium text-[#6B7280] focus:border-[#6A64F1] focus:shadow-md"
							/>
						</div>
					</div>
				</div>
			{/if}

			<div class="flex items-center justify-center mt-4">
				<button
					type="submit"
					class="flex w-full items-center justify-center rounded-lg bg-blue-500 px-4 py-2 text-white hover:bg-blue-600 focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50"
				>
					<svg
						class:block={$loading}
						class:hidden={!$loading}
						class="h-5 w-5 animate-spin text-white"
						xmlns="http://www.w3.org/2000/svg"
						fill="none"
						viewBox="0 0 24 24"
					>
						<circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"
						></circle>
						<path
							class="opacity-75"
							fill="currentColor"
							d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
						></path>
					</svg>
					<span class="ml-2">
						{translateFunction('auth.verify')}
					</span>
				</button>
			</div>
		</form>
	</div>
{/if}
