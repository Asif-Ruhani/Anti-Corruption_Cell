<script lang="ts">
	import { setLanguage } from '$lib/translate';
	import { onMount } from 'svelte';

	let selectedLanguage: string = 'bn';

	onMount(() => {
		selectedLanguage = localStorage.getItem('lang_code') || 'bn';
		setLanguage(selectedLanguage);
	});

	function toggleLanguage() {
		selectedLanguage = selectedLanguage === 'en' ? 'bn' : 'en';
		localStorage.setItem('lang_code', selectedLanguage);
		setLanguage(selectedLanguage);
	}
</script>

<!-- Language Toggle Button -->
<div class="inline-block">
	<button on:click={toggleLanguage} class="w-14 py-2">
		{#if selectedLanguage === 'en'}
			<svg class="h-8 rounded-lg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 480">
				<path fill="#00247d" d="M0 0h640v480H0z" />
				<path fill="#fff" d="M75 0h150v480H75zM0 165h640v150H0z" />
				<path fill="#cf142b" d="M100 0h100v480H100zM0 190h640v100H0z" />
			</svg>
		{:else}
			<svg class="h-8 rounded-lg" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 640 480">
				<path fill="#006a4e" d="M0 0h640v480H0z" />
				<circle cx="280" cy="240" r="160" fill="#f42a41" />
			</svg>
		{/if}
	</button>
</div>
