<script lang="ts">
	import { enhance } from '$app/forms';
	import { translate } from '$lib/translate';
	import { onDestroy } from 'svelte';
	import { isLoggedIn } from '../../stores/auth';
	import { goto } from '$app/navigation';

	let translateFunction = (key: string) => key;
	const unsubscribe = translate.subscribe((fn) => {
		translateFunction = fn;
	});

	onDestroy(() => {
		unsubscribe();
	});

	let loading: boolean;
	export let isGeneralUser: boolean;
	export let message: string;
	export let error: string;
	export let handleSubmit: () => Promise<Response>;

	async function handleResponse(response: Response) {
		if (response.ok) {
			const data = await response.json();

			localStorage.setItem('user_logged_in', 'true');
			localStorage.setItem('user_id', data.user_id);
			localStorage.setItem('role_id', data.role_id);
			isLoggedIn.set(true);

			window.location.href = '/dashboard';
			message = 'Success!';
			error = '';
		} else {
			isLoggedIn.set(false);
			localStorage.removeItem('user_logged_in');
			localStorage.removeItem('role_id');
			localStorage.removeItem('user_id');

			const errorData = await response.json();
			error = errorData.detail || 'An error occurred';

			message = '';
		}
	}

	async function submitHandler() {
		try {
			loading = true;
			const response = await handleSubmit();
			await handleResponse(response);
		} catch (exception) {
			console.error(exception);
		} finally {
			loading = false;
		}
	}
</script>

<div class="auth-login mt-2 flex items-center justify-center bg-gray-50 md:mt-20">
	<div class="w-full max-w-sm rounded-lg bg-white p-8 shadow-lg">
		<div class="mb-6 flex justify-center">
			<span class="inline-block rounded-full bg-gray-200 p-2">
				<svg
					class="h-16 w-16 text-gray-800"
					aria-hidden="true"
					xmlns="http://www.w3.org/2000/svg"
					width="48"
					height="48"
					fill="currentColor"
					viewBox="0 0 24 24"
				>
					<path
						fill-rule="evenodd"
						d="M12 20a7.966 7.966 0 0 1-5.002-1.756l.002.001v-.683c0-1.794 1.492-3.25 3.333-3.25h3.334c1.84 0 3.333 1.456 3.333 3.25v.683A7.966 7.966 0 0 1 12 20ZM2 12C2 6.477 6.477 2 12 2s10 4.477 10 10c0 5.5-4.44 9.963-9.932 10h-.138C6.438 21.962 2 17.5 2 12Zm10-5c-1.84 0-3.333 1.455-3.333 3.25S10.159 13.5 12 13.5c1.84 0 3.333-1.455 3.333-3.25S13.841 7 12 7Z"
						clip-rule="evenodd"
					/>
				</svg>
			</span>
		</div>
		<h1
			class="mb-6 text-center font-semibold"
			class:text-base={isGeneralUser}
			class:text-xl={!isGeneralUser}
		>
			{#if isGeneralUser}
				{translateFunction('auth.user.provide_login_info')}
			{:else}
				{translateFunction('auth.admin.provide_login_info')}
			{/if}
		</h1>
		<form on:submit|preventDefault={submitHandler}>
			<slot></slot>
			<div class="flex items-center justify-center">
				<button
					type="submit"
					class="flex w-full items-center justify-center rounded-lg bg-blue-500 px-4 py-2 text-white hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50"
				>
					<svg
						class:block={loading}
						class:hidden={!loading}
						class="h-5 w-5 animate-spin text-white"
						xmlns="http://www.w3.org/2000/svg"
						fill="none"
						viewBox="0 0 24 24"
					>
						<circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"
						></circle>
						<path
							class="opacity-75"
							fill="currentColor"
							d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
						></path>
					</svg>
					<span class="ml-2">
						{#if isGeneralUser}
							{translateFunction('auth.verify')}
						{:else}
							{translateFunction('auth.login')}
						{/if}
					</span>
				</button>
			</div>

			{#if message}
				<p class="text-green-500 text-center mt-4">{message}</p>
			{/if}

			{#if error}
				<p class="text-red-500 text-center mt-4">{error}</p>
			{/if}
		</form>
	</div>
</div>
