<script lang="ts">
	import { translate } from '$lib/translate';
	import { onDestroy } from 'svelte';

	export let title: string = 'Dashboard';
	let translateFunction = (key: string) => key;
	const unsubscribe = translate.subscribe((fn) => {
		translateFunction = fn;
	});

	onDestroy(() => {
		unsubscribe();
	});
</script>

<div class="border-b-2 mt-4 flex flex-row items-center px-6 pb-2 ml-auto">
	<div class="flex items-start">
		<span class="font-semibold text-2xl">{title}</span>
	</div>
	<div class="hidden">
		<div class="flex items-center ml-auto">
			<label for="show-count" class="text-slate-500 font-medium mr-2"
				>{translateFunction('show')}:</label
			>
			<select
				id="show-count"
				class="text-slate-500 hover:bg-slate-200 rounded-lg border-2 px-4 py-2 font-medium focus:outline-none focus:ring"
			>
				<option value="30">30</option>
				<option value="60">60</option>
				<option value="100">100</option>
			</select>
		</div>

		<div class="flex items-center ml-4">
			<label for="sort-by" class="text-slate-500 font-medium mr-2"
				>{translateFunction('sort_by')}:</label
			>
			<select
				id="sort-by"
				class="text-slate-500 hover:bg-slate-200 rounded-lg border-2 px-4 py-2 font-medium focus:outline-none focus:ring"
			>
				<option value="last-month">Last Hour</option>
				<option value="last-2-months">Last Day</option>
				<option value="this-year">Last 3 days</option>
			</select>
		</div>
	</div>
</div>
