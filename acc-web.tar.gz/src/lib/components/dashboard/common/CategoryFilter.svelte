<script lang="ts">
	import { translate } from '$lib/translate';
	import { loadCategories, loadCities } from '$lib/utils/fetchUtils';
	import { onDestroy, onMount } from 'svelte';
	import { filters } from '../../../../stores/filter';

	let translateFunction = (key: string) => key;
	const unsubscribe = translate.subscribe((fn) => {
		translateFunction = fn;
	});

	onDestroy(() => {
		unsubscribe();
	});

	export let showStatusFilter = true;
	const statuses = ['Pending', 'Processing', 'Solved', 'Rejected'];
	let categories = [{ cat_name: 'Extortion', cat_id: 1 }];
	let cities = ['Dhaka'];

	onMount(async () => {
		categories = await loadCategories();
		cities = await loadCities();
	});
</script>

<div class="px-4 flex flex-col min-w-[24vh]">
	<div class="flex flex-col">
		<h2 class="text-lg font-medium mt-4 mb-2">{translateFunction('status')}</h2>
		<div class="flex flex-col mb-2">
			<select
				bind:value={$filters.status}
				class="text-slate-500 hover:bg-slate-200 rounded-lg border-2 px-4 py-2 font-medium focus:outline-none focus:ring"
			>
				<option value="">{translateFunction('all')}</option>
				{#each statuses as status}
					<option value={status.toLocaleLowerCase()}
						>{translateFunction(status.toLocaleLowerCase())}</option
					>
				{/each}
			</select>
		</div>

		<h2 class="text-lg font-medium mt-4 mb-2">{translateFunction('location')}</h2>
		<div class="flex flex-col mb-2">
			<select
				bind:value={$filters.city}
				class="text-slate-500 hover:bg-slate-200 rounded-lg border-2 px-4 py-2 font-medium focus:outline-none focus:ring"
			>
				<option value="">{translateFunction('all')}</option>
				{#each cities as city}
					<option value={city}>{translateFunction(city.toLocaleLowerCase())}</option>
				{/each}
			</select>
		</div>

		<h2 class="text-lg font-medium mt-4 mb-2">{translateFunction('category')}</h2>
		<div class="flex flex-col mb-4">
			<select
				bind:value={$filters.cat_id}
				class="text-slate-500 hover:bg-slate-200 rounded-lg border-2 px-4 py-2 font-medium focus:outline-none focus:ring"
			>
				<option value="">{translateFunction('all')}</option>
				{#each categories as category}
					<option value={category.cat_id}
						>{translateFunction(category.cat_name.toLocaleLowerCase().replaceAll(' ', '_'))}</option
					>
				{/each}
			</select>
		</div>
	</div>
</div>
