<script>
	const containerClass = 'pb-2 mb-2';
</script>

<div class={containerClass}>
	<div class="flex">
		<div class="relative overflow-y-auto lg:h-[85vh] md:h-[75vh]">
			<slot></slot>
		</div>
	</div>
</div>
