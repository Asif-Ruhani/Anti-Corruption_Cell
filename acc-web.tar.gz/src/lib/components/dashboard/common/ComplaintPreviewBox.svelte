<script lang="ts">
	import { goto } from '$app/navigation';
	import { translate, langCode } from '$lib/translate';
	import { formatDate } from '$lib/utils/dateUtils';
	import { onDestroy } from 'svelte';

	let translateFunction = (key: string) => key;
	const unsubscribe = translate.subscribe((fn) => {
		translateFunction = fn;
	});

	onDestroy(() => {
		unsubscribe();
	});

	function shortenCityName(cityName: string): string {
		if (cityName === undefined) return '';

		const cityMap: Record<string, string> = {
			Dhaka: 'DHK',
			Chattogram: 'CTG',
			Sylhet: 'SLH',
			Rajshahi: 'RAJ',
			Khulna: 'KHU',
			Barishal: 'BAR',
			Rangpur: 'RNG',
			Mymensingh: 'MYM',
			Bogura: 'BGR',
			Comilla: 'CML',
			Narayanganj: 'NYN',
			Narsingdi: 'NSD',
			Jessore: 'JSR',
			Pabna: 'PBN',
			Tangail: 'TGL',
			Dinajpur: 'DNJ'
		};

		return cityMap[cityName] || cityName.trim().slice(0, 3).toUpperCase();
	}

	const categories = {
		'1': {
			cat_name: 'Extortion'
		},
		'2': {
			cat_name: 'Embezzlement'
		},
		'3': {
			cat_name: 'Bureaucracy'
		},
		'4': {
			cat_name: 'Nepotism'
		},
		'5': {
			cat_name: 'Fraud'
		},
		'6': {
			cat_name: 'Others'
		},
		'7': {
			cat_name: 'Bribery'
		},
		'8': {
			cat_name: 'Money Laundering'
		},
		'9': {
			cat_name: 'Tax Evasion'
		},
		'10': {
			cat_name: 'Corruption'
		}
	};

	export let userId: any = -1;
	export let roleName: string = 'user';

	export let shortPreview: boolean;
	export let isGeneralUser: boolean;

	export let complaintObj: any = {};
	export let complaintCity: string;
	export let complaintId: number;
	export let complaintDesc: string;
	export let complaintCatId: string;
	export let complaintDateTime: string;
	export let complaintStatus: string;

	let catName = 'Others';
	try {
		catName = categories[complaintCatId].cat_name;
	} catch (err) {
		console.error(err);
	}

	function handleClick() {
		goto(`/complaints/${complaintId}`);
	}
</script>

<div
	class="border border-green-400 mx-2 h-full rounded-md mt-1 transition flex flex-col justify-between"
	class:hover:shadow-xl={!shortPreview}
	class:shadow-md={!shortPreview}
	class:my-2={shortPreview}
	class:my-4={!shortPreview}
	class:w-[96%]={!shortPreview}
	class:w-72={shortPreview}
	class:min-h-72={!shortPreview}
	class:min-h-50={shortPreview}
>
	<div
		class="bg-[rgba(0,128,0,0.664)] text-white flex w-full items-center justify-center font-semibold"
		class:text-base={shortPreview}
		class:text-lg={!shortPreview}
		class:h-14={!shortPreview}
		class:h-10={shortPreview}
	>
		<h3>{shortenCityName(complaintCity)} - {complaintId}</h3>
	</div>
	<p
		class="m-2"
		class:line-clamp-6={!shortPreview}
		class:line-clamp-4={shortPreview}
		class:text-sm={shortPreview}
		class:text-base={!shortPreview}
	>
		{complaintDesc}
	</p>
	<div class="mb-2">
		<span
			class="ml-2 w-fit rounded-lg border-gray-200 font-semibold p-2 text-white"
			class:text-xs={shortPreview}
			class:text-sm={!shortPreview}
			class:bg-indigo-500={complaintStatus.toLocaleLowerCase() === 'pending'}
			class:bg-orange-500={complaintStatus.toLocaleLowerCase() === 'processing'}
			class:bg-green-500={complaintStatus.toLocaleLowerCase() === 'solved'}
			class:bg-red-500={complaintStatus.toLocaleLowerCase() === 'rejected'}
			>{translateFunction(complaintStatus.toLocaleLowerCase())}</span
		>
		<span
			class="w-fit rounded-lg border-gray-200 bg-slate-300 p-2 font-semibold"
			class:text-xs={shortPreview}
			class:text-sm={!shortPreview}
			class:ml-2={isGeneralUser}
			>{translateFunction(
				categories[complaintCatId]?.cat_name?.toLocaleLowerCase().replaceAll(' ', '_') || 'others'
			)}</span
		>
	</div>
	<div>
		<span
			class="w-fit rounded-lg border-gray-200 bg-gray-200 p-2 ml-2 font-semibold"
			class:text-xs={shortPreview}
			class:text-sm={!shortPreview}>{formatDate(complaintDateTime, $langCode)}</span
		>
	</div>
	<button
		on:click={handleClick}
		class="mx-auto bg-[rgba(0,128,0,0.664)] hover:bg-[rgba(0,128,0,0.774)] transition text-white border-none rounded-md"
		class:text-base={!shortPreview}
		class:text-sm={shortPreview}
		class:w-24={!shortPreview}
		class:w-20={shortPreview}
		class:h-10={!shortPreview}
		class:h-8={shortPreview}
		class:m-4={!shortPreview}
		class:m-2={shortPreview}
	>
		{#if roleName === 'user'}
			{translateFunction('see_more')}

			<!-- {#if complaintStatus.toLocaleLowerCase() === 'pending'}
				{translateFunction('manage')}
			{:else}
				{translateFunction('see_more')}
			{/if} -->
		{:else}
			{translateFunction('manage')}
		{/if}
	</button>
</div>
