<script>
	import { onDestroy, onMount } from 'svelte';
	import { PUBLIC_API_URL } from '$env/static/public';
	import { translate } from '$lib/translate';
	import { genUserStartChart } from '$lib/utils/chartUtils';

	let translateFunction = (key) => key;
	const unsubscribe = translate.subscribe((fn) => {
		translateFunction = fn;
	});

	onDestroy(() => {
		unsubscribe();
	});

	let chartContainer;

	onMount(async () => {
		const Complaints = {
			Rejected: 0,
			Pending: 0,
			Solved: 0,
			Processing: 0
		};

		const response = await fetch(
			`${PUBLIC_API_URL}/complaints/stats?user_id=${localStorage.getItem('user_id')}`
		);

		if (response.ok) {
			let complaints = await response.json();
			Complaints.Pending = complaints.statuses.pending;
			Complaints.Rejected = complaints.statuses.rejected;
			Complaints.Solved = complaints.statuses.solved;
			Complaints.Processing = complaints.statuses.processing;
		} else {
			console.error('Failed to load complaints');
		}

		if (chartContainer) {
			const ctx = chartContainer.getContext('2d');
			genUserStartChart(ctx, Complaints);
		}
	});
</script>

<div class="flex flex-col h-[40vh] pt-4">
	<h2 class="font-semibold text-xl text-center pt-2">{translateFunction('statistics')}</h2>
	<div class="flex-grow p-2">
		<canvas bind:this={chartContainer}></canvas>
	</div>
</div>
