<script lang="ts">
	import { langCode, translate } from '$lib/translate';
	import { onDestroy, onMount } from 'svelte';
	import CategoryFilter from '../common/CategoryFilter.svelte';
	import ComplaintList from '../common/ComplaintList.svelte';
	import ComplaintPreview from '../common/ComplaintPreviewBox.svelte';
	import SortFilter from '../common/SortFilter.svelte';
	import UserStats from './UserStats.svelte';
	import { PUBLIC_API_URL } from '$env/static/public';
	import { filters } from '../../../../stores/filter';
	import { writable } from 'svelte/store';

	const isGeneralUser: boolean = true;
	const shortPreview: boolean = false;
	let solvedProblems: string = '25';

	const complaints = writable([]);
	async function fetchComplaints(filters) {
		try {
			const params = new URLSearchParams(
				Object.entries(filters).filter(([_, value]) => value !== null && value !== '')
			);

			params.set('user_id', localStorage.getItem('user_id') || '-1');

			const response = await fetch(`${PUBLIC_API_URL}/complaints?${params}`);

			if (response.ok) {
				const data = await response.json();
				complaints.set(data);
			} else {
				complaints.set([]);
			}
		} catch (err) {
			console.error('Error fetching complaints:', err);
			complaints.set([]);
		}
	}

	let total_user = '';
	let total_solved = '';
	let total_solved_users = '';

	onMount(async () => {
		const response = await fetch(
			`${PUBLIC_API_URL}/complaints?user_id=${localStorage.getItem('user_id')}`
		);

		if (response.ok) {
			complaints.set(await response.json());
		} else {
			console.error('Failed to load complaints');
		}

		const rsponse = await fetch(`${PUBLIC_API_URL}/complaints/stats/all`);

		if (rsponse.ok) {
			const jsn = await rsponse.json();
			console.debug(jsn);
			total_user = jsn.users.total.toString() || '0';
			solvedProblems = jsn.complaints.solved || '0';
			total_solved_users = jsn.users.solved.toString() || '0';
		} else {
			console.error('Failed to load complaints');
		}
	});

	$: {
		const filterValues = $filters;
		fetchComplaints(filterValues);
	}

	let translateFunction = (key: string) => key;
	const unsubscribe = translate.subscribe((fn) => {
		translateFunction = fn;
	});

	onDestroy(() => {
		unsubscribe();
	});

	function translateEnNumToBnNum() {
		return solvedProblems
			.replaceAll('1', '১')
			.replaceAll('2', '২')
			.replaceAll('3', '৩')
			.replaceAll('4', '৪')
			.replaceAll('5', '৫')
			.replaceAll('6', '৬')
			.replaceAll('7', '৭')
			.replaceAll('8', '৮')
			.replaceAll('9', '৯')
			.replaceAll('0', '০');
	}

	function translateBnNumToEnNum() {
		return solvedProblems
			.replaceAll('১', '1')
			.replaceAll('২', '2')
			.replaceAll('৩', '3')
			.replaceAll('৪', '4')
			.replaceAll('৫', '5')
			.replaceAll('৬', '6')
			.replaceAll('৭', '7')
			.replaceAll('৮', '8')
			.replaceAll('৯', '9')
			.replaceAll('০', '0');
	}
</script>

<SortFilter title={translateFunction('user_dashboard')} />
<div class="flex h-screen">
	<!-- Left Sidebar / Filter -->
	<div class="border-r-2 h-full">
		<CategoryFilter showStatusFilter={false} />
	</div>

	<!-- Center Container for Complaints List -->
	<div class="flex-grow overflow-y-auto">
		<ComplaintList>
			<div
				class="sticky top-0 grid lg:grid-cols-4 md:grid-cols-3 gap-y-4 w-full justify-items-center pb-8"
			>
				{#if $complaints.length !== 0}
					{#each $complaints as complaint}
						<ComplaintPreview
							{shortPreview}
							{isGeneralUser}
							complaintCity={complaint.city_id}
							complaintId={complaint.complaint_id}
							complaintDesc={complaint.description}
							complaintCatId={complaint.cat_id}
							complaintDateTime={complaint.created_at}
							complaintStatus={complaint.status}
						/>
					{/each}
				{:else}
					<div class="mx-auto w-screen p-8">
						<span class="text-4xl">{translateFunction('no_complaints_found')}</span>
					</div>
				{/if}
			</div>
		</ComplaintList>
	</div>

	<!-- Right Container for User Stats -->
	<div class="border-l flex-col">
		<div class="border-b border-gray-300 py-2 text-center">
			<div class="flex flex-col h-[35vh] justify-center items-center">
				<span class="font-semibold text-2xl px-2">
					{#if $langCode === 'en'}
						We have solved over<br />
						<p class="text-5xl text-green-600 py-4">{solvedProblems}</p>
						complaints so far
					{:else}
						এখন পর্যন্ত আমরা<br />
						<p class="text-5xl text-green-600 py-4">{translateEnNumToBnNum()}</p>
						এর বেশি অভিযোগ সমাধান করেছি
					{/if}
				</span>
				<!-- <span class="font-semibold text-2xl pb-10">47 complaints</span> -->
			</div>
			<!-- <img src="/images/asif.jpg" class="w-96" /> -->
			<!-- <UserRecentComplaints /> -->
		</div>
		<div class="flex-col justify-center items-center">
			<UserStats />
		</div>
	</div>
</div>
