<script lang="ts">
	import { onDestroy, onMount } from 'svelte';
	import ComplaintPreview from '../common/ComplaintPreviewBox.svelte';
	import { PUBLIC_API_URL } from '$env/static/public';
	import { translate } from '$lib/translate';
	import { goto } from '$app/navigation';

	const isGeneralUser: boolean = false;
	const shortPreview: boolean = true;

	let complaints = Array(12).fill({
		id: 'DHK-1211',
		status: 'processing',
		desc: "Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.",
		dateTime: 'Nov 5, 2024 05:30PM'
	});

	onMount(async () => {
		const response = await fetch(
			`${PUBLIC_API_URL}/complaints?user_id=${localStorage.getItem('user_id')}`
		);

		if (response.ok) {
			complaints = await response.json();
		} else {
			console.error('Failed to load complaints');
		}
	});

	let translateFunction = (key: string) => key;
	const unsubscribe = translate.subscribe((fn) => {
		translateFunction = fn;
	});

	onDestroy(() => {
		unsubscribe();
	});

	const goToComplaints = () => {
		goto('/complaints/my');
	};
</script>

<div class="flex flex-col">
	<h2 class="font-semibold text-xl text-center pt-2">{translateFunction('recent_complaints')}</h2>
	<span class="text-center">
		(<button on:click={goToComplaints} class="hover:underline">
			{translateFunction('view_all')}
		</button>)
	</span>
	<div class="overflow-y-auto grid grid-cols-1 gap-2 h-[35vh] max:h-[40vh]">
		{#each complaints as complaint}
			<ComplaintPreview
				{shortPreview}
				{isGeneralUser}
				complaintCity={complaint.city}
				complaintId={complaint.complaint_id}
				complaintDesc={complaint.desc}
				complaintCatId={complaint.cat_id}
				complaintDateTime={complaint.created_at}
				complaintStatus={complaint.status}
			/>
		{/each}
	</div>
</div>
