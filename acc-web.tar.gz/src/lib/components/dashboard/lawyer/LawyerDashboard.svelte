<script lang="ts">
	import { onDestroy, onMount } from 'svelte';
	import { PUBLIC_API_URL } from '$env/static/public';
	import CategoryFilter from '../common/CategoryFilter.svelte';
	import ComplaintList from '../common/ComplaintList.svelte';
	import ComplaintPreview from '../common/ComplaintPreviewBox.svelte';
	import SortFilter from '../common/SortFilter.svelte';
	import { writable } from 'svelte/store';
	import { filters } from '../../../../stores/filter';
	import { translate } from '$lib/translate';

	let translateFunction = (key: string) => key;
	const unsubscribe = translate.subscribe((fn) => {
		translateFunction = fn;
	});

	onDestroy(() => {
		unsubscribe();
	});

	export let isRejectedList = false;

	let shortPreview: boolean = false;
	let roleId = writable('');
	const dashboardTitle = writable('');
	const isGeneralUser: boolean = false;

	const complaints = writable([]);

	async function fetchComplaints(filters) {
		try {
			const params = new URLSearchParams(
				Object.entries(filters).filter(([_, value]) => value !== null && value !== '')
			);

			console.debug('fetchComplaints: ' + $roleId);

			if ($roleId === 'regulatory') {
				if (params.get('status') === 'pending' || params.get('status') === 'processing') {
					params.set('status', 'pending');
				} else if (params.get('status') === null) {
					params.set('status', 'pending');
				}
			} else if ($roleId === 'admin') {
				if (params.get('status') === 'processing') {
					params.set('status', 'processing');
				} else if (params.get('status') === null) {
					params.set('status', 'processing');
				}
			} else if (($roleId === 'admin' || $roleId === 'regulatory') && isRejectedList) {
				params.set('status', 'rejected');
			} else {
				return;
			}

			const response = await fetch(`${PUBLIC_API_URL}/complaints?${params.toString()}`);

			if (response.ok) {
				const data = await response.json();
				complaints.set(data);
			} else {
				complaints.set([]);
			}
		} catch (err) {
			console.error('Error fetching complaints:', err);
			complaints.set([]);
		}
	}

	onMount(async () => {
		let response;

		const storedRoleId = localStorage.getItem('role_id') || 'regulatory';
		roleId.set(storedRoleId);

		if ($roleId === 'regulatory' && !isRejectedList) {
			dashboardTitle.set('regulatory_dashboard');
			response = await fetch(`${PUBLIC_API_URL}/complaints?status=pending`);
		} else if ($roleId === 'admin' && !isRejectedList) {
			dashboardTitle.set('admin_dashboard');
			response = await fetch(`${PUBLIC_API_URL}/complaints?status=processing`);
		} else if (isRejectedList) {
			response = await fetch(`${PUBLIC_API_URL}/complaints?status=rejected`);
		}

		if (response.ok) {
			complaints.set(await response.json());
		} else {
			console.error('Failed to load complaints');
		}
	});

	$: {
		const x = $roleId;
		const filterValues = $filters;
		fetchComplaints(filterValues);
	}
</script>

<SortFilter title={translateFunction($dashboardTitle)} />

<div class="flex h-screen">
	<!-- Left Sidebar / Filter -->
	<div class="border-r-2 h-full">
		<CategoryFilter />
	</div>

	<!-- Right Container for Complaints List -->
	<div class="flex-grow overflow-y-auto">
		<ComplaintList>
			<div
				class="sticky top-0 grid lg:grid-cols-4 md:grid-cols-3 gap-y-4 w-full justify-items-center pb-8"
			>
				{#if $complaints.length !== 0}
					{#each $complaints as complaint}
						<ComplaintPreview
							roleName={'admin'}
							{shortPreview}
							{isGeneralUser}
							complaintCity={complaint.city}
							complaintId={complaint.complaint_id}
							complaintDesc={complaint.desc}
							complaintCatId={complaint.cat_id}
							complaintDateTime={complaint.created_at}
							complaintStatus={complaint.status}
						/>
					{/each}
				{:else}
					<div class="mx-auto w-screen p-8">
						<span class="text-4xl">{translateFunction('no_complaints_found')}</span>
					</div>
				{/if}
			</div>
		</ComplaintList>
	</div>
</div>
