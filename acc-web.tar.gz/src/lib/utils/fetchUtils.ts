import { PUBLIC_API_URL } from '$env/static/public';

export const loadCategories = async () => {
	try {
		const response = await fetch(PUBLIC_API_URL + '/categories/');
		if (response.ok) {
			return await response.json();
		} else {
			console.error('Failed to load categories');
		}
	} catch (error) {
		console.error('Error fetching categories:', error);
	}

	return [''];
};

export const loadCities = async () => {
	try {
		const response = await fetch(PUBLIC_API_URL + '/complaints/city/');
		if (response.ok) {
			return await response.json();
		} else {
			console.error('Failed to load categories');
		}
	} catch (error) {
		console.error('Error fetching categories:', error);
	}

	return [''];
};

export async function updateComplaintStatus(
	complaintId: number,
	status: string
): Promise<{ message: string }> {
	try {
		const response = await fetch(
			`${PUBLIC_API_URL}/complaints/update?complaint_id=${complaintId}&status=${status}`,
			{
				method: 'PUT',
				headers: {
					'Content-Type': 'application/json'
				},
				body: JSON.stringify({ status })
			}
		);

		if (!response.ok) {
			const errorData = await response.json();
			throw new Error(errorData.detail || 'Failed to update complaint status');
		}

		const data = await response.json();
		return data;
	} catch (error) {
		console.error('Error updating complaint status:', error);
		throw error;
	}
}
