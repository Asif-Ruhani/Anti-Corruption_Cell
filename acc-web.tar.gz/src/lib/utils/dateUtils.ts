export function formatDate(timestamp: string, langKey: string = 'en'): string {
	const date = new Date(timestamp);

	const locale = langKey == 'bn' ? 'bn-BD' : 'en-US';

	return date.toLocaleString(locale, {
		weekday: 'short',
		month: 'short',
		day: 'numeric',
		year: 'numeric',
		hour: '2-digit',
		minute: '2-digit',
		hour12: false
	});
}
