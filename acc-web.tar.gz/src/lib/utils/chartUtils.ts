import {
	Chart,
	CategoryScale,
	LinearScale,
	Title,
	Tooltip,
	Legend,
	BarController,
	BarElement
} from 'chart.js';

export function genUserStartChart(ctx, Complaints) {
	Chart.register(CategoryScale, LinearScale, Title, Tooltip, Legend, BarController, BarElement);

	const Colors = {
		LightRed: '#ff4d4d',
		LimeGreen: '#4caf50',
		VividBlue: '#2196f3',
		Orange: '#ff9800'
	};

	new Chart(ctx, {
		type: 'bar',
		data: {
			labels: ['Rejected', 'Pending', 'Processing', 'Solved'],
			datasets: [
				{
					label: 'Complaint Status',
					data: [Complaints.Rejected, Complaints.Pending, Complaints.Processing, Complaints.Solved],
					backgroundColor: [Colors.LightRed, Colors.VividBlue, Colors.Orange, Colors.LimeGreen],
					borderWidth: 1
				}
			]
		},

		options: {
			responsive: true,
			maintainAspectRatio: false,
			scales: {
				x: {
					title: {
						display: true
					}
				},
				y: {
					title: {
						display: true,
						text: 'Number of Complaints'
					},
					beginAtZero: true,
					ticks: {
						stepSize: 1
					}
				}
			}
		}
	});
}
