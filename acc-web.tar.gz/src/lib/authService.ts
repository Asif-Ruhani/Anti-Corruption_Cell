interface SignUpCredentials {
	email: string;
	password: string;
	confirmPassword: string;
}

interface LoginCredentials {
	email: string;
	password: string;
}

const MOCK_USERS_DB = new Map<string, { email: string; password: string }>();

export async function signUpUser({ email, password, confirmPassword }: SignUpCredentials) {
	if (password !== confirmPassword) {
		return { success: false, message: 'Passwords do not match' };
	}

	if (MOCK_USERS_DB.has(email)) {
		return { success: false, message: 'Email is already registered' };
	}

	// Store user in mock database
	MOCK_USERS_DB.set(email, { email, password });

	// Return success with user data
	return {
		success: true,
		user: { email }
	};
}

export async function loginUser({ email, password }: LoginCredentials) {
	const user = MOCK_USERS_DB.get(email);

	if (!user || user.password !== password) {
		return { success: false, message: 'Invalid email or password' };
	}

	// Successful login
	return {
		success: true,
		user: { email }
	};
}
