import { writable, derived, get } from 'svelte/store';
import { language, type LanguageKey } from '../stores/language';
import en from '../translations/en.json';
import bn from '../translations/bn.json';

type Translations = { [key: string]: string };

const translationsMap: { [key in string]: Translations } = {
	en,
	bn
};

export const currentTranslations = writable<Translations>(translationsMap['en']);
export const langCode = writable<string>('en');

export const setLanguage = (lngCode: string) => {
	langCode.set(lngCode);
	language.set(lngCode);
};

export const translate = derived(currentTranslations, ($currentTranslations) => {
	return (key: string) => $currentTranslations[key] || key;
});

language.subscribe((langCode) => {
	currentTranslations.set(translationsMap[langCode]);
});
