export interface User {
	email: string;
	// other fields can be added here
}
