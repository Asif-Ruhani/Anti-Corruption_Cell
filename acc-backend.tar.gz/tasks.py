from invoke import task


@task
def install(c) -> None:
    """
    Install project dependencies using uv.
    """
    c.run("uv sync", pty=True)


@task
def dev(c) -> None:
    """
    Start the FastAPI development server
    """
    c.run("uv run fastapi dev --port 8001", pty=True)


@task
def lint(c) -> None:
    """
    Lint the codebase using ruff.
    """
    c.run("ruff check .", pty=True)


@task
def format(c) -> None:
    """
    Format the codebase using isort, black and ruff.
    """
    c.run("isort --profile black .", pty=True)
    c.run("ruff format .", pty=True)


@task
def clean(c) -> None:
    """
    Clean python debris
    """
    c.run("uv run pyclean .", pty=True)


@task
def test(c) -> None:
    """
    Run tests
    """
    c.run("python -m pytest tests", pty=True)
