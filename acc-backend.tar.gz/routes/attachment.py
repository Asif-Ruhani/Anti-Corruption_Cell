from datetime import datetime, timedelta
from pathlib import Path
from typing import List

from fastapi import APIRouter, Depends, File, HTTPException, Query, UploadFile
from fastapi.responses import JSONResponse
from sqlalchemy import asc, case, desc, func, update
from sqlalchemy.orm import Session, sessionmaker

from config.db import engine
from models.index import attachments, categories, complaints, users
from models.user import RoleEnum
from schemas.index import AttachmentCreate, AttachmentRead

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

attachment_router = APIRouter(prefix="/attachments", tags=["Attachments"])

UPLOAD_DIRECTORY = Path("uploads/")
UPLOAD_DIRECTORY.mkdir(exist_ok=True)


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# Add Attachment
# @attachment_router.post("/upload", response_model=AttachmentRead)
# async def upload_file(
#     complaint_id: int, file: UploadFile = File(...), db: Session = Depends(get_db)
# ):
#     file_location = UPLOAD_DIRECTORY / Path(file.filename).name
#     with open(file_location, "wb") as f:
#         f.write(await file.read())

#     stmt = attachments.insert().values(
#         complaint_id=complaint_id,
#         file_path=file_location,
#         file_type=file.content_type,
#     )

#     result = db.execute(stmt)
#     db.commit()

#     created_id = result.inserted_primary_key[0]
#     created_attachment = db.execute(
#         attachments.select().where(attachments.c.attachment_id == created_id)
#     ).fetchone()

#     return created_attachment


@attachment_router.post("/upload", response_model=List[AttachmentRead])
async def upload_files(
    complaint_id: int,
    files: List[UploadFile] = File(...),
    db: Session = Depends(get_db),
):
    uploaded_attachments = []
    print(files)

    for file in files:
        print(file)
        # Generate a safe file path to save the file
        file_location = UPLOAD_DIRECTORY / Path(file.filename).name

        # Save the file to the specified location
        with open(file_location, "wb") as f:
            f.write(await file.read())

        # Insert the file details into the database
        stmt = attachments.insert().values(
            complaint_id=complaint_id,
            file_path=str(file_location),  # Store the path as a string
            file_type=file.content_type,
        )
        result = db.execute(stmt)
        db.commit()

        created_id = result.inserted_primary_key[0]
        created_attachment = db.execute(
            attachments.select().where(attachments.c.attachment_id == created_id)
        ).fetchone()

        uploaded_attachments.append(created_attachment)

    return uploaded_attachments


# List Attachments
@attachment_router.get("/list", response_model=List[AttachmentRead])
def list_attachments(db: Session = Depends(get_db)):
    """Get all attachments."""
    result = db.execute(attachments.select()).fetchall()
    return result


# Get Attachment
@attachment_router.get("/complaint/{complaint_id}", response_model=List[AttachmentRead])
def get_attachments_by_complaint_id(complaint_id: int, db: Session = Depends(get_db)):
    """Get all attachments for a specific complaint ID."""
    attachments_list = db.execute(
        attachments.select().where(attachments.c.complaint_id == complaint_id)
    ).fetchall()

    if not attachments_list:
        return []

    return attachments_list


# Delete Attachment
@attachment_router.delete("/{attachment_id}", response_model=dict)
def delete_attachment(attachment_id: int, db: Session = Depends(get_db)):
    stmt = attachments.delete().where(attachments.c.attachment_id == attachment_id)
    result = db.execute(stmt)
    if result.rowcount == 0:
        raise HTTPException(status_code=404, detail="Attachment not found")
    db.commit()
    return {"message": "Attachment deleted successfully"}
