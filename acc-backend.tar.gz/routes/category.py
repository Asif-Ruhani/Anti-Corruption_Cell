from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session, sessionmaker

from config.db import engine
from models.index import categories
from schemas.index import CategoryCreate, CategoryRead

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

complaint_router = APIRouter()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


category_router = APIRouter(prefix="/categories", tags=["Categories"])


# Create Category
@category_router.post("/", response_model=CategoryRead)
def create_category(category: CategoryCreate, db: Session = Depends(get_db)):
    new_category = categories.insert().values(cat_name=category.cat_name)
    db.execute(new_category)
    db.commit()

    # Fetch the inserted category
    category_id = (
        db.execute(categories.select().filter_by(cat_name=category.cat_name))
        .fetchone()
        .cat_id
    )

    return {"cat_id": category_id, "cat_name": category.cat_name}


# Get All Categories
@category_router.get("/", response_model=list[CategoryRead])
def get_categories(db: Session = Depends(get_db)):
    categories_list = db.execute(categories.select()).fetchall()
    return [{"cat_id": row.cat_id, "cat_name": row.cat_name} for row in categories_list]


# Get Category by ID
@category_router.get("/categories/{cat_id}", response_model=CategoryRead)
def get_category(cat_id: int, db: Session = Depends(get_db)):
    category = db.execute(
        categories.select().where(categories.c.cat_id == cat_id)
    ).fetchone()
    if category is None:
        raise HTTPException(status_code=404, detail="Category not found")
    return {"cat_id": category.cat_id, "cat_name": category.cat_name}


# Update Category
@category_router.put("/categories/{cat_id}", response_model=CategoryRead)
def update_category(
    cat_id: int, category: CategoryCreate, db: Session = Depends(get_db)
):
    existing_category = db.execute(
        categories.select().where(categories.c.cat_id == cat_id)
    ).fetchone()
    if existing_category is None:
        raise HTTPException(status_code=404, detail="Category not found")

    update_query = (
        categories.update()
        .where(categories.c.cat_id == cat_id)
        .values(cat_name=category.cat_name)
    )
    db.execute(update_query)
    db.commit()

    return {"cat_id": cat_id, "cat_name": category.cat_name}


# Delete Category
@category_router.delete("/categories/{cat_id}", response_model=CategoryRead)
def delete_category(cat_id: int, db: Session = Depends(get_db)):
    category = db.execute(
        categories.select().where(categories.c.cat_id == cat_id)
    ).fetchone()
    if category is None:
        raise HTTPException(status_code=404, detail="Category not found")

    delete_query = categories.delete().where(categories.c.cat_id == cat_id)
    db.execute(delete_query)
    db.commit()

    return {"cat_id": cat_id, "cat_name": category.cat_name}
