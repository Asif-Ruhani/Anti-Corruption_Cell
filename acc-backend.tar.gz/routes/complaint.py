from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import asc, case, delete, desc, func, update
from sqlalchemy.orm import Session, sessionmaker

from config.db import engine
from models.complaint import ComplaintCity, ComplaintStatus
from models.index import attachments, categories, complaints, users, notifications
from models.user import RoleEnum
from schemas.index import ComplaintCreate, ComplaintRead

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

complaint_router = APIRouter(prefix="/complaints", tags=["Complaints"])


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# Get all cities
@complaint_router.get("/city", response_model=list)
async def get_complaint_cities():
    return [city.value for city in ComplaintCity]


# Create Complaint
@complaint_router.post("/create", response_model=ComplaintRead)
def create_complaint(complaint: ComplaintCreate, db: Session = Depends(get_db)):
    db_user = db.query(users).filter(users.c.user_id == complaint.user_id).first()
    if not db_user:
        raise HTTPException(status_code=400, detail="User not found")

    db_category = (
        db.query(categories).filter(categories.c.cat_id == complaint.cat_id).first()
    )
    if not db_category:
        raise HTTPException(status_code=400, detail="Category not found")

    new_complaint = complaints.insert().values(
        user_id=complaint.user_id,
        title=complaint.title,
        cat_id=complaint.cat_id,
        desc=complaint.desc,
        city=complaint.city,
        address=complaint.address,
        status=complaint.status,
        created_at=complaint.created_at,
        modified_at=complaint.modified_at,
    )

    result = db.execute(new_complaint)
    db.commit()

    complaint_id = result.inserted_primary_key[0]
    created_complaint = (
        db.query(complaints).filter(complaints.c.complaint_id == complaint_id).first()
    )

    return created_complaint


@complaint_router.put("/update", response_model=dict)
def update_status(
    status: ComplaintStatus,
    complaint_id: int = Query(None, description="The ID of the complaint to update"),
    db: Session = Depends(get_db),
):
    complaint = (
        db.query(complaints).filter(complaints.c.complaint_id == complaint_id).first()
    )

    if not complaint:
        raise HTTPException(status_code=404, detail="Complaint not found")

    query = (
        update(complaints)
        .where(complaints.c.complaint_id == complaint_id)
        .values(status=status)
    )

    db.execute(query)
    db.commit()

    
    message = f"status is changed from {complaint.status.value.upper()} to {status.value.upper()}"
    new_notif = notifications.insert().values(
            user_id=complaint.user_id,
            complaint_id=complaint_id,
            message=message
    )
    db.execute(new_notif)
    db.commit()

    return {"message": "complaint status updated successfully"}


@complaint_router.get("/stats", response_model=dict)
def get_complaint_stats(
    db: Session = Depends(get_db),
    user_id: int = Query(None, description="User ID to filter complaints by"),
):
    if not user_id:
        raise HTTPException(status_code=400, detail="User ID is required")

    stats_query = (
        db.query(
            func.count().label("total_complaints"),
            func.sum(case((complaints.c.status == "rejected", 1), else_=0)).label(
                "rejected"
            ),
            func.sum(case((complaints.c.status == "pending", 1), else_=0)).label(
                "pending"
            ),
            func.sum(case((complaints.c.status == "processing", 1), else_=0)).label(
                "processing"
            ),
            func.sum(case((complaints.c.status == "solved", 1), else_=0)).label(
                "solved"
            ),
        )
        .filter(complaints.c.user_id == user_id)
        .first()
    )

    if not stats_query or stats_query.total_complaints == 0:
        raise HTTPException(
            status_code=404, detail="No complaints found for the specified user"
        )

    return {
        "user_id": user_id,
        "total_complaints": stats_query.total_complaints,
        "statuses": {
            "rejected": stats_query.rejected,
            "pending": stats_query.pending,
            "processing": stats_query.processing,
            "solved": stats_query.solved,
        },
    }


# Get complaint by ID
@complaint_router.get("/{complaint_id}", response_model=ComplaintRead)
def get_complaint(complaint_id: int, db: Session = Depends(get_db)):
    db_complaint = (
        db.query(complaints).filter(complaints.c.complaint_id == complaint_id).first()
    )
    if db_complaint is None:
        raise HTTPException(status_code=404, detail="Complaint not found")
    return db_complaint


@complaint_router.get("/", response_model=list[ComplaintRead])
def list_complaints(
    status: ComplaintStatus | None = None,
    cat_id: int | None = None,
    city: str | None = None,
    user_id: int = Query(None, description="User ID to filter complaints by"),
    db: Session = Depends(get_db),
):
    query = complaints.select()

    if status:
        query = query.where(complaints.c.status == status)

    if user_id:
        current_user = db.query(users).filter(users.c.user_id == user_id).first()
        if current_user[1] == RoleEnum.user:
            query = query.where(complaints.c.user_id == current_user[0])

    if cat_id:
        query = query.where(complaints.c.cat_id == cat_id)
    if city:
        query = query.where(complaints.c.city == city)

    result = db.execute(query).fetchall()
    return result


# Delete


# Delete Complaint
@complaint_router.delete("/{complaint_id}", response_model=ComplaintRead)
def delete_complaint(complaint_id: int, db: Session = Depends(get_db)):
    # Check if the complaint exists
    complaint_to_delete = (
        db.query(complaints).filter(complaints.c.complaint_id == complaint_id).first()
    )

    if not complaint_to_delete:
        raise HTTPException(status_code=404, detail="Complaint not found")

    db.execute(delete(attachments).where(attachments.c.complaint_id == complaint_id))
    db.commit()

    # Delete the complaint
    db.execute(complaints.delete().where(complaints.c.complaint_id == complaint_id))
    db.commit()

    # Return the deleted complaint data (optional)
    return complaint_to_delete


@complaint_router.get("/stats/all", response_model=dict)
def get_complaint_stats(
    db: Session = Depends(get_db),
):
    stats_query = db.query(
        func.count().label("total_complaints"),
        func.sum(case((complaints.c.status == "rejected", 1), else_=0)).label(
            "rejected"
        ),
        func.sum(case((complaints.c.status == "pending", 1), else_=0)).label("pending"),
        func.sum(case((complaints.c.status == "processing", 1), else_=0)).label(
            "processing"
        ),
        func.sum(case((complaints.c.status == "solved", 1), else_=0)).label("solved"),
    ).first()

    solved_users_count = (
        db.query(func.count(func.distinct(complaints.c.user_id)))
        .filter(complaints.c.status == "solved")
        .scalar()
    )

    total_users = db.query(func.count(func.distinct(complaints.c.user_id))).scalar()

    if not stats_query or stats_query.total_complaints == 0:
        raise HTTPException(
            status_code=404, detail="No complaints found in the database"
        )

    return {
        "complaints": {
            "total": stats_query.total_complaints,
            "rejected": stats_query.rejected,
            "pending": stats_query.pending,
            "processing": stats_query.processing,
            "solved": stats_query.solved,
        },
        "users": {"total": total_users, "solved": solved_users_count},
    }
