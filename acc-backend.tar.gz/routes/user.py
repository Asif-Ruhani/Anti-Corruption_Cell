from datetime import datetime
from secrets import randbelow

from fastapi import APIRouter, Cookie, Depends, HTTPException, Response
from sqlalchemy import func, select, update
from sqlalchemy.orm import Session, sessionmaker

from config.db import breg_crt_engine, engine, nid_engine
from models.index import breg_cert_citizens, nid_citizens, users
from schemas.index import BregCertUser, NidUser, User, UserLogin, UserRead

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
nid_session_local = sessionmaker(autocommit=False, autoflush=False, bind=nid_engine)
breg_crt_session_local = sessionmaker(
    autocommit=False, autoflush=False, bind=breg_crt_engine
)


user_router = APIRouter(prefix="/users", tags=["Users"])


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


def is_above_18(datstr: str) -> bool:
    print(datstr)
    target_date = datetime.strptime(datstr, "%Y-%m-%d")
    current_year = datetime.now().year
    target_year = target_date.year

    year_difference = abs(target_year - current_year)

    return year_difference >= 18


# Dependency for NID DB
def get_nid_db():
    db = nid_session_local()
    try:
        yield db
    finally:
        db.close()


# Dependency for Birth Registration DB
def get_breg_db():
    db = breg_crt_session_local()
    try:
        yield db
    finally:
        db.close()


@user_router.get("/getId", response_model=UserRead)
def create_user(nid_num: int, db: Session = Depends(get_db)):
    db_user = db.query(users).filter(users.c.nid == nid_num).first()
    if not db_user:
        raise HTTPException(status_code=400, detail="user not registered")

    return db_user


@user_router.post("/login/admin", response_model=UserRead)
def create_user(username: str, password: str, db: Session = Depends(get_db)):
    db_user = db.query(users).filter(users.c.nid == username).first()
    if not db_user:
        raise HTTPException(status_code=400, detail="user not registered")

    return db_user


@user_router.post("/login", response_model=UserRead)
def login(
    user_login: UserLogin,
    db: Session = Depends(get_db),
    nid_db: Session = Depends(get_nid_db),
    breg_db: Session = Depends(get_breg_db),
):
   
    nid_num = 0

    if user_login.isNid:
        db_user = (
            nid_db.query(nid_citizens)
            .filter(nid_citizens.c.n_id == user_login.nid)
            .first()
        )
        if db_user:
            nid_num = db_user.n_id
    else:
        if not is_above_18(user_login.dob):
            raise HTTPException(status_code=404, detail="Must be at least 18 years old")

        db_user = (
            breg_db.query(breg_cert_citizens)
            .filter(
                breg_cert_citizens.c.birth_registration_number == user_login.bregNum,
                breg_cert_citizens.c.date_of_birth == user_login.dob,
            )
            .first()
        )
        if db_user:
            nid_num = db_user.birth_registration_number

    if db_user is None:
        raise HTTPException(status_code=404, detail="incorrect info provided")

    db_user = db.query(users).filter(users.c.nid == nid_num).first()
    if db_user is None:
        raise HTTPException(status_code=404, detail="User not found")

    if db_user.status != "active":
        raise HTTPException(status_code=401, detail="user is disabled")

    return db_user


@user_router.post("/create", response_model=UserRead)
def create_user(user: User, db: Session = Depends(get_db)):
    db_user = db.query(users).filter(users.c.nid == user.nid).first()
    if db_user:
        raise HTTPException(status_code=400, detail="NID already registered")

    new_user_data = {
        "role_id": user.role_id,
        "nid": user.nid,
        "status": user.status,
        "joint_at": user.joint_at,
    }

    try:
        db.execute(users.insert().values(new_user_data))
        db.commit()

        created_user = db.query(users).filter(users.c.nid == user.nid).first()
        if not created_user:
            raise HTTPException(status_code=500, detail="User creation failed")
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))

    return created_user


@user_router.get("/users", response_model=list[UserRead])
def list_users(db: Session = Depends(get_db)):
    db_users = db.query(users).all()
    return db_users


@user_router.get("/nid", response_model=list[NidUser])
def list_users(db: Session = Depends(get_nid_db)):
    return db.query(nid_citizens).all()


@user_router.get("/breg", response_model=list[BregCertUser])
def list_users(db: Session = Depends(get_breg_db)):
    return db.query(breg_cert_citizens).all()


@user_router.get("/{user_id}", response_model=UserRead)
def get_user(user_id: int, db: Session = Depends(get_db)):
    db_user = db.query(users).filter(users.c.user_id == user_id).first()
    if db_user is None:
        raise HTTPException(status_code=404, detail="User not found")
    return db_user


@user_router.get("/verify/nid")
def verify_nid(nid: str, phone_num: str, nid_db: Session = Depends(get_nid_db)):
    db_user = (
        nid_db.query(nid_citizens)
        .filter(nid_citizens.c.n_id == nid, nid_citizens.c.phone_number == phone_num)
        .first()
    )

    if db_user is None:
        raise HTTPException(status_code=404, detail="User with this NID not found")

    return db_user.n_id


@user_router.get("/verify/breg")
def verify_breg(breg_num: str, dob: datetime, breg_db: Session = Depends(get_breg_db)):
    db_user = (
        breg_db.query(breg_cert_citizens)
        .filter(
            breg_cert_citizens.c.birth_registration_number == breg_num,
            breg_cert_citizens.c.date_of_birth == dob,
        )
        .first()
    )

    if db_user is None:
        raise HTTPException(
            status_code=404,
            detail="User with provided Birth Registration Number and DOB not found",
        )

    return db_user.birth_registration_number


@user_router.put("/{user_id}/status", response_model=UserRead)
def update_user_status(user_id: int, status: str, db: Session = Depends(get_db)):
    db_user = db.query(users).filter(users.c.user_id == user_id).first()
    if db_user is None:
        raise HTTPException(status_code=404, detail="User not found")

    query = update(users).where(users.c.user_id == user_id).values(status=status)

    db.execute(query)
    db.commit()

    updated_user = db.execute(select(users).where(users.c.user_id == user_id)).first()

    return updated_user


@user_router.get("/otp/send")
def send_otp(response: Response):
    otp = f"{randbelow(1000000):06d}"
    response.set_cookie(key="otp_code", value=otp, samesite="lax")

    print(f"OTP: {otp}")

    return otp


@user_router.post("/otp/verify")
def verify_otp(
    rial_code: str,
    entered_code: str = Cookie(None, alias="otp_code"),
):
    if entered_code == rial_code:
        return "ok"
    else:
        return "nok"
