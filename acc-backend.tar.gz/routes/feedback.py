from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import asc, case, delete, desc, func, select, update
from sqlalchemy.orm import Session, sessionmaker

from config.db import engine
from models.complaint import ComplaintCity, ComplaintStatus
from models.index import attachments, categories, complaints, feedback, users
from models.user import RoleEnum
from schemas.index import (
    ComplaintCreate,
    ComplaintRead,
    FeedbackCreate,
    FeedbackRead,
    FeedbackUpdate,
)

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

feedback_router = APIRouter(prefix="/feedback", tags=["Feedback"])


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


# Create a feedback record
@feedback_router.post("/", response_model=FeedbackRead)
def create_feedback(feedback_data: FeedbackCreate, db: Session = Depends(get_db)):
    new_feedback = feedback.insert().values(
        complaint_id=feedback_data.complaint_id,
        level=feedback_data.level,
    )
    result = db.execute(new_feedback)
    db.commit()

    # Fetch the newly created feedback using its ID
    created_feedback = db.execute(
        select(feedback).where(feedback.c.id == result.lastrowid)
    ).first()

    return created_feedback


# Retrieve feedback by ID
@feedback_router.get("/{feedback_id}", response_model=FeedbackRead)
def get_feedback(feedback_id: int, db: Session = Depends(get_db)):
    db_feedback = db.execute(
        select(feedback).where(feedback.c.id == feedback_id)
    ).first()

    if not db_feedback:
        raise HTTPException(status_code=404, detail="Feedback not found")

    return db_feedback


# Update feedback by ID
@feedback_router.put("/{feedback_id}", response_model=FeedbackRead)
def update_feedback(
    feedback_id: int, feedback_data: FeedbackUpdate, db: Session = Depends(get_db)
):
    db_feedback = db.execute(
        select(feedback).where(feedback.c.id == feedback_id)
    ).first()

    if not db_feedback:
        raise HTTPException(status_code=404, detail="Feedback not found")

    stmt = (
        update(feedback)
        .where(feedback.c.id == feedback_id)
        .values(level=feedback_data.level)
    )
    db.execute(stmt)
    db.commit()

    updated_feedback = db.execute(
        select(feedback).where(feedback.c.id == feedback_id)
    ).first()

    return updated_feedback


# Delete feedback by ID
@feedback_router.delete("/{feedback_id}", response_model=dict)
def delete_feedback(feedback_id: int, db: Session = Depends(get_db)):
    db_feedback = db.execute(
        select(feedback).where(feedback.c.id == feedback_id)
    ).first()

    if not db_feedback:
        raise HTTPException(status_code=404, detail="Feedback not found")

    stmt = delete(feedback).where(feedback.c.id == feedback_id)
    db.execute(stmt)
    db.commit()

    return {"detail": "Feedback deleted successfully"}


@feedback_router.get("/complaint/{complaint_id}", response_model=FeedbackRead)
def get_feedback_by_complaint_id(complaint_id: int, db: Session = Depends(get_db)):
    # Query the feedback table by complaint_id
    db_feedback = db.execute(
        select(feedback).where(feedback.c.complaint_id == complaint_id)
    ).first()

    if not db_feedback:
        raise HTTPException(
            status_code=404, detail="Feedback not found for the given complaint ID"
        )

    return db_feedback


@feedback_router.post("/upsert", response_model=FeedbackRead)
def upsert_feedback(
    feedback_data: FeedbackUpdate,  # Use FeedbackUpdate since it has complaint_id
    db: Session = Depends(get_db),
):
    # Check if the feedback exists
    db_feedback = (
        db.query(feedback)
        .filter(feedback.c.complaint_id == feedback_data.complaint_id)
        .first()
    )

    if db_feedback:
        # Update the existing feedback
        stmt = (
            update(feedback)
            .where(feedback.c.complaint_id == feedback_data.complaint_id)
            .values(level=feedback_data.level)
        )
        db.execute(stmt)
        db.commit()

        # Return the updated feedback
        updated_feedback = (
            db.query(feedback)
            .filter(feedback.c.complaint_id == feedback_data.complaint_id)
            .first()
        )
        return updated_feedback

    # Create a new feedback if no existing feedback found
    new_feedback = feedback.insert().values(
        complaint_id=feedback_data.complaint_id,
        level=feedback_data.level,
    )
    result = db.execute(new_feedback)
    db.commit()

    # Fetch the newly created feedback using its auto-generated ID
    created_feedback = (
        db.query(feedback).filter(feedback.c.id == result.lastrowid).first()
    )
    return created_feedback
