from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session, sessionmaker

from config.db import engine
from models.index import notifications
from schemas.index import NotificationRead

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

notification_router = APIRouter()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


notification_router = APIRouter(prefix="/notifications", tags=["Notifications"])

# Get All notification
@notification_router.get("/{user_id}", response_model=list[NotificationRead])
def get_notification(user_id, db: Session = Depends(get_db)):
    query = notifications.select()
    if user_id is not None:
        query = query.where(notifications.c.user_id == user_id)
    notification_list = db.execute(query).fetchall()
    return notification_list
