from datetime import datetime, timedelta
from typing import List

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import asc, case, delete, desc, func, update
from sqlalchemy.orm import Session, sessionmaker

from config.db import engine
from models.complaint import ComplaintCity, ComplaintStatus
from models.index import attachments, categories, comments, complaints, users
from models.user import RoleEnum
from schemas.index import CommentCreate, CommentRead, CommentUpdate

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

comment_router = APIRouter(prefix="/comments", tags=["Comments"])


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()


@comment_router.get("/", response_model=List[CommentRead])
def get_complaints(db: Session = Depends(get_db)):
    db_complaints = db.query(comments).all()

    if not db_complaints:
        raise HTTPException(status_code=404, detail="No complaints found")

    return db_complaints


# Get all comments for a particular complaint
@comment_router.get("/{complaint_id}", response_model=CommentRead)
def get_comments(complaint_id: int, db: Session = Depends(get_db)):
    db_comments = (
        db.query(comments).filter(comments.c.complaint_id == complaint_id).first()
    )
    if not db_comments:
        raise HTTPException(status_code=404, detail="Comments not found")
    return db_comments


@comment_router.post("/", response_model=CommentRead)
def upsert_comment(
    comment_data: CommentUpdate,
    db: Session = Depends(get_db),
):
    # Check if the comment exists
    db_comment = (
        db.query(comments).filter(comments.c.cmt_id == comment_data.comment_id).first()
    )

    if db_comment:
        # Update the existing comment
        stmt = (
            update(comments)
            .where(comments.c.cmt_id == comment_data.comment_id)
            .values(comment=comment_data.comment)
        )
        db.execute(stmt)
        db.commit()

        # Return the updated comment
        updated_comment = (
            db.query(comments)
            .filter(comments.c.cmt_id == comment_data.comment_id)
            .first()
        )
        return updated_comment

    # Create a new comment if no existing comment found
    if not comment_data.complaint_id:
        raise HTTPException(
            status_code=400,
            detail="complaint_id is required to create a new comment.",
        )

    new_comment = comments.insert().values(
        complaint_id=comment_data.complaint_id,
        comment=comment_data.comment,
    )
    result = db.execute(new_comment)
    db.commit()

    # Fetch the newly created comment
    created_comment = db.query(comments).order_by(comments.c.cmt_id.desc()).first()
    return created_comment
