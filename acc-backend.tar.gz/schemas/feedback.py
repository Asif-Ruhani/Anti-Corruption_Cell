from typing import Optional

from pydantic import BaseModel
from sqlalchemy import Column, ForeignKey, Integer, MetaData, String, Table


# Pydantic Models
class FeedbackBase(BaseModel):
    complaint_id: int
    level: str

    class Config:
        orm_mode = True


class FeedbackCreate(FeedbackBase):
    pass


class FeedbackUpdate(FeedbackBase):
    level: str

    class Config:
        orm_mode = True


class FeedbackRead(FeedbackBase):
    id: int
