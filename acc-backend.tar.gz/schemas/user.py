from datetime import datetime
from enum import Enum
from typing import Optional

from pydantic import BaseModel, EmailStr


class RoleEnum(str, Enum):
    admin = "admin"
    regulatory = "regulatory"
    user = "user"


class User(BaseModel):
    nid: str
    role_id: RoleEnum
    status: str
    joint_at: datetime

    class Config:
        orm_mode = True


class NidUser(BaseModel):
    n_id: str
    birth_registration_number: str
    date_of_birth: datetime
    name_english: str
    gender: str
    phone_number: str
    created_at: datetime

    class Config:
        orm_mode = True


class BregCertUser(BaseModel):
    birth_registration_number: str
    date_of_birth: datetime
    name_english: str
    gender: str
    created_at: datetime

    class Config:
        orm_mode = True


class UserLogin(BaseModel):
    nid: Optional[str] = None
    phone_num: Optional[str] = None
    bregNum: Optional[str] = None
    dob: Optional[str] = None
    isNid: Optional[bool] = None


class UserRead(User):
    user_id: int
