from datetime import datetime
from typing import Optional

from pydantic import BaseModel


class CommentBase(BaseModel):
    complaint_id: int
    comment: str

    class Config:
        orm_mode = True


class CommentCreate(CommentBase):
    pass


class CommentRead(CommentBase):
    comment: str
    cmt_id: Optional[int]


class CommentUpdate(CommentBase):
    comment_id: Optional[int]
    comment: str
