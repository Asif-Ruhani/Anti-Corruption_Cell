from datetime import datetime

from pydantic import BaseModel


class AttachmentBase(BaseModel):
    complaint_id: int
    file_path: str
    file_type: str
    created_at: datetime

    class Config:
        orm_mode = True


class AttachmentCreate(BaseModel):
    complaint_id: int
    file_path: str
    file_type: str


class AttachmentRead(AttachmentBase):
    attachment_id: int
