from datetime import datetime
from pydantic import BaseModel


class NotificationBase(BaseModel):
    class Config:
        orm_mode = True


class NotificationCreate(NotificationBase):
    pass


class NotificationRead(NotificationBase):
    notification_id: int
    complaint_id: int
    message: str 
    created_at: datetime
