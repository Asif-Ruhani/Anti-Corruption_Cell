from pydantic import BaseModel


class CategoryBase(BaseModel):
    cat_name: str

    class Config:
        orm_mode = True


class CategoryCreate(CategoryBase):
    pass


class CategoryRead(CategoryBase):
    cat_id: int
