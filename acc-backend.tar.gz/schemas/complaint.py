from datetime import datetime
from enum import Enum
from typing import Optional

from pydantic import BaseModel


class ComplaintStatus(str, Enum):
    rejected = "rejected"
    pending = "pending"
    processing = "processing"
    solved = "solved"


class ComplaintBase(BaseModel):
    user_id: int
    title: str
    cat_id: int
    desc: str
    city: str
    address: str
    status: ComplaintStatus
    created_at: datetime
    modified_at: datetime

    class Config:
        orm_mode = True


class ComplaintCreate(ComplaintBase):
    pass


class ComplaintRead(ComplaintBase):
    complaint_id: int
    created_at: datetime
    modified_at: datetime
