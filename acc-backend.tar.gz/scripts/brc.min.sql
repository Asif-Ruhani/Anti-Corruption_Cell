CREATE DATABASE IF NOT EXISTS birth_regcrt_db;
USE birth_regcrt_db;

INSERT INTO breg_users (
  birth_registration_number, date_of_birth, 
  name_bangla, name_english, father_name, 
  father_nid, mother_name, mother_nid, 
  gender, current_address
) 
VALUES 
  (
    '20001234567890000',
    '2000-05-15', 
    'মোঃ সাইফুল ইসলাম', 
    'Md. Saiful Islam', 
    'আব্দুল মান্নান', 
    '19970123456789001', 
    'জাহানারা বেগম', 
    '19950123456789002', 
    'male', 
    '123, কুমিল্লা রোড, ঢাকা'
  ),
  (
    '11201234567890123',
    '1990-01-01', 
    'রাহেলা খাতুন', 
    'Rahela Khatun',
    'মোহাম্মদ আলী', 
    '19910123456789003',
    'শাহিদা বেগম', 
    '19920123456789004',
    'female',
    '45/12, আগ্রাবাদ, চট্টগ্রাম'
  );
