CREATE DATABASE IF NOT EXISTS anti_corruption_cell;
use anti_corruption_cell;

INSERT INTO users (role_id, joint_at, nid, status)
VALUES 
('admin', '2024-08-01 10:30:00', 'admin', 'active'),
('regulatory', '2024-09-02 11:45:00', 'regulatory', 'active'),
('user', '2024-10-01 11:45:00', '19951120456000123', 'active'),
('user', '2024-10-02 10:45:00', '19880715345000156', 'active');


INSERT INTO categories (cat_name)
VALUES 
  ('Extortion'),
  ('Embezzlement'),
  ('Bureaucracy'),
  ('Nepotism'),
  ('Fraud'),
  ('Others'),
  ('Bribery'),
  ('Money Laundering'),
  ('Tax Evasion'),
  ('Corruption');


INSERT INTO complaints (user_id, title, cat_id, `desc`, city, address, status, created_at, modified_at)
VALUES 
(3, 'Street Lights Out in Comilla', 3, 'The street lights on the main road are not functioning, making it unsafe at night.', 'Comilla', '12, Shashan Road, Comilla', 'pending', '2024-11-03 18:00:00', '2024-11-03 18:00:00'),
(3, 'Unlawful Building Construction in Khulna', 1, 'A high-rise building is being constructed without permission in a residential area.', 'Khulna', '20, Sonadanga, Khulna', 'rejected', '2024-09-15 15:20:00', '2024-09-15 15:20:00'),
(3, 'Illegal Parking in Sylhet', 6, 'Vehicles are illegally parked on the main road, causing traffic congestion.', 'Sylhet', '12, Zindabazar, Sylhet', 'pending', '2024-11-01 12:00:00', '2024-11-01 12:00:00'),
(4, 'Illegal Garbage Dumping in Barishal', 6, 'Garbage is being dumped illegally in public spaces, leading to pollution and foul smells.', 'Barishal', '65, Kazi Bazar, Barishal', 'pending', '2024-11-02 12:05:00', '2024-11-02 12:05:00'),
(4, 'Blocked Drainage System in Chattogram', 6, 'The drainage system in our area is completely blocked, causing waterlogging even with slight rain.', 'Chattogram', '12, Patharghata Road, Chattogram', 'pending', '2024-11-15 08:00:00', '2024-11-15 08:00:00'),
(4, 'Potholes on Main Road in Dhaka', 3, 'Potholes are damaging vehicles and creating traffic jams on the main road.', 'Dhaka', '50, Dhanmondi, Dhaka', 'solved', '2024-10-15 17:40:00', '2024-10-18 10:20:00');


INSERT INTO attachments (complaint_id, file_path, file_type, created_at)
VALUES
    (1, 'uploads/dark_no_light.jpg', 'image/jpeg', '2024-11-01 14:23:45'),
    (2, 'uploads/illegal_building.jpg', 'image/jpeg', '2024-11-02 10:45:12'),
    (3, 'uploads/illegal_parking_issue.jpg', 'image/jpeg', '2024-11-05 09:05:30'),
    (4, 'uploads/garbage_dump.jpg', 'image/jpeg', '2024-11-05 09:05:30'),
    (5, 'uploads/no_drainage.jpg', 'image/jpeg', '2024-11-10 16:32:21'),
    (6, 'uploads/poth_holes.jpg', 'image/jpeg', '2024-10-11 16:32:21');