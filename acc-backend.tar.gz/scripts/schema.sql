CREATE DATABASE IF NOT EXISTS anti_corruption_cell;
CREATE DATABASE IF NOT EXISTS birth_regcrt_db;
CREATE DATABASE IF NOT EXISTS nid_db;

USE anti_corruption_cell;
CREATE TABLE categories (
        cat_id INTEGER NOT NULL AUTO_INCREMENT, 
        cat_name VARCHAR(30) NOT NULL, 
        PRIMARY KEY (cat_id)
);


CREATE TABLE users (
        user_id INTEGER NOT NULL AUTO_INCREMENT, 
        role_id ENUM('admin','regulatory','user') NOT NULL, 
        joint_at TIMESTAMP NOT NULL, 
        nid VARCHAR(30) NOT NULL, 
        status VARCHAR(10) NOT NULL, 
        PRIMARY KEY (user_id)
);


CREATE TABLE complaints (
        complaint_id INTEGER NOT NULL AUTO_INCREMENT, 
        user_id INTEGER NOT NULL, 
        title VARCHAR(255) NOT NULL, 
        cat_id INTEGER NOT NULL, 
        `desc` TEXT, 
        city VARCHAR(20), 
        address VARCHAR(255), 
        status ENUM('rejected','pending','processing','solved') NOT NULL, 
        created_at TIMESTAMP NOT NULL DEFAULT (now()),
        modified_at TIMESTAMP NOT NULL, 
        PRIMARY KEY (complaint_id), 
        FOREIGN KEY(user_id) REFERENCES users (user_id), 
        FOREIGN KEY(cat_id) REFERENCES categories (cat_id)
);



CREATE TABLE notifications (
        notification_id INTEGER NOT NULL AUTO_INCREMENT, 
        user_id INTEGER NOT NULL, 
        complaint_id INTEGER NOT NULL,
        message VARCHAR(255) NOT NULL, 
        created_at TIMESTAMP NOT NULL DEFAULT (now()),
        PRIMARY KEY (notification_id), 
        FOREIGN KEY(user_id) REFERENCES users (user_id),
        FOREIGN KEY(complaint_id) REFERENCES complaints (complaint_id)
);



CREATE TABLE attachments (
        attachment_id INTEGER NOT NULL AUTO_INCREMENT, 
        complaint_id INTEGER NOT NULL, 
        file_path VARCHAR(255) NOT NULL, 
        file_type VARCHAR(255) NOT NULL, 
        created_at TIMESTAMP NOT NULL DEFAULT (now()), 
        PRIMARY KEY (attachment_id), 
        FOREIGN KEY(complaint_id) REFERENCES complaints (complaint_id)
);



CREATE TABLE comments (
        cmt_id INTEGER NOT NULL AUTO_INCREMENT, 
        complaint_id INTEGER NOT NULL, 
        comment TEXT NOT NULL, 
        PRIMARY KEY (cmt_id), 
        FOREIGN KEY(complaint_id) REFERENCES complaints (complaint_id)
);



CREATE TABLE feedback (
        id INTEGER NOT NULL AUTO_INCREMENT, 
        complaint_id INTEGER NOT NULL, 
        level VARCHAR(10) NOT NULL, 
        PRIMARY KEY (id), 
        FOREIGN KEY(complaint_id) REFERENCES complaints (complaint_id)
);




USE nid_db;
CREATE TABLE nid_citizens (
        n_id VARCHAR(17) NOT NULL, 
        voter_area_name VARCHAR(255) NOT NULL, 
        voter_area_number VARCHAR(50) NOT NULL, 
        name_bangla VARCHAR(255) NOT NULL, 
        name_english VARCHAR(255) NOT NULL, 
        father_name VARCHAR(255) NOT NULL, 
        father_nid VARCHAR(17), 
        mother_name VARCHAR(255) NOT NULL, 
        mother_nid VARCHAR(17), 
        birth_registration_number VARCHAR(20), 
        date_of_birth DATE NOT NULL, 
        gender ENUM('male','female') NOT NULL, 
        current_address TEXT NOT NULL, 
        phone_number VARCHAR(20) NOT NULL, 
        created_at TIMESTAMP NOT NULL DEFAULT (now()), 
        updated_at TIMESTAMP NULL DEFAULT (now()), 
        PRIMARY KEY (n_id)
);

USE birth_regcrt_db;
CREATE TABLE breg_users (
        birth_registration_number VARCHAR(20) NOT NULL, 
        date_of_birth DATE NOT NULL, 
        name_bangla VARCHAR(255) NOT NULL, 
        name_english VARCHAR(255) NOT NULL, 
        father_name VARCHAR(255) NOT NULL, 
        father_nid VARCHAR(17), 
        mother_name VARCHAR(255) NOT NULL, 
        mother_nid VARCHAR(17), 
        gender ENUM('male','female') NOT NULL, 
        current_address TEXT NOT NULL, 
        created_at TIMESTAMP NULL DEFAULT (now()), 
        updated_at TIMESTAMP NULL DEFAULT (now()), 
        PRIMARY KEY (birth_registration_number)
);