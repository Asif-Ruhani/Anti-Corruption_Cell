USE anti_corruption_cell;

INSERT INTO users (role_id, joint_at, nid, status)
VALUES 
('admin', '2024-11-01 10:30:00', '123456789', 'active'),
('regulatory', '2024-11-02 11:45:00', '987654321', 'inactive'),
('admin', '2024-11-05 14:50:00', '456789123', 'active'),
('regulatory', '2024-11-06 16:10:00', '112233445', 'inactive'),
('admin', '2024-11-09 12:30:00', '665544332', 'active');


INSERT INTO categories (cat_name)
VALUES 
  ('Extortion'),
  ('Embezzlement'),
  ('Bureaucracy'),
  ('Nepotism'),
  ('Fraud'),
  ('Others'),
  ('Bribery'),
  ('Money Laundering'),
  ('Tax Evasion'),
  ('Corruption');


INSERT INTO complaints (user_id, title, cat_id, `desc`, city, address, status, created_at, modified_at)
VALUES 
(5, 'Unsafe Public Transport in Barishal', 4, 'Public buses are overcrowded and not maintained, posing a safety risk.', 'Barishal', '56, Banaripara, Barishal', 'processing', '2024-08-25 17:30:00', '2024-09-05 09:15:00'),
(6, 'Unlawful Building Construction in Khulna', 1, 'A high-rise building is being constructed without permission in a residential area.', 'Khulna', '20, Sonadanga, Khulna', 'rejected', '2024-09-15 15:20:00', '2024-09-15 15:20:00'),
(7, 'Inadequate Street Lighting in Tangail', 3, 'The street lights are not functioning properly in the main town area, making it unsafe at night.', 'Tangail', '33, College Road, Tangail', 'processing', '2024-08-18 19:30:00', '2024-08-18 19:30:00'),
(8, 'Illegal Garbage Dumping in Barishal', 6, 'Garbage is being dumped illegally in public spaces, leading to pollution and foul smells.', 'Barishal', '65, Kazi Bazar, Barishal', 'pending', '2024-11-02 12:05:00', '2024-11-02 12:05:00'),
(9, 'Land Encroachment in Tangail', 1, 'Private land is being illegally occupied, blocking the local road access.', 'Tangail', '22, Mangalbari, Tangail', 'rejected', '2024-08-05 13:50:00', '2024-08-05 13:50:00'),
(5, 'Illegal River Encroachment in Bogura', 1, 'Land encroachment along the riverbank is destroying the natural ecosystem.', 'Bogura', '10, Gokulnagar, Bogura', 'rejected', '2024-07-05 13:50:00', '2024-07-05 13:50:00'),
(6, 'Unregulated Construction in Chattogram', 1, 'Illegal construction is going on without proper permits, violating building codes.', 'Chattogram', '30, Agrabad, Chattogram', 'processing', '2024-10-12 14:25:00', '2024-10-14 09:50:00'),
(7, 'Water Shortage in Rangpur', 2, 'The water supply is irregular and insufficient in my area, especially during the dry season.', 'Rangpur', '44, Adhunik Para, Rangpur', 'pending', '2024-10-12 10:00:00', '2024-10-12 10:00:00'),
(8, 'Street Lights Out in Comilla', 3, 'The street lights on the main road are not functioning, making it unsafe at night.', 'Comilla', '12, Shashan Road, Comilla', 'pending', '2024-11-03 18:00:00', '2024-11-03 18:00:00'),
(9, 'Corruption in Local Police Station in Rajshahi', 5, 'Police officers are taking bribes for releasing criminals in the local station.', 'Rajshahi', '45, New Market, Rajshahi', 'processing', '2024-10-25 10:30:00', '2024-10-28 12:40:00'),
(10, 'Blocked Drainage System in Chattogram', 6, 'The drainage system in our area is completely blocked, causing waterlogging even with slight rain.', 'Chattogram', '12, Patharghata Road, Chattogram', 'pending', '2024-11-15 08:00:00', '2024-11-15 08:00:00'),
(5, 'Poor Hygiene in Mymensingh', 6, 'Public toilets are dirty and unsanitary, causing a health risk in the area.', 'Mymensingh', '22, Babu Bazar, Mymensingh', 'solved', '2024-09-02 14:20:00', '2024-09-10 16:25:00'),
(6, 'Noise Pollution from Factories in Gazipur', 4, 'Nearby factories operate all night, creating constant noise and disturbing the peace.', 'Gazipur', '75, Konabari, Gazipur', 'processing', '2024-11-08 14:45:00', '2024-11-10 10:20:00'),
(7, 'Potholes on Main Road in Dhaka', 3, 'Potholes are damaging vehicles and creating traffic jams on the main road.', 'Dhaka', '50, Dhanmondi, Dhaka', 'solved', '2024-10-15 17:40:00', '2024-10-18 10:20:00'),
(8, 'Illegal Waste Dumping in Dhaka', 2, 'Hazardous waste is being dumped in the open field near my residence, causing environmental and health hazards.', 'Dhaka', '15/4, Mirpur Road, Dhaka', 'pending', '2024-10-10 08:45:00', '2024-10-10 08:45:00'),
(9, 'Irregular Electricity Supply in Mymensingh', 4, 'There are frequent power outages in my area, causing a lot of inconvenience.', 'Mymensingh', '10, Boro Bazar, Mymensingh', 'pending', '2024-11-10 09:15:00', '2024-11-10 09:15:00'),
(10, 'Open Sewage in Rajshahi', 6, 'Raw sewage is flowing openly in the streets, creating an unbearable stench and health hazards.', 'Rajshahi', '21, Taherpur, Rajshahi', 'solved', '2024-11-01 16:20:00', '2024-11-05 10:50:00'),
(5, 'Illegal Sand Mining in Sylhet', 1, 'Sand mining is taking place in the river, which is causing erosion and environmental damage.', 'Sylhet', '25, Mirzapur, Sylhet', 'processing', '2024-09-20 08:30:00', '2024-09-22 11:00:00'),
(6, 'Corrupt Government Officials in Rajshahi', 5, 'Local officials are demanding bribes for routine administrative work.', 'Rajshahi', '77, Shaheb Bazar, Rajshahi', 'solved', '2024-07-20 11:10:00', '2024-08-01 14:40:00'),
(7, 'Overcrowding in School Classrooms in Sylhet', 5, 'The local primary school classrooms are overcrowded, affecting the quality of education.', 'Sylhet', '5, Dorga Gate, Sylhet', 'pending', '2024-11-18 11:30:00', '2024-11-18 11:30:00'),
(8, 'Illegal Parking in Sylhet', 6, 'Vehicles are illegally parked on the main road, causing traffic congestion.', 'Sylhet', '12, Zindabazar, Sylhet', 'pending', '2024-11-01 12:00:00', '2024-11-01 12:00:00'),
(9, 'Lack of Public Toilets in Bogura', 6, 'There is a severe shortage of clean public toilets in the city, especially near public transport hubs.', 'Bogura', '13, Sadar Bazar, Bogura', 'rejected', '2024-07-22 16:50:00', '2024-07-22 16:50:00'),
(10, 'Illegal Water Supply Connections in Khulna', 2, 'Residents are illegally tapping into the water supply, causing water shortages for others.', 'Khulna', '38, Rupsha Road, Khulna', 'solved', '2024-09-16 14:15:00', '2024-09-18 16:00:00'),
(5, 'Poor Road Conditions in Chattogram', 3, 'The roads in the city center are full of potholes and are dangerous to drive on.', 'Chattogram', '34, Kaptai Road, Chattogram', 'processing', '2024-11-02 09:00:00', '2024-11-05 10:30:00'),
(6, 'Broken Footpaths in Dhaka', 3, 'Footpaths in the city are broken and uneven, causing inconvenience for pedestrians, especially the elderly.', 'Dhaka', '60, Motijheel, Dhaka', 'rejected', '2024-11-05 09:10:00', '2024-11-05 09:10:00');

INSERT INTO attachments (complaint_id, file_path, file_type, created_at)
VALUES
    (1, '/uploads/dark_no_light.jpg', 'image/jpeg', '2024-11-01 14:23:45'),
    (2, '/uploads/illegal_building.jpg', 'image/jpeg', '2024-11-02 10:45:12'),
    (3, '/uploads/illegal_parking_issue.jpg', 'image/jpeg', '2024-11-05 09:05:30'),
    (4, '/uploads/garbage_dump.jpg', 'image/jpeg', '2024-11-05 09:05:30'),
    (5, '/uploads/no_drainage.jpg', 'image/jpeg', '2024-11-10 16:32:21'),
    (6, '/uploads/poth_holes.jpg', 'image/jpeg', '2024-10-11 16:32:21');