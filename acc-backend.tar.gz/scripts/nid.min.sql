CREATE DATABASE IF NOT EXISTS nid_db;
USE nid_db;

INSERT INTO nid_citizens (
  n_id, 
  voter_area_name, 
  voter_area_number, 
  name_bangla,
  name_english, 
  father_name, 
  father_nid, 
  mother_name, 
  mother_nid, 
  birth_registration_number, 
  date_of_birth, 
  gender,
  current_address,
  phone_number
) 
VALUES 
  (
    '19951120456000123', 
    'Dhaka South',
    'DS12345', 
    'রফিকুল ইসলাম', 
    'Rafiqul Islam', 
    'Abdur Rahman', 
    '19931120456000001', 
    'Jahanara Begum', 
    '19921120456000002', 
    '19958986783280917', 
    '1995-11-20', 
    'Male', 
    '123/A, Motijheel, Dhaka',
    '01712345678'
  ),
  (
    '11212345678901234', 
    'Sylhet City', 
    'SC55467', 
    'সাজিদ রহমান', 
    'Sajid Rahman', 
    'Nazrul Islam', 
    '507500047824', 
    'Rubina Begum',
    '716161781539',
    '11201234567890123',
    '2000-12-25', 
    'Male', 
    '15, Dorgah Gate, Sylhet',
    '01511234567'
  );