#!/bin/bash

docker run --name anti-corruption-cell -e MYSQL_ALLOW_EMPTY_PASSWORD=yes -d mysql:lts
docker exec -it anti-corruption-cell mysql -uroot

