from sqlalchemy import MetaData, create_engine
from sqlalchemy.exc import SQLAlchemyError

meta = MetaData()
nMeta = MetaData()
bRegMeta = MetaData()

engine = create_engine("mysql+pymysql://root@localhost:3306/anti_corruption_cell")
conn = engine.connect()

nid_engine = create_engine("mysql+pymysql://root@localhost:3306/nid_db")
nid_db_conn = nid_engine.connect()

breg_crt_engine = create_engine("mysql+pymysql://root@localhost:3306/birth_regcrt_db")
breg_crt_db_conn = breg_crt_engine.connect()
