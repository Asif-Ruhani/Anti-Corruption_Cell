import enum

from sqlalchemy import TIMESTAMP, Column, Enum, ForeignKey, Integer, String, Table
from sqlalchemy.sql import func

from config.db import engine, meta

categories = Table(
    "categories",
    meta,
    Column("cat_id", Integer, primary_key=True, autoincrement=True),
    Column("cat_name", String(30), nullable=False),
)
