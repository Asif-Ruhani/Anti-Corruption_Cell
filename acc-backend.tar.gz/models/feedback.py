from typing import Optional

from pydantic import BaseModel
from sqlalchemy import Column, ForeignKey, Integer, MetaData, String, Table

from config.db import engine, meta

feedback = Table(
    "feedback",
    meta,
    Column("id", Integer, primary_key=True, index=True),
    Column(
        "complaint_id", Integer, ForeignKey("complaints.complaint_id"), nullable=False
    ),
    Column("level", String(10), nullable=False),
)
