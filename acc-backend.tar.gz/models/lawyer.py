import enum

from sqlalchemy import TIMESTAMP, Column, Enum, ForeignKey, Integer, String, Table
from sqlalchemy.sql import func

from config.db import engine, meta

lawyers = Table(
    "lawyers",
    meta,
    Column("red_id", Integer, primary_key=True),
    Column("name", String(30), nullable=False),
    Column("institution", String(255), nullable=False),
    Column("designation", String(255), nullable=False),
    Column("specialist", String(255), nullable=False),
    Column("experience", Integer, nullable=False),
    Column("cases", Integer, nullable=False),
    Column("fees", Integer, nullable=False),
    Column("contact", String(255), nullable=False),
)
