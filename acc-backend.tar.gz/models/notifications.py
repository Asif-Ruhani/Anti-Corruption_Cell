import enum

from sqlalchemy import TIMESTAMP, Column, ForeignKey, Integer, String, Table, Text
from sqlalchemy.sql import func

from config.db import engine, meta

notifications = Table(
    "notifications",
    meta,
    Column("notification_id", Integer, primary_key=True, autoincrement=True),
    Column("user_id", Integer, ForeignKey("users.user_id"), nullable=False),
    Column(
        "complaint_id", Integer, ForeignKey("complaints.complaint_id"), nullable=False
    ),
    Column("message", String(255), nullable=False),
    Column("created_at", TIMESTAMP, nullable=False),
)
