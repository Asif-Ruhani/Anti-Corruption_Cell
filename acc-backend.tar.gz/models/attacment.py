import enum

from sqlalchemy import TIMESTAMP, Column, Enum, ForeignKey, Integer, String, Table, func
from sqlalchemy.sql import func

from config.db import engine, meta

attachments = Table(
    "attachments",
    meta,
    Column("attachment_id", Integer, primary_key=True, autoincrement=True),
    Column(
        "complaint_id", Integer, ForeignKey("complaints.complaint_id"), nullable=False
    ),
    Column("file_path", String(255), nullable=False),
    Column("file_type", String(255), nullable=False),
    Column("created_at", TIMESTAMP, server_default=func.now(), nullable=False),
)
