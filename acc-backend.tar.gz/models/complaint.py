import enum

from sqlalchemy import TIMESTAMP, Column, Enum, ForeignKey, Integer, String, Table, Text
from sqlalchemy.sql import func

from config.db import engine, meta


class ComplaintStatus(enum.Enum):
    rejected = "rejected"
    pending = "pending"
    processing = "processing"
    solved = "solved"


class ComplaintCity(enum.Enum):
    Dhaka = "Dhaka"
    Chattogram = "Chattogram"
    Khulna = "Khulna"
    Comilla = "Comilla"
    Rajshahi = "Rajshahi"
    Sylhet = "Sylhet"
    Barishal = "Barishal"
    Rangpur = "Rangpur"
    Mymensingh = "Mymensingh"
    Bogura = "Bogura"
    Narayanganj = "Narayanganj"
    Narsingdi = "Narsingdi"
    Jessore = "Jessore"
    Pabna = "Pabna"
    Tangail = "Tangail"
    Dinajpur = "Dinajpur"


complaints = Table(
    "complaints",
    meta,
    Column("complaint_id", Integer, primary_key=True, autoincrement=True),
    Column("user_id", Integer, ForeignKey("users.user_id"), nullable=False),
    Column("title", String(255), nullable=False),
    Column("cat_id", Integer, ForeignKey("categories.cat_id"), nullable=False),
    Column("desc", Text),
    Column("city", String(20)),
    Column("address", String(255)),
    Column("status", Enum(ComplaintStatus), nullable=False),
    Column("created_at", TIMESTAMP, nullable=False),
    Column("modified_at", TIMESTAMP, nullable=False),
)
