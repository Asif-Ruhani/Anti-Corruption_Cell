import enum

from sqlalchemy import TIMESTAMP, Column, Enum, Integer, String, Table

from config.db import meta


class RoleEnum(enum.Enum):
    admin = "admin"
    regulatory = "regulatory"
    user = "user"


users = Table(
    "users",
    meta,
    Column("user_id", Integer, primary_key=True, autoincrement=True),
    Column("role_id", Enum(RoleEnum), nullable=False),
    Column("joint_at", TIMESTAMP, nullable=False),
    Column("nid", String(30), nullable=False),
    Column("status", String(10), nullable=False),
)
