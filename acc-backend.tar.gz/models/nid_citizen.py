from datetime import datetime

from sqlalchemy import (
    TIMESTAMP,
    Column,
    Date,
    Enum,
    MetaData,
    String,
    Table,
    Text,
    func,
)

from config.db import engine, nMeta

nid_citizens = Table(
    "nid_citizens",
    nMeta,
    Column("n_id", String(17), primary_key=True, nullable=False),
    Column("voter_area_name", String(255), nullable=False),
    Column("voter_area_number", String(50), nullable=False),
    Column("name_bangla", String(255), nullable=False),
    Column("name_english", String(255), nullable=False),
    Column("father_name", String(255), nullable=False),
    Column("father_nid", String(17), nullable=True),
    Column("mother_name", String(255), nullable=False),
    Column("mother_nid", String(17), nullable=True),
    Column("birth_registration_number", String(20), nullable=True),
    Column("date_of_birth", Date, nullable=False),
    Column("gender", Enum("male", "female"), nullable=False),
    Column("current_address", Text, nullable=False),
    Column("phone_number", String(20), nullable=False),
    Column("created_at", TIMESTAMP, nullable=False, server_default=func.now()),
    Column(
        "updated_at",
        TIMESTAMP,
        server_default=func.now(),
        onupdate=func.now(),
    ),
)
