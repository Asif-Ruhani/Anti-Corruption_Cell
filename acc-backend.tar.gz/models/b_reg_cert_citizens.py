from sqlalchemy import (
    TIMESTAMP,
    Column,
    Date,
    Enum,
    MetaData,
    String,
    Table,
    Text,
    func,
)

from config.db import bRegMeta, engine

# Citizens Table
breg_cert_citizens = Table(
    "breg_users",
    bRegMeta,
    Column("birth_registration_number", String(20), primary_key=True, nullable=False),
    Column("date_of_birth", Date, nullable=False),
    Column("name_bangla", String(255), nullable=False),
    Column("name_english", String(255), nullable=False),
    Column("father_name", String(255), nullable=False),
    Column("father_nid", String(17), nullable=True),
    Column("mother_name", String(255), nullable=False),
    Column("mother_nid", String(17), nullable=True),
    Column("gender", Enum("male", "female"), nullable=False),
    Column("current_address", Text, nullable=False),
    Column("created_at", TIMESTAMP, server_default=func.now()),
    Column(
        "updated_at",
        TIMESTAMP,
        server_default=func.now(),
        onupdate=func.now(),
    ),
)
