import enum

from sqlalchemy import (
    TIMESTAMP,
    Column,
    Enum,
    ForeignKey,
    Integer,
    String,
    Table,
    Text,
    func,
)
from sqlalchemy.sql import func

from config.db import engine, meta

comments = Table(
    "comments",
    meta,
    Column("cmt_id", Integer, primary_key=True, autoincrement=True),
    Column(
        "complaint_id", Integer, ForeignKey("complaints.complaint_id"), nullable=False
    ),
    Column("comment", Text, nullable=False),
)
