from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from config.db import breg_crt_engine, bRegMeta, engine, meta, nid_engine, nMeta
from routes.index import (
    attachment_router,
    category_router,
    comment_router,
    complaint_router,
    feedback_router,
    user_router,
    notification_router
)

UPLOAD_DIRECTORY = Path("uploads/")
UPLOAD_DIRECTORY.mkdir(exist_ok=True)


app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

meta.create_all(engine)
nMeta.create_all(nid_engine)
bRegMeta.create_all(breg_crt_engine)


app.include_router(user_router)
app.include_router(complaint_router)
app.include_router(category_router)
app.include_router(attachment_router)
app.include_router(comment_router)
app.include_router(feedback_router)
app.include_router(notification_router)

app.mount("/uploads", StaticFiles(directory=UPLOAD_DIRECTORY), name="uploads")

# from sqlalchemy.schema import CreateTable
# sql_schema = "\n".join(
#     str(CreateTable(table).compile(engine))
#     for table in bRegMeta.sorted_tables
# )


# print("-"*50)
# print(sql_schema)
# print("-"*50)
