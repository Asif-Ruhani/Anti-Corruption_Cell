import 'package:flutter/material.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

Color getComplaintStatusColor(String status) {
  switch (status) {
    case 'processing':
      return Colors.blue;
    case 'pending':
      return Colors.orange;
    case 'solved':
      return Colors.green;
    case 'rejected':
      return Colors.red;
    default:
      return Colors.grey;
  }
}

String getTranslatedComplaintStatus(BuildContext context, String status) {
  final localizations = AppLocalizations.of(context)!;

  switch (status.toLowerCase()) {
    case 'processing':
      return localizations.processing;
    case 'pending':
      return localizations.pending;
    case 'solved':
      return localizations.solved;
    case 'rejected':
      return localizations.rejected;
    default:
      return localizations.processing;
  }
}
