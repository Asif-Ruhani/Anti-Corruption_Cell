import 'package:flutter/material.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

String getDivisionShortCode(String divisionName) {
  switch (divisionName.toLowerCase()) {
    case 'dhaka':
      return 'DHK';
    case 'chattogram':
      return 'CTG';
    case 'khulna':
      return 'KLN';
    case 'comilla':
      return 'CML';
    case 'rajshahi':
      return 'RJH';
    case 'sylhet':
      return 'SYL';
    case 'barishal':
      return 'BRL';
    case 'rangpur':
      return 'RPR';
    case 'mymensingh':
      return 'MYM';
    case 'bogura':
      return 'BGR';
    case 'narayanganj':
      return 'NRG';
    case 'narsingdi':
      return 'NSD';
    case 'jessore':
      return 'JSR';
    case 'pabna':
      return 'PBN';
    case 'tangail':
      return 'TGL';
    case 'dinajpur':
      return 'DJP';
    default:
      debugPrint("Unknown Division: $divisionName");
      return 'UNK';
  }
}

String getTranslatedDivision(BuildContext context, String divisionName) {
  final localizations = AppLocalizations.of(context)!;

  switch (divisionName.toLowerCase()) {
    case 'barishal':
      return localizations.barishal;
    case 'chattogram':
      return localizations.chattogram;
    case 'dhaka':
      return localizations.dhaka;
    case 'khulna':
      return localizations.khulna;
    case 'mymensingh':
      return localizations.mymensingh;
    case 'rajshahi':
      return localizations.rajshahi;
    case 'rangpur':
      return localizations.rangpur;
    case 'sylhet':
      return localizations.sylhet;

    default:
      debugPrint("Unknown Division: $divisionName");
      return 'UNK';
  }
}
