class FormValidators {
  static String? required(String? value, {String? errorMessage}) {
    return value == null || value.isEmpty ? (errorMessage ?? 'Required') : null;
  }
}
