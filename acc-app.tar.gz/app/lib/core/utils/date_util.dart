import 'package:flutter/material.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';

import 'package:app/core/providers/locale_provider.dart';

String formatDate(
  BuildContext context,
  String dateString,
  String formatString,
) {
  try {
    final date = DateTime.parse(dateString);
    final localeProvider = context.watch<LocaleProvider>();
    final isBangla = localeProvider.locale.languageCode == 'bn';

    if (isBangla) {
      initializeDateFormatting('bn_BD', null);
    }

    return DateFormat(formatString, isBangla ? 'bn_BD' : 'en_US').format(date);
  } catch (e) {
    return dateString;
  }
}
