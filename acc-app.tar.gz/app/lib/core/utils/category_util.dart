import 'package:flutter/material.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

String catIdTocatName(BuildContext context, int catId) {
  final localizations = AppLocalizations.of(context)!;

  switch (catId) {
    case 1:
      return localizations.extortion;

    case 2:
      return localizations.embezzlement;

    case 3:
      return localizations.bureaucracy;

    case 4:
      return localizations.nepotism;

    case 5:
      return localizations.fraud;

    case 6:
      return localizations.others;

    case 7:
      return localizations.bribery;

    case 8:
      return localizations.money_laundering;

    case 9:
      return localizations.tax_evasion;

    case 10:
      return localizations.corruption;

    case _:
      return "none";
  }
}
