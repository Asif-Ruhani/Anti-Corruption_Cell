class Statistics {
  final int totalComplaints;
  final int resolved;
  final int pending;

  Statistics({
    required this.totalComplaints,
    required this.resolved,
    required this.pending,
  });

  factory Statistics.fromJson(Map<String, dynamic> json) {
    return Statistics(
      totalComplaints: json['totalComplaints'] ?? 0,
      resolved: json['resolved'] ?? 0,
      pending: json['pending'] ?? 0,
    );
  }
}
