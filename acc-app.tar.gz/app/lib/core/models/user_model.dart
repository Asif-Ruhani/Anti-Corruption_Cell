class User {
  final String nid;
  final String roleId;
  final String status;
  final DateTime jointAt;
  final int userId;

  User({
    required this.nid,
    required this.roleId,
    required this.status,
    required this.jointAt,
    required this.userId,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      nid: json['nid'] ?? "0",
      roleId: json['role_id'] ?? '0',
      status: json['status'] ?? 'active',
      jointAt: DateTime.parse(json['joint_at'] as String),
      userId: json['user_id'] ?? 0,
    );
  }
}
