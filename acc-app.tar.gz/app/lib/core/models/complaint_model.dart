class Complaint {
  final int userId;
  final String title;
  final int categoryId;
  final String description;
  final String city;
  final String address;
  final String status;
  final DateTime createdAt;
  final DateTime modifiedAt;
  final int complaintId;

  Complaint({
    required this.userId,
    required this.title,
    required this.categoryId,
    required this.description,
    required this.city,
    required this.address,
    required this.status,
    required this.createdAt,
    required this.modifiedAt,
    required this.complaintId,
  });

  factory Complaint.fromJson(Map<String, dynamic> json) {
    return Complaint(
      userId: json['user_id'] as int,
      title: json['title'] as String,
      categoryId: json['cat_id'] as int,
      description: json['desc'] as String,
      city: json['city'] as String,
      address: json['address'] as String,
      status: json['status'] as String,
      createdAt: DateTime.parse(json['created_at'] as String),
      modifiedAt: DateTime.parse(json['modified_at'] as String),
      complaintId: json['complaint_id'] as int,
    );
  }

  // Helper method to format date
  String get formattedDate {
    return '${createdAt.day}/${createdAt.month}/${createdAt.year}';
  }
}
