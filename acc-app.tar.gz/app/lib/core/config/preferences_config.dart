class PreferencesConfig {
  // Authentication
  static const String isLoggedIn = 'is_logged_in';

  // User Preferences
  static const String userId = 'user_id';
  static const String userRole = 'user_role';

  // App Settings
  static const String appTheme = 'app_theme';
  static const String appLanguage = 'app_language';
}
