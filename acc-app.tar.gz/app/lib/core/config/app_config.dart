abstract class AppConfig {
  static const String baseUrl = 'http://localhost:8001';
  static const bool isProduction = bool.fromEnvironment('PRODUCTION');
}
