import 'package:app/core/models/category_model.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'package:app/core/models/complaint_model.dart';
import 'package:app/core/models/statistics_model.dart';
import 'package:app/core/models/user_model.dart';
import 'package:app/core/services/api_service.dart';

class ApiServiceProvider extends ChangeNotifier {
  final ApiService _service;

  ApiServiceProvider(this._service);

  final Map<String, dynamic> _data = {};
  final Map<String, bool> _loadingStates = {};
  final Map<String, Exception?> _errors = {};

  T? getData<T>(String key) => _data[key] as T?;
  bool isLoading(String key) => _loadingStates[key] ?? false;
  Exception? getError(String key) => _errors[key];

  Future<T?> fetchEndpoint<T>(String key, Future<T> Function() fetchFn) async {
    _loadingStates[key] = true;
    _errors[key] = null;

    try {
      final result = await fetchFn();
      _data[key] = result;
      _errors[key] = null;
      return result;
    } on Exception catch (e) {
      _errors[key] = e;
      _data[key] = null;
      return null;
    } finally {
      _loadingStates[key] = false;
      notifyListeners();
    }
  }

  Future sendOTP() => fetchEndpoint('otp_send', _service.sendOTP);

  Future<Statistics?> loadStatistics() =>
      fetchEndpoint<Statistics>('statistics', _service.fetchStatistics);

  Future loadNotifications({required int userId}) => fetchEndpoint(
    'notifications',
    () => _service.fetchNotifications(userId: userId),
  );

  Future<List<ComplaintCategory>?> getCategories() =>
      fetchEndpoint<List<ComplaintCategory>>(
        'categories',
        () => _service.getCategories(),
      );

  Future<User?> getUserId({required String nid}) async {
    return fetchEndpoint<User>(
      'getUserId_$nid',
      () => _service.getUserId(nid: nid),
    );
  }

  Future<Complaint?> getComplaint({required int complaintId}) async {
    return fetchEndpoint<Complaint>(
      'getComplaint$complaintId',
      () => _service.getComplaint(complaintId: complaintId),
    );
  }

  Future<List<Complaint>?> getComplaints({
    required int userId,
    Map<String, dynamic>? queryParameters,
  }) async {
    return fetchEndpoint<List<Complaint>>(
      'getComplaints$userId',
      () => _service.getComplaints(
        userId: userId,
        queryParameters: queryParameters,
      ),
    );
  }

  Future<List<dynamic>?> getAttachments({required int complaintId}) async {
    return fetchEndpoint<List<dynamic>>(
      'getAttachment$complaintId',
      () => _service.getAttachments(complaintId: complaintId),
    );
  }

  Future verifyNid({required String nid, required String phoneNum}) async {
    return fetchEndpoint(
      'verifyNid_${nid}_$phoneNum',
      () => _service.verifyNid(nid: nid, phoneNum: phoneNum),
    );
  }

  Future verifyBrc({required String brc, required String dob}) async {
    return fetchEndpoint(
      'verifyBrc_${brc}_$dob',
      () => _service.verifyBrc(brc: brc, dob: dob),
    );
  }
}
