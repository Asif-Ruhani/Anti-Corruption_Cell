import 'dart:convert';
import 'package:app/core/models/category_model.dart';
import 'package:http/http.dart' as http;

import 'package:app/core/config/app_config.dart';
import 'package:app/core/models/complaint_model.dart';
import 'package:app/core/models/statistics_model.dart';
import 'package:app/core/models/user_model.dart';

class ApiService {
  final String baseUrl = AppConfig.baseUrl;

  T _handleResponse<T>(http.Response response) {
    if (response.statusCode == 200) {
      return json.decode(response.body) as T;
    } else {
      throw ApiException(
        statusCode: response.statusCode,
        message: 'Request failed with status ${response.statusCode}',
      );
    }
  }

  Exception _handleError(dynamic e) {
    print("Error: $e");
    return Exception('Request failed: ${e.toString()}');
  }

  Future<dynamic> get(
    String endpoint, {
    Map<String, dynamic>? queryParameters,
  }) async {
    try {
      final uri = Uri.parse(
        '$baseUrl$endpoint',
      ).replace(queryParameters: queryParameters);
      final response = await http.get(uri);
      return _handleResponse(response);
    } catch (e) {
      throw _handleError(e);
    }
  }

  Future sendOTP() async {
    try {
      await get("/users/otp/send");
    } catch (e) {
      throw _handleError(e);
    }
  }

  Future verifyOTP({required String otpCode}) async {
    try {
      await get("/users/otp/verify?rial_code=$otpCode");
    } catch (e) {
      throw _handleError(e);
    }
  }

  Future<User> getUserId({required String nid}) async {
    try {
      final body = await get("/users/getId", queryParameters: {'nid_num': nid});
      return User.fromJson(body);
    } catch (e) {
      throw _handleError(e);
    }
  }

  Future<Complaint> getComplaint({required int complaintId}) async {
    try {
      final body = await get("/complaints/$complaintId");
      return Complaint.fromJson(body);
      // return User.fromJson(body);
    } catch (e) {
      throw _handleError(e);
    }
  }

  Future<List<Complaint>> getComplaints({
    required int userId,
    Map<String, dynamic>? queryParameters,
  }) async {
    try {
      final resp = await get(
        "/complaints/?user_id=$userId",
        queryParameters: queryParameters,
      );
      final complaints =
          resp
              .map<Complaint>(
                (complaintJson) => Complaint.fromJson(complaintJson),
              )
              .toList();

      return complaints;
    } catch (e) {
      throw _handleError(e);
    }
  }

  Future<List<ComplaintCategory>> getCategories() async {
    try {
      final resp = await get("/categories");
      return resp
          .map<ComplaintCategory>((item) => ComplaintCategory.fromJson(item))
          .toList();
    } catch (e) {
      throw _handleError(e);
    }
  }

  Future<List<dynamic>> getAttachments({required int complaintId}) async {
    try {
      final body = await get("/attachments/complaint/$complaintId");
      return body;
    } catch (e) {
      throw _handleError(e);
    }
  }

  Future verifyNid({required String nid, required String phoneNum}) async {
    try {
      return await get(
        "/users/verify/nid",
        queryParameters: {'nid': nid, 'phone_num': phoneNum},
      );
    } catch (e) {
      throw _handleError(e);
    }
  }

  Future verifyBrc({required String brc, required String dob}) async {
    try {
      return await get(
        "/users/verify/breg",
        queryParameters: {'breg_num': brc, 'dob': dob},
      );
    } catch (e) {
      throw _handleError(e);
    }
  }

  Future<Statistics> fetchStatistics() async {
    final body = await get("/statistics");
    return Statistics.fromJson(json.decode(body));
  }

  Future fetchNotifications({required int userId}) async {
    final body = await get("/notifications/$userId");
    return body;
    // return Statistics.fromJson(json.decode(body));
  }
}

class ApiException implements Exception {
  final String message;
  final int? statusCode;

  ApiException({required this.message, this.statusCode});

  @override
  String toString() => message;
}
