import 'package:app/core/config/preferences_config.dart';
import 'package:app/core/providers/locale_provider.dart';
import 'package:flutter/material.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context);

    return Scaffold(
      appBar: AppBar(title: Text(localizations!.settings)),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [_buildLanguageTile(context, localizations)],
      ),
    );
  }

  // <----- Language Start ----->
  Widget _buildLanguageTile(
    BuildContext context,
    AppLocalizations localizations,
  ) {
    final currentLocale = Localizations.localeOf(context);

    return ListTile(
      leading: const Icon(Icons.language),
      title: Text(localizations.language),
      subtitle: Text(
        _getLanguageName(currentLocale.languageCode, localizations),
      ),
      onTap: () => _showLanguageDialog(context, localizations),
    );
  }

  String _getLanguageName(String languageCode, AppLocalizations localizations) {
    final languageMap = {
      'en': localizations.english,
      'bn': localizations.bangla,
    };
    return languageMap[languageCode] ?? localizations.english;
  }

  void _showLanguageDialog(
    BuildContext context,
    AppLocalizations localizations,
  ) {
    final localeProvider = context.read<LocaleProvider>();
    final currentLocale = localeProvider.locale;

    final List<Map<String, dynamic>> languages = [
      {
        'locale': const Locale('bn', 'BD'),
        'name': localizations.bangla,
        'lang_code': 'bn',
        'ctry_code': 'BD',
      },
      {
        'locale': const Locale('en', 'US'),
        'name': localizations.english,
        'lang_code': 'en',
        'ctry_code': 'US',
      },
    ];

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(localizations.chooseLanguage),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children:
                languages.map((lang) {
                  final locale = lang['locale'] as Locale;
                  return RadioListTile(
                    title: Text(lang['name']),
                    value: locale,
                    groupValue:
                        currentLocale.languageCode == locale.languageCode
                            ? locale
                            : null,
                    onChanged: (lang) {
                      if (lang != null) {
                        _changeLanguage(context, locale);
                      }
                    },
                  );
                }).toList(),
          ),
        );
      },
    );
  }

  void _changeLanguage(BuildContext context, Locale locale) async {
    Navigator.of(context).pop();

    final localeProvider = context.read<LocaleProvider>();
    localeProvider.setLocale(locale);

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(PreferencesConfig.appLanguage, locale.languageCode);
  }

  // <----- Language End ----->
}
