import 'package:app/core/models/complaint_model.dart';
import 'package:app/features/complaint/presentation/screens/complaint_detail_screen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:app/core/providers/api_provider.dart';
import 'package:app/core/config/preferences_config.dart';
import 'package:app/features/notification/presentation/widgets/notification_card.dart';

// TODO: Implement Notification Page
class NotificationScreen extends StatefulWidget {
  const NotificationScreen({super.key});

  @override
  State<NotificationScreen> createState() => _NotificationScreenState();
}

class _NotificationScreenState extends State<NotificationScreen> {
  late ApiServiceProvider apiProvider;
  List<Map<String, dynamic>> _notifications = [];
  bool _isLoading = true;
  bool _hasError = false;

  @override
  void initState() {
    super.initState();
    apiProvider = Provider.of<ApiServiceProvider>(context, listen: false);
    _fetchNotifications();
  }

  Future<void> _fetchNotifications() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final userId = prefs.getInt(PreferencesConfig.userId);
      final response = await apiProvider.loadNotifications(userId: userId!);

      setState(() {
        _notifications = List<Map<String, dynamic>>.from(response);
        _isLoading = false;
      });
    } catch (e) {
      setState(() {
        _hasError = true;
        _isLoading = false;
      });
    }
  }

  Future<void> _refreshNotifications() async {
    setState(() {
      _isLoading = true;
    });
    await _fetchNotifications();
  }

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context)!;

    return Scaffold(
      appBar: AppBar(title: Text(localizations.notification)),
      body: _buildBody(),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(child: CircularProgressIndicator());
    }

    if (_hasError) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline, size: 48, color: Colors.red),
            const SizedBox(height: 16),
            Text('Failed to load notifications'),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _refreshNotifications,
              child: const Text('Retry'),
            ),
          ],
        ),
      );
    }

    if (_notifications.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.notifications_off, size: 48, color: Colors.grey),
            const SizedBox(height: 16),
            Text('No notifications yet'),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _refreshNotifications,
      child: ListView.builder(
        itemCount: _notifications.length,
        itemBuilder: (context, index) {
          final notification = _notifications[index];
          return NotificationCard(
            complaintId: notification['complaint_id'],
            message: notification['message'],
            createdAt: notification['created_at'],
            onTap: () async {
              final complaint = await _loadComplaint(
                notification['complaint_id'],
              );

              if (complaint == null) {
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text('Failed to load complaint')),
                );
                return;
              }

              Navigator.push(
                context,
                MaterialPageRoute(
                  builder:
                      (context) => ComplaintDetailScreen(
                        complaintId: notification['complaint_id'],
                      ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  Future<Complaint?> _loadComplaint(int complaintId) {
    return apiProvider.getComplaint(complaintId: complaintId).catchError((
      error,
    ) {
      debugPrint('Error loading complaint: $error');
      return null;
    });
  }
}
