import 'package:flutter/material.dart';

class LoginOption extends StatelessWidget {
  final String option;
  final bool isSelected;
  final bool isFirst;
  final bool isLast;
  final VoidCallback onTap;

  static const _borderRadius = 12.0;
  static const _padding = EdgeInsets.symmetric(vertical: 16, horizontal: 20);
  static const _animationDuration = Duration(milliseconds: 200);

  const LoginOption({
    super.key,
    required this.option,
    required this.isSelected,
    required this.isFirst,
    required this.isLast,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;

    return AnimatedContainer(
      duration: _animationDuration,
      curve: Curves.easeInOut,
      decoration: BoxDecoration(
        color:
            isSelected
                ? colorScheme.primaryContainer
                : colorScheme.surface.withOpacity(0.7),
        borderRadius: _buildBorderRadius(),
        border: Border.all(
          color:
              isSelected
                  ? colorScheme.primary.withOpacity(0.3)
                  : colorScheme.outline.withOpacity(0.2),
          width: 1.5,
        ),
        boxShadow:
            isSelected
                ? [
                  BoxShadow(
                    color: colorScheme.primary.withOpacity(0.1),
                    blurRadius: 8,
                    spreadRadius: 2,
                    offset: const Offset(0, 2),
                  ),
                ]
                : null,
      ),
      child: Material(
        type: MaterialType.transparency,
        child: InkWell(
          borderRadius: _buildBorderRadius(),
          onTap: onTap,
          splashColor: colorScheme.primary.withOpacity(0.1),
          highlightColor: colorScheme.primary.withOpacity(0.05),
          child: Padding(
            padding: _padding,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  option,
                  style: theme.textTheme.titleMedium?.copyWith(
                    color:
                        isSelected
                            ? colorScheme.onPrimaryContainer
                            : colorScheme.onSurface,
                    fontWeight: isSelected ? FontWeight.w600 : FontWeight.w500,
                    letterSpacing: 0.2,
                  ),
                ),
                AnimatedSwitcher(
                  duration: _animationDuration,
                  transitionBuilder:
                      (child, animation) =>
                          ScaleTransition(scale: animation, child: child),
                  child:
                      isSelected
                          ? Icon(
                            Icons.check_circle_rounded,
                            color: colorScheme.primary,
                            size: 24,
                          )
                          : null,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  BorderRadius _buildBorderRadius() {
    return BorderRadius.only(
      topLeft: Radius.circular(isFirst ? _borderRadius : 0),
      topRight: Radius.circular(isFirst ? _borderRadius : 0),
      bottomLeft: Radius.circular(isLast ? _borderRadius : 0),
      bottomRight: Radius.circular(isLast ? _borderRadius : 0),
    );
  }
}
