import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

enum LoginType { nidPhone, brnDob }

// TODO: Improve Login Form
class LoginForm extends StatefulWidget {
  final GlobalKey<FormState> formKey;
  final TextEditingController controller1;
  final TextEditingController controller2;
  final void Function(String value1, String value2) onSubmitted;
  final String? error1;
  final String? error2;
  final bool isLoading;
  final AppLocalizations localizations;
  final LoginType loginType;

  const LoginForm({
    super.key,
    required this.formKey,
    required this.controller1,
    required this.controller2,
    required this.onSubmitted,
    required this.localizations,
    required this.loginType,
    this.error1,
    this.error2,
    this.isLoading = false,
  });

  @override
  State<LoginForm> createState() => _LoginFormState();
}

class _LoginFormState extends State<LoginForm> {
  DateTime? _selectedDate;

  @override
  void dispose() {
    super.dispose();
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? DateTime.now(),
      firstDate: DateTime(1940),
      lastDate: DateTime.now(),
    );
    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
        widget.controller2.text =
            "${picked.day}/${picked.month}/${picked.year}";
        widget.onSubmitted(widget.controller1.text, widget.controller2.text);
      });
    }
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String labelText,
    required IconData icon,
    required String? errorText,
    required TextInputType keyboardType,
    required String? Function(String?) validator,
    bool isDateField = false,
    BuildContext? context,
    void Function(String)? onFieldSubmitted,
  }) {
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(
        labelText: labelText,
        prefixIcon: !isDateField ? Icon(icon) : null,
        suffixIcon:
            isDateField
                ? IconButton(
                  icon: const Icon(Icons.calendar_today),
                  onPressed: () => _selectDate(context!),
                )
                : null,
        errorText: errorText,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
      ),
      keyboardType: keyboardType,
      readOnly: isDateField,
      validator: validator,
      onFieldSubmitted: onFieldSubmitted,
      inputFormatters:
          keyboardType == TextInputType.number
              ? [FilteringTextInputFormatter.digitsOnly]
              : null,
    );
  }

  String? _validateNID(String? value) {
    if (value == null || value.isEmpty) {
      return widget.localizations.requiredField;
    }
    if (value.length < 8) {
      return 'NID number must be at least 8 digits';
    }
    return null;
  }

  String? _validatePhone(String? value) {
    if (value == null || value.isEmpty) {
      return widget.localizations.requiredField;
    }
    if (value.length < 11) {
      return 'Phone number must be at least 11 digits';
    }
    return null;
  }

  String? _validateDOB(String? value) {
    if (value == null || value.isEmpty) {
      return widget.localizations.requiredField;
    }
    if (_selectedDate == null) {
      return 'Please select a valid date';
    }
    return null;
  }

  String? _validateBRN(String? value) {
    if (value == null || value.isEmpty) {
      return widget.localizations.requiredField;
    }
    if (!RegExp(r'^\d+$').hasMatch(value)) {
      return 'BRN must contain only numbers';
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: widget.formKey,
      child: Column(
        children: [
          if (widget.loginType == LoginType.nidPhone) ...[
            _buildTextField(
              controller: widget.controller1,
              labelText: widget.localizations.nid_num,
              icon: Icons.perm_identity_rounded,
              errorText: widget.error1,
              keyboardType: TextInputType.number,
              validator: _validateNID,
            ),
            const SizedBox(height: 20),
            _buildTextField(
              controller: widget.controller2,
              labelText: widget.localizations.phone_num,
              icon: Icons.phone,
              errorText: widget.error2,
              keyboardType: TextInputType.phone,
              validator: _validatePhone,
            ),
          ] else ...[
            _buildTextField(
              controller: widget.controller1,
              labelText: widget.localizations.brc_num,
              icon: Icons.assignment_ind,
              errorText: widget.error1,
              keyboardType: TextInputType.number,
              validator: _validateBRN,
            ),
            const SizedBox(height: 20),
            _buildTextField(
              controller: widget.controller2,
              labelText: 'Date of Birth',
              icon: Icons.calendar_month_outlined,
              errorText: widget.error2,
              keyboardType: TextInputType.datetime,
              validator: _validateDOB,
              isDateField: true,
              context: context,
            ),
          ],
          const SizedBox(height: 30),
        ],
      ),
    );
  }
}
