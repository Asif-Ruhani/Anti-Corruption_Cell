import 'package:app/features/auth/presentation/widgets/login_option.dart';
import 'package:flutter/material.dart';

class LoginTypeSelector extends StatelessWidget {
  final int selectedLoginType;
  final List<String> options;
  final ValueChanged<int> onSelected;

  const LoginTypeSelector({
    super.key,
    required this.selectedLoginType,
    required this.options,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    return ConstrainedBox(
      constraints: const BoxConstraints(maxWidth: 400),
      child: Container(
        width: double.infinity,
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.secondaryContainer,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: Theme.of(context).colorScheme.outlineVariant,
            width: 1,
          ),
        ),
        child: Column(
          children: List<Widget>.generate(
            options.length,
            (index) => LoginOption(
              option: options[index],
              isSelected: selectedLoginType == index,
              isFirst: index == 0,
              isLast: index == options.length - 1,
              onTap: () => onSelected(index),
            ),
          ),
        ),
      ),
    );
  }
}
