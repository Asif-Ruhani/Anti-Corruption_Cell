import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:app/core/config/preferences_config.dart';
import 'package:app/core/providers/api_provider.dart';
import 'package:app/features/auth/presentation/widgets/login_form.dart';
import 'package:app/features/auth/presentation/widgets/login_type_selector.dart';
import 'package:app/routes/routes.dart';

// TODO: Save user id on success
class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _nidController = TextEditingController();
  final _phoneController = TextEditingController();
  final _brnController = TextEditingController();
  final _dobController = TextEditingController();

  late final GlobalKey<FormState> _nidFormKey;
  late final GlobalKey<FormState> _brnFormKey;

  int _selectedLoginType = -1;
  bool _isLoading = false;

  void initState() {
    super.initState();
    _nidFormKey = GlobalKey<FormState>();
    _brnFormKey = GlobalKey<FormState>();
  }

  @override
  void dispose() {
    _nidController.dispose();
    _phoneController.dispose();
    _brnController.dispose();
    _dobController.dispose();
    super.dispose();
  }

  Future<void> _submitForm(
    BuildContext context,
    GlobalKey<FormState> formKey,
  ) async {
    final apiProvider = Provider.of<ApiServiceProvider>(context, listen: false);
    if (formKey.currentState?.validate() ?? false) {
      setState(() => _isLoading = true);
      dynamic resp;
      try {
        if (_selectedLoginType == 1) {
          resp = await apiProvider.verifyNid(
            nid: _nidController.text,
            phoneNum: _phoneController.text,
          );
        } else if (_selectedLoginType == 0) {
          resp = await apiProvider.verifyBrc(
            brc: _brnController.text,
            dob: _dobController.text,
          );
        }

        // TODO: Add Login Message Translation
        if (resp == null) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Login failed: Invalid Credential Provided'),
            ),
          );
        } else {
          // Get and Save userId after being verified
          final resp2 = await apiProvider.getUserId(nid: _nidController.text);
          if (resp2 != null) {
            final prefs = await SharedPreferences.getInstance();
            prefs.setInt(PreferencesConfig.userId, resp2.userId);
            prefs.setBool(PreferencesConfig.isLoggedIn, true);

            apiProvider.sendOTP();
            Navigator.pushNamed(context, AppRoutes.otp);
          }
        }
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Login failed: ${e.toString()}')),
        );
      } finally {
        setState(() => _isLoading = false);
      }
    }
  }

  Widget _buildCurrentForm(BuildContext context) {
    switch (_selectedLoginType) {
      case 1: // NID/Phone
        return LoginForm(
          formKey: _nidFormKey,
          controller1: _nidController,
          controller2: _phoneController,
          loginType: LoginType.nidPhone,
          onSubmitted: (nid, phone) {
            _nidController.text = nid;
            _phoneController.text = phone;
            _submitForm(context, _nidFormKey);
          },
          localizations: AppLocalizations.of(context)!,
          isLoading: _isLoading,
        );
      case 0: // BRN/DOB
        return LoginForm(
          formKey: _brnFormKey,
          controller1: _brnController,
          controller2: _dobController,
          loginType: LoginType.brnDob,
          onSubmitted: (brn, dob) {
            _brnController.text = brn;
            _dobController.text = dob;
            _submitForm(context, _brnFormKey);
          },
          localizations: AppLocalizations.of(context)!,
          isLoading: _isLoading,
        );
      default:
        return const SizedBox.shrink();
    }
  }

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context)!;
    final theme = Theme.of(context);

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Expanded(child: _buildContent(context, localizations, theme)),
            _buildContinueButton(localizations),
          ],
        ),
      ),
    );
  }

  Widget _buildContent(
    BuildContext context,
    AppLocalizations localizations,
    ThemeData theme,
  ) {
    final screenHeight = MediaQuery.of(context).size.height;

    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 24),
      child: ConstrainedBox(
        constraints: BoxConstraints(minHeight: screenHeight - 250),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Security icon
            Icon(
              Icons.security_outlined,
              size: 70,
              color: theme.iconTheme.color,
            ),
            const SizedBox(height: 24),

            // Header text
            Text(
              localizations.login_header,
              textAlign: TextAlign.center,
              style: theme.textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),

            // Subtitle text
            Text(
              localizations.login_type_select,
              textAlign: TextAlign.center,
              style: theme.textTheme.bodyMedium,
            ),
            const SizedBox(height: 32),

            // Login type selector
            LoginTypeSelector(
              selectedLoginType: _selectedLoginType,
              options: [localizations.brc, localizations.nid],
              onSelected: (index) {
                setState(() {
                  _selectedLoginType = index;
                });
              },
            ),
            const SizedBox(height: 28),

            _buildCurrentForm(context),
          ],
        ),
      ),
    );
  }

  Widget _buildContinueButton(AppLocalizations localizations) {
    return Container(
      width: double.maxFinite,
      padding: const EdgeInsets.symmetric(horizontal: 26, vertical: 54),
      child: FilledButton(
        onPressed:
            _isLoading
                ? null
                : () {
                  if (_selectedLoginType == 0) {
                    _submitForm(context, _brnFormKey);
                  } else if (_selectedLoginType == 1) {
                    _submitForm(context, _nidFormKey);
                  }
                },
        style: FilledButton.styleFrom(
          padding: const EdgeInsets.symmetric(vertical: 16),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        child:
            _isLoading
                ? const CircularProgressIndicator()
                : Text(
                  localizations.login_continue,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
      ),
    );
  }
}
