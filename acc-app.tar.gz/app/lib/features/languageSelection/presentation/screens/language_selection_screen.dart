import 'package:app/core/config/preferences_config.dart';
import 'package:app/core/providers/locale_provider.dart';
import 'package:app/routes/routes.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LanguageSelectionScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // App Logo/Title
              const Icon(Icons.translate, size: 80, color: Colors.blue),
              const SizedBox(height: 20),
              Text(
                "Choose Language",
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 40),

              // Language Cards
              _LanguageCard(
                language: "English",
                flag: '🇬🇧',
                onTap: () => _changeLanguage(context, Locale('en', 'US')),
              ),
              const SizedBox(height: 20),
              _LanguageCard(
                language: "বাংলা",
                flag: '🇧🇩',
                onTap: () => _changeLanguage(context, Locale('bn', 'BD')),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _changeLanguage(BuildContext context, Locale locale) async {
    final localeProvider = context.read<LocaleProvider>();
    localeProvider.setLocale(locale);

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(PreferencesConfig.appLanguage, locale.languageCode);

    Navigator.of(context).pushNamed(AppRoutes.login);
  }
}

class _LanguageCard extends StatelessWidget {
  final String language;
  final String flag;
  final VoidCallback onTap;

  const _LanguageCard({
    required this.language,
    required this.flag,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            children: [
              Text(flag, style: const TextStyle(fontSize: 32)),
              const SizedBox(width: 20),
              Text(language, style: const TextStyle(fontSize: 18)),
              const Spacer(),
              const Icon(Icons.chevron_right, color: Colors.grey),
            ],
          ),
        ),
      ),
    );
  }
}
