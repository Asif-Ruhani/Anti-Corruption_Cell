import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class EvidenceUploader extends StatefulWidget {
  final void Function(List<File>) onFilesSelected;

  const EvidenceUploader({super.key, required this.onFilesSelected});

  @override
  State<EvidenceUploader> createState() => _EvidenceUploaderState();
}

class _EvidenceUploaderState extends State<EvidenceUploader> {
  List<File> _selectedFiles = [];

  Future<void> _pickFiles() async {
    try {
      final pickedFiles = await ImagePicker().pickMultiImage(imageQuality: 85);
      if (pickedFiles.isEmpty) return;

      setState(() {
        _selectedFiles = pickedFiles.map((file) => File(file.path)).toList();
      });
      widget.onFilesSelected(_selectedFiles);
    } catch (e) {
      debugPrint('File picker error: $e');
    }
  }

  void _removeFile(int index) {
    setState(() {
      _selectedFiles.removeAt(index);
    });
    widget.onFilesSelected(_selectedFiles);
  }

  Widget _buildUploadArea() => GestureDetector(
    onTap: _pickFiles,
    behavior: HitTestBehavior.opaque,
    child: Container(
      height: 120,
      width: double.maxFinite,
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey),
        borderRadius: BorderRadius.circular(8),
      ),
      child: const Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(Icons.cloud_upload, size: 40, color: Colors.grey),
          SizedBox(height: 8),
          Text('Tap to upload evidence', style: TextStyle(color: Colors.grey)),
        ],
      ),
    ),
  );

  Widget _buildThumbnail(File file, int index) => Stack(
    clipBehavior: Clip.none,
    children: [
      Container(
        width: 80,
        height: 80,
        decoration: BoxDecoration(
          border: Border.all(color: Colors.grey),
          borderRadius: BorderRadius.circular(4),
        ),
        child: Image.file(file, fit: BoxFit.cover),
      ),
      Positioned(
        top: -4,
        right: -4,
        child: GestureDetector(
          onTap: () => _removeFile(index),
          child: Container(
            decoration: const BoxDecoration(
              color: Colors.red,
              shape: BoxShape.circle,
            ),
            padding: const EdgeInsets.all(2),
            child: const Icon(Icons.close, size: 14, color: Colors.white),
          ),
        ),
      ),
    ],
  );

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _buildUploadArea(),
        if (_selectedFiles.isNotEmpty) ...[
          const SizedBox(height: 16),
          Text(
            'Selected files (${_selectedFiles.length})',
            style: const TextStyle(fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: List.generate(
              _selectedFiles.length,
              (index) => _buildThumbnail(_selectedFiles[index], index),
            ),
          ),
        ],
      ],
    );
  }
}
