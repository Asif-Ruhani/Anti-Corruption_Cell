import 'package:flutter/material.dart';

import 'package:app/core/utils/status_util.dart';

class ComplaintStatusChip extends StatelessWidget {
  final String status;

  const ComplaintStatusChip({super.key, required this.status});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.maxFinite,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
      decoration: BoxDecoration(
        color: getComplaintStatusColor(status).withOpacity(0.3),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: getComplaintStatusColor(status), width: 1),
      ),
      child: Text(
        getTranslatedComplaintStatus(context, status),
        textAlign: TextAlign.center,
        style: TextStyle(
          color: Theme.of(context).colorScheme.onSurface,
          fontWeight: FontWeight.bold,
          fontSize: 12,
        ),
      ),
    );
  }
}
