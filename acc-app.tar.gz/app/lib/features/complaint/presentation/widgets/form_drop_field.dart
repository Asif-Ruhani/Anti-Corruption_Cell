import 'package:flutter/material.dart';

class FormDropField<T> extends StatelessWidget {
  final T? value;
  final String hintText;
  final bool isDarkMode;
  final List<DropdownMenuItem<T>> items;
  final void Function(T?)? onChanged;
  final String? Function(T?)? validator;
  final Widget Function(T)? itemBuilder;
  final String? Function(T)? displayValue;

  const FormDropField({
    super.key,
    required this.value,
    required this.hintText,
    required this.isDarkMode,
    required this.items,
    this.onChanged,
    this.validator,
    this.itemBuilder,
    this.displayValue,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return DropdownButtonFormField<T>(
      value: value,
      decoration: InputDecoration(
        hintText: hintText,
        filled: true,
        fillColor:
            isDarkMode
                ? theme.colorScheme.surfaceContainerHighest.withOpacity(0.5)
                : theme.colorScheme.surfaceContainerHighest.withOpacity(0.3),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide.none,
        ),
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 12,
        ),
        errorMaxLines: 2,
      ),
      items: items,
      onChanged: onChanged,
      validator: validator,
      dropdownColor: theme.colorScheme.surfaceContainerHighest,
      borderRadius: BorderRadius.circular(12),
      selectedItemBuilder:
          itemBuilder != null
              ? (context) {
                return items.map((item) {
                  return itemBuilder!(item.value!);
                }).toList();
              }
              : null,
      hint: Text(
        hintText,
        style: TextStyle(color: theme.colorScheme.onSurface.withOpacity(0.6)),
      ),
    );
  }
}
