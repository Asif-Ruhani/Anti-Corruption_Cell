import 'package:app/core/config/app_config.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';

import 'package:app/core/models/complaint_model.dart';
import 'package:app/core/providers/api_provider.dart';
import 'package:app/core/utils/category_util.dart';
import 'package:app/core/utils/date_util.dart';
import 'package:app/core/utils/location_util.dart';
import 'package:app/features/complaint/presentation/widgets/complaint_attachments.dart';
import 'package:app/features/complaint/presentation/widgets/complaint_meta_item.dart';
import 'package:app/features/complaint/presentation/widgets/complaint_section.dart';
import 'package:app/features/complaint/presentation/widgets/complaint_status_chip.dart';

class ComplaintDetailScreen extends StatefulWidget {
  final int complaintId;

  const ComplaintDetailScreen({super.key, required this.complaintId});

  @override
  State<ComplaintDetailScreen> createState() => _ComplaintPageState();
}

class _ComplaintPageState extends State<ComplaintDetailScreen> {
  late ThemeData theme;
  late Future<Complaint?> _complaintFuture;
  late Future<List<dynamic>?> _attachmentFuture;

  @override
  void initState() {
    super.initState();
    _initializeData();
  }

  Future<void> _initializeData() async {
    final apiProvider = context.read<ApiServiceProvider>();
    _complaintFuture = apiProvider.getComplaint(
      complaintId: widget.complaintId,
    );

    _attachmentFuture = apiProvider.getAttachments(
      complaintId: widget.complaintId,
    );
  }

  @override
  Widget build(BuildContext context) {
    theme = Theme.of(context);
    final localizations = AppLocalizations.of(context)!;

    return Scaffold(
      appBar: AppBar(
        title: Text(localizations.complaint_details),
        elevation: 1,
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          setState(() {
            _initializeData();
          });
          await _complaintFuture;
        },
        child: FutureBuilder<Complaint?>(
          future: _complaintFuture,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(child: CircularProgressIndicator());
            }

            if (!snapshot.hasData || snapshot.data == null) {
              return const Center(child: Text('Failed to get your complaint'));
            }

            return Scaffold(
              body: Column(
                children: [
                  Expanded(
                    child: SingleChildScrollView(
                      physics: const AlwaysScrollableScrollPhysics(),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          _buildComplaintDetails(snapshot.data!, localizations),
                          const SizedBox(height: 24),
                        ],
                      ),
                    ),
                  ),

                  if (snapshot.data?.status == 'pending')
                    Padding(
                      padding: const EdgeInsets.all(20),
                      child: ElevatedButton(
                        onPressed:
                            () => _deleteComplaint(
                              snapshot.data?.complaintId,
                              localizations,
                            ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Theme.of(context).colorScheme.error,
                          foregroundColor:
                              Theme.of(context).colorScheme.onError,
                          minimumSize: const Size.fromHeight(50),
                        ),
                        child: const Text('Delete'),
                      ),
                    ),
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildComplaintDetails(
    Complaint complaint,
    AppLocalizations localizations,
  ) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(20),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Center(child: ComplaintStatusChip(status: complaint.status)),
          const SizedBox(height: 16),
          Text(
            complaint.title,
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),

          // Complaint meta data
          Wrap(
            spacing: 16,
            runSpacing: 8,
            children: [
              ComplaintMetaItem(
                icon: Icons.calendar_today_rounded,
                text: formatDate(
                  context,
                  complaint.createdAt.toString(),
                  'MMM d, y',
                ),
              ),
              ComplaintMetaItem(
                icon: Icons.location_city_rounded,
                text: getTranslatedDivision(context, complaint.city),
              ),
              ComplaintMetaItem(
                icon: Icons.category_rounded,
                text: catIdTocatName(context, complaint.complaintId),
              ),
            ],
          ),
          const SizedBox(height: 24),

          // Address section
          ComplaintSection(
            icon: Icons.map,
            title: localizations.address,
            content: complaint.address,
          ),
          const SizedBox(height: 24),

          // Description section
          ComplaintSection(
            icon: Icons.description,
            title: localizations.description,
            content: complaint.description,
          ),
          const SizedBox(height: 24),

          // Attachment section
          ComplaintAttachments(attachmentFuture: _attachmentFuture),
        ],
      ),
    );
  }

  void _deleteComplaint(
    int? complaintId,
    AppLocalizations localizations,
  ) async {
    if (complaintId == null) return;

    final uri = Uri.parse('${AppConfig.baseUrl}/complaints/$complaintId');
    var request = await http.delete(uri);

    if (request.statusCode == 200) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(localizations.deleted_complaint_msg)),
      );
      Navigator.of(context).pop();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(localizations.deleted_complaint_failed_msg)),
      );
    }
  }
}
