import 'dart:convert';
import 'dart:io';
import 'package:app/core/config/app_config.dart';
import 'package:app/core/config/preferences_config.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';

import 'package:app/core/models/category_model.dart';
import 'package:app/core/providers/api_provider.dart';
import 'package:app/core/utils/category_util.dart';
import 'package:app/core/utils/form_validators.dart';
import 'package:app/core/utils/location_util.dart';
import 'package:app/features/complaint/presentation/widgets/form_drop_field.dart';
import 'package:app/features/complaint/presentation/widgets/form_evidence_uploader.dart';
import 'package:app/features/complaint/presentation/widgets/form_text_field.dart';
import 'package:app/features/complaint/presentation/widgets/form_section_header.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ComplaintFormScreen extends StatefulWidget {
  const ComplaintFormScreen({super.key});

  @override
  State<ComplaintFormScreen> createState() => _ComplaintFormScreenState();
}

class _ComplaintFormScreenState extends State<ComplaintFormScreen> {
  late ApiServiceProvider apiProvider;
  late List<ComplaintCategory>? _categories = [];

  final _formKey = GlobalKey<FormState>();
  final _titleController = TextEditingController();
  final _descriptionController = TextEditingController();
  final _addressController = TextEditingController();
  String? _selectedCategoryId;
  String? _selectedDivsion;
  List<File> _evidenceFiles = [];

  @override
  void initState() {
    super.initState();
    apiProvider = context.read<ApiServiceProvider>();
    _loadComplaintCategories();
  }

  Future _loadComplaintCategories() async {
    final categories = await apiProvider.getCategories();

    setState(() {
      _categories = categories;
    });
  }

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _addressController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final isDarkMode = theme.brightness == Brightness.dark;
    final localizations = AppLocalizations.of(context)!;

    return Scaffold(
      appBar: AppBar(title: Text(localizations.new_complaint), elevation: 0),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Details Group
              SectionHeader(title: localizations.complaint_details),
              const SizedBox(height: 16),

              // Title Field
              FormTextField(
                controller: _titleController,
                hintText: localizations.complaint_title_placeholder,
                isDarkMode: isDarkMode,
                validator:
                    (value) => FormValidators.required(
                      value,
                      errorMessage: localizations.requiredField,
                    ),
              ),

              const SizedBox(height: 16),

              // Category Field
              FormDropField<String>(
                value: _selectedCategoryId,
                hintText: localizations.select_category,
                isDarkMode: theme.brightness == Brightness.dark,
                items:
                    _categories
                        ?.map<DropdownMenuItem<String>>(
                          (category) => DropdownMenuItem<String>(
                            value: category.id.toString(),
                            child: Text(catIdTocatName(context, category.id)),
                          ),
                        )
                        .toList() ??
                    [],
                onChanged: (value) {
                  setState(() {
                    _selectedCategoryId = value;
                  });
                },
                validator:
                    (value) => FormValidators.required(
                      value,
                      errorMessage: localizations.requiredField,
                    ),
              ),
              const SizedBox(height: 16),

              // Description Field
              FormTextField(
                controller: _descriptionController,
                hintText: localizations.complaint_description_placeholder,
                isDarkMode: isDarkMode,
                maxLines: 5,
                validator:
                    (value) => FormValidators.required(
                      value,
                      errorMessage: localizations.requiredField,
                    ),
              ),
              const SizedBox(height: 32),

              // Location Section
              SectionHeader(title: localizations.location_details),
              const SizedBox(height: 16),
              
              FormDropField<String>(
                value: _selectedDivsion,
                hintText: localizations.select_division,
                isDarkMode: theme.brightness == Brightness.dark,
                items:
                    [
                      'Dhaka',
                      'Chattogram',
                      'Sylhet',
                      'Rajshahi',
                      'Khulna',
                      'Barishal',
                      'Rangpur',
                      'Mymensingh',
                    ].map((division) {
                      return DropdownMenuItem<String>(
                        value: division.toLowerCase(),
                        child: Text(getTranslatedDivision(context, division)),
                      );
                    }).toList(),
                onChanged: (value) {
                  setState(() {
                    _selectedDivsion = value;
                  });
                },
                validator:
                    (value) => FormValidators.required(
                      value,
                      errorMessage: localizations.requiredField,
                    ),
              ),

              const SizedBox(height: 16),
              FormTextField(
                controller: _addressController,
                hintText: localizations.complaint_location_placeholder,
                isDarkMode: isDarkMode,
                validator:
                    (value) => FormValidators.required(
                      value,
                      errorMessage: localizations.requiredField,
                    ),
              ),
              const SizedBox(height: 32),

              // Attachment Section
              SectionHeader(title: localizations.evidences),
              const SizedBox(height: 16),
              EvidenceUploader(
                onFilesSelected: (files) {
                  setState(() {
                    _evidenceFiles = files;
                  });
                },
              ),

              const SizedBox(height: 40),

              // Submit Button
              SizedBox(
                width: double.infinity,
                child: FilledButton(
                  onPressed: () => _submitComplaint(localizations),
                  style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  child: Text(
                    localizations.submit,
                    style: TextStyle(fontSize: 16),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _submitComplaint(AppLocalizations localizations) async {
    if (!_formKey.currentState!.validate()) return;
    if (_evidenceFiles.isEmpty) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(localizations.no_evidences_msg)));
      return;
    }

    debugPrint(_evidenceFiles.isEmpty.toString());

    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (context) {
        return const Center(child: CircularProgressIndicator());
      },
    );

    try {
      final prefs = await SharedPreferences.getInstance();
      final userId = prefs.getInt(PreferencesConfig.userId);
      if (userId == null) throw Exception("UserId not found");

      // Prepare the complaint data
      final complaintData = {
        'user_id': userId,
        'title': _titleController.text,
        'cat_id': int.parse(_selectedCategoryId ?? '0'),
        'desc': _descriptionController.text,
        'city': _selectedDivsion,
        'address': _addressController.text,
        'status': 'pending',
        'created_at': DateTime.now().toIso8601String(),
        'modified_at': DateTime.now().toIso8601String(),
      };

      final response = await http.post(
        Uri.parse("${AppConfig.baseUrl}/complaints/create"),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode(complaintData),
      );

      var data = json.decode(response.body);
      await uploadEvidences(data['complaint_id']);

      Navigator.of(context).pop();
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text(localizations.submitted_complain)));
    } catch (e) {
      Navigator.of(context).pop();
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Failed to submit complaint: $e')));
    } finally {
      Navigator.of(context).pop();
    }
  }

  Future<void> uploadEvidences(int complaintId) async {
    final uri = Uri.parse(
      '${AppConfig.baseUrl}/attachments/upload?complaint_id=$complaintId',
    );
    var request = http.MultipartRequest('POST', uri);

    for (var file in _evidenceFiles) {
      request.files.add(await http.MultipartFile.fromPath('files', file.path));
    }

    try {
      final response = await request.send();

      if (response.statusCode != 200) {
        throw Exception(
          'File upload failed with status ${response.statusCode}',
        );
      }

      final responseBody = await response.stream.bytesToString();
      debugPrint('Uploaded Attachment: $responseBody');
    } catch (error) {
      debugPrint('Error uploading file: $error');
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Upload failed: $error')));
    }
  }
}
