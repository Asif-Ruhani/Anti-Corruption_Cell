import 'package:flutter/material.dart';

import 'package:app/core/models/complaint_model.dart';
import 'package:app/core/utils/category_util.dart';
import 'package:app/core/utils/date_util.dart';
import 'package:app/core/utils/location_util.dart';
import 'package:app/core/utils/status_util.dart';
import 'package:app/features/complaint/presentation/screens/complaint_detail_screen.dart';

class ComplaintCard extends StatelessWidget {
  final Complaint complaint;
  final VoidCallback? onTap;

  const ComplaintCard({super.key, required this.complaint, this.onTap});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final greyColor =
        theme.brightness == Brightness.dark
            ? Colors.grey.shade400
            : Colors.grey.shade600;

    return Card(
      margin: const EdgeInsets.symmetric(vertical: 6, horizontal: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      elevation: 1,
      color: Theme.of(context).cardTheme.color,
      child: Material(
        type: MaterialType.transparency,
        borderRadius: BorderRadius.circular(12),
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap:
              () => {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder:
                        (context) => ComplaintDetailScreen(
                          complaintId: complaint.complaintId,
                        ),
                  ),
                ),
              },
          splashColor: theme.colorScheme.primary.withOpacity(0.1),
          highlightColor: theme.colorScheme.primary.withOpacity(0.05),
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildHeaderRow(context, greyColor),
                const SizedBox(height: 8),
                _buildTitle(theme),
                const SizedBox(height: 12),
                _buildLocationRow(greyColor),
                const SizedBox(height: 18),
                _buildChipsRow(context),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeaderRow(BuildContext context, Color greyColor) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          '#${getDivisionShortCode(complaint.city)}-${complaint.complaintId.toString().padLeft(3, '0')}',
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
            color: greyColor,
            fontWeight: FontWeight.bold,
          ),
        ),
        Text(
          formatDate(context, complaint.createdAt.toString(), 'MMM d, y'),
          style: Theme.of(
            context,
          ).textTheme.bodySmall?.copyWith(color: greyColor),
        ),
      ],
    );
  }

  Widget _buildTitle(ThemeData theme) {
    return Text(
      complaint.title,
      style: theme.textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w600),
      maxLines: 2,
      overflow: TextOverflow.ellipsis,
    );
  }

  Widget _buildLocationRow(Color greyColor) {
    return Row(
      children: [
        Icon(Icons.location_on, size: 16, color: greyColor),
        const SizedBox(width: 6),
        Expanded(
          child: Text(
            complaint.address.isNotEmpty ? complaint.address : complaint.city,
            style: TextStyle(fontSize: 13, color: greyColor),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }

  Widget _buildChipsRow(BuildContext context) {
    return Row(
      children: [
        _buildChip(
          getTranslatedComplaintStatus(context, complaint.status),
          getComplaintStatusColor(complaint.status),
          FontWeight.w600,
        ),
        const SizedBox(width: 8),
        _buildChip(
          catIdTocatName(context, complaint.categoryId),
          Colors.blue,
          FontWeight.w500,
        ),
      ],
    );
  }

  Widget _buildChip(String text, Color color, FontWeight fontWeight) {
    return Chip(
      backgroundColor: color.withOpacity(0.12),
      side: BorderSide(color: color.withOpacity(0.3), width: 1),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      label: Text(
        text,
        style: TextStyle(
          color: color,
          fontSize: 11.5,
          fontWeight: fontWeight,
          letterSpacing: text == text.toUpperCase() ? 0.3 : 0,
        ),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 10),
      visualDensity: VisualDensity.compact,
    );
  }
}
