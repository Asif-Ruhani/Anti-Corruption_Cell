import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:app/core/config/preferences_config.dart';
import 'package:app/features/home/presentation/widgets/side_drawer/drawer_header.dart';
import 'package:app/features/home/presentation/widgets/side_drawer/drawer_item.dart';
import 'package:app/routes/routes.dart';

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context)!;

    return Drawer(
      child: ListView(
        children: [
          const CustomDrawerHeader(),

          CustomDrawerItem(
            icon: Icons.settings,
            title: localizations.settings,
            onTap: () => _navigateTo(context, AppRoutes.settings),
          ),
          // CustomDrawerItem(
          //   icon: Icons.support_agent,
          //   title: localizations.support,
          //   onTap: () => _navigateTo(context, AppRoutes.support),
          // ),
          CustomDrawerItem(
            icon: Icons.info_outline,
            title: localizations.about,
            onTap: () => _navigateTo(context, AppRoutes.about),
          ),

          const Divider(),

          CustomDrawerItem(
            icon: Icons.logout,
            title: localizations.signout,
            onTap: () => _showLogoutConfirmation(context),
          ),
        ],
      ),
    );
  }

  void _navigateTo(BuildContext context, String routeName) {
    Navigator.of(context).pop();
    Navigator.of(context).pushNamed(routeName);
  }

  void _showLogoutConfirmation(BuildContext context) {
    final localizations = AppLocalizations.of(context)!;
    final theme = Theme.of(context);

    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            title: Text(localizations.confirmSignout),
            content: Text(localizations.confirmSignout),
            actions: [
              // Cancel Button
              TextButton(
                onPressed: () async {
                  Navigator.of(context).pop();
                },
                child: Text(localizations.cancel),
              ),
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  _performLogout(context);
                },
                child: Text(
                  localizations.signout,
                  style: TextStyle(color: theme.colorScheme.error),
                ),
              ),
            ],
          ),
    );
  }

  Future<void> _performLogout(BuildContext context) async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setBool(PreferencesConfig.isLoggedIn, false);

    Navigator.popAndPushNamed(context, AppRoutes.login);
  }
}
