import 'package:flutter/material.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

// TODO: Implement Search by Query
class AdvancedSearchDialog extends StatefulWidget {
  final String? query;
  final Map<String, String?>? filters;

  const AdvancedSearchDialog({
    super.key,
    required this.query,
    required this.filters,
  });

  @override
  State<AdvancedSearchDialog> createState() => _AdvancedSearchDialogState();
}

class _AdvancedSearchDialogState extends State<AdvancedSearchDialog> {
  final _formKey = GlobalKey<FormState>();
  final _query = ValueNotifier<String?>(null);
  final _status = ValueNotifier<String?>(null);
  final _location = ValueNotifier<String?>(null);
  final _category = ValueNotifier<String?>(null);

  static const _padding = EdgeInsets.all(16.0);
  static const _borderRadius = BorderRadius.all(Radius.circular(8.0));
  static const _spacing = SizedBox(height: 12.0);
  static const _doubleSpacing = SizedBox(height: 24.0);

  @override
  void initState() {
    super.initState();
    _query.value = widget.query;
    _status.value = widget.filters?['status'];
    _location.value = widget.filters?['location'];
    _category.value = widget.filters?['category'];
  }

  @override
  void dispose() {
    _query.dispose();
    _status.dispose();
    _location.dispose();
    _category.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context)!;
    final theme = Theme.of(context);

    return Dialog(
      insetPadding: _padding,
      shape: const RoundedRectangleBorder(borderRadius: _borderRadius),
      child: SingleChildScrollView(
        child: Form(
          key: _formKey,
          child: Padding(
            padding: _padding,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _buildHeader(theme, localizations),
                _doubleSpacing,

                // _buildSearchField(localizations),
                // _spacing,
                _buildDropdown(
                  label: localizations.dialog_status,
                  notifier: _status,
                  items: _statusOptions(localizations),
                ),
                _spacing,

                _buildDropdown(
                  label: localizations.dialog_location,
                  notifier: _location,
                  items: _locationOptions(localizations),
                ),
                _spacing,

                _buildDropdown(
                  label: localizations.dialog_category,
                  notifier: _category,
                  items: _categoryOptions(localizations),
                ),

                _doubleSpacing,

                _buildActionButtons(localizations),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(ThemeData theme, AppLocalizations localizations) => Row(
    children: [
      Expanded(
        child: Text(
          localizations.dialog_advancedSearch,
          style: theme.textTheme.titleLarge?.copyWith(
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      IconButton(
        icon: const Icon(Icons.close),
        onPressed: () => Navigator.pop(context),
        tooltip: localizations.cancel,
      ),
    ],
  );

  Widget _buildSearchField(AppLocalizations localizations) => TextFormField(
    decoration: InputDecoration(
      prefixIcon: const Icon(Icons.search),
      border: const OutlineInputBorder(borderRadius: _borderRadius),
      labelText: localizations.dialog_search,
      contentPadding: const EdgeInsets.symmetric(
        vertical: 12.0,
        horizontal: 16.0,
      ),
    ),
    textInputAction: TextInputAction.next,
  );

  Widget _buildDropdown({
    required String label,
    required ValueNotifier<String?> notifier,
    required List<Map<String, dynamic>> items,
  }) => ValueListenableBuilder<String?>(
    valueListenable: notifier,
    builder:
        (context, value, _) => DropdownButtonFormField<String>(
          value: value,
          decoration: InputDecoration(
            labelText: label,
            border: const OutlineInputBorder(borderRadius: _borderRadius),
            contentPadding: const EdgeInsets.symmetric(
              horizontal: 16.0,
              vertical: 12.0,
            ),
          ),
          items:
              items
                  .map(
                    (item) => DropdownMenuItem<String>(
                      value: item['key'].toString(),
                      child: Text(item['value']),
                    ),
                  )
                  .toList(),
          onChanged: (newValue) => notifier.value = newValue,
          isExpanded: true,
        ),
  );

  Widget _buildActionButtons(AppLocalizations localizations) => Row(
    children: [
      Expanded(
        child: OutlinedButton(
          onPressed: _resetFilters,
          style: OutlinedButton.styleFrom(
            padding: const EdgeInsets.symmetric(vertical: 16.0),
            shape: const RoundedRectangleBorder(borderRadius: _borderRadius),
          ),
          child: Text(localizations.reset),
        ),
      ),
      const SizedBox(width: 12.0),
      Expanded(
        child: ElevatedButton(
          onPressed: _submitSearch,
          style: ElevatedButton.styleFrom(
            padding: const EdgeInsets.symmetric(vertical: 16.0),
            shape: const RoundedRectangleBorder(borderRadius: _borderRadius),
          ),
          child: Text(localizations.submit),
        ),
      ),
    ],
  );

  List<Map<String, dynamic>> _statusOptions(AppLocalizations localizations) {
    return [
      {'key': "pending", 'value': localizations.pending},
      {'key': "processing", 'value': localizations.processing},
      {'key': "rejected", 'value': localizations.rejected},
      {'key': "solved", 'value': localizations.solved},
    ];
  }

  List<Map<String, dynamic>> _locationOptions(AppLocalizations localizations) {
    return [
      {'key': "barishal", 'value': localizations.barishal},
      {'key': "chattogram", 'value': localizations.chattogram},
      {'key': "dhaka", 'value': localizations.dhaka},
      {'key': "khulna", 'value': localizations.khulna},
      {'key': "mymensingh", 'value': localizations.mymensingh},
      {'key': "rajshahi", 'value': localizations.rajshahi},
      {'key': "rangpur", 'value': localizations.rangpur},
      {'key': "sylhet", 'value': localizations.sylhet},
    ];
  }

  List<Map<String, dynamic>> _categoryOptions(AppLocalizations localizations) {
    return [
      {'key': 1, 'value': localizations.extortion},
      {'key': 2, 'value': localizations.embezzlement},
      {'key': 3, 'value': localizations.bureaucracy},
      {'key': 4, 'value': localizations.nepotism},
      {'key': 5, 'value': localizations.fraud},
      {'key': 6, 'value': localizations.others},
      {'key': 7, 'value': localizations.bribery},
      {'key': 8, 'value': localizations.money_laundering},
      {'key': 9, 'value': localizations.tax_evasion},
      {'key': 10, 'value': localizations.corruption},
    ];
  }

  void _resetFilters() {
    _formKey.currentState?.reset();
    _query.value = '';
    _status.value = null;
    _location.value = null;
    _category.value = null;
  }

  void _submitSearch() {
    if (_formKey.currentState?.validate() ?? false) {
      _formKey.currentState?.save();
      _formKey.currentState?.save();
      Navigator.pop(context, {
        'query': _query.value,
        'filters': {
          'status': _status.value,
          'location': _location.value,
          'category': _category.value,
        },
      });

      // test
      // Navigator.pop(context);
    }
  }
}
