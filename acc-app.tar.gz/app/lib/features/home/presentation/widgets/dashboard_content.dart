import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'package:app/core/config/preferences_config.dart';
import 'package:app/core/models/complaint_model.dart';
import 'package:app/core/providers/api_provider.dart';
import 'package:app/features/complaint/presentation/screens/complaint_detail_screen.dart';
import 'package:app/features/home/presentation/widgets/complaint/complaint_card.dart';

class DashboardContent extends StatefulWidget {
  final VoidCallback? onRefresh;
  final String? currentSearchQuery;
  final Map<String, String?>? currentFilters;

  const DashboardContent({
    super.key,
    this.onRefresh,
    this.currentFilters,
    this.currentSearchQuery,
  });

  @override
  State<DashboardContent> createState() => _DashboardContentState();
}

class _DashboardContentState extends State<DashboardContent> {
  Future<List<Complaint>?>? _complaintsFuture;
  late SharedPreferences _prefs;
  late ApiServiceProvider _apiProvider;

  @override
  void initState() {
    super.initState();
    _initializeData();
  }

  @override
  void didUpdateWidget(DashboardContent oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.currentSearchQuery != oldWidget.currentSearchQuery ||
        widget.currentFilters != oldWidget.currentFilters) {
      _loadComplaints();
    }
  }

  Future<void> _initializeData() async {
    _prefs = await SharedPreferences.getInstance();
    _apiProvider = context.read<ApiServiceProvider>();
    _loadComplaints();
  }

  Future<void> _loadComplaints() async {
    final userId = _prefs.getInt(PreferencesConfig.userId);
    if (userId == null) {
      setState(() {
        _complaintsFuture = Future.error('User not authenticated');
      });

      return;
    }

    final params = <String, String>{
      if (widget.currentFilters?['status'] != null &&
          widget.currentFilters!['status']!.isNotEmpty)
        'status': widget.currentFilters!['status']!,
      if (widget.currentFilters?['category'] != null &&
          widget.currentFilters!['category']!.isNotEmpty)
        'cat_id': widget.currentFilters!['category']!,
      if (widget.currentFilters?['location'] != null &&
          widget.currentFilters!['location']!.isNotEmpty)
        'city': widget.currentFilters!['location']!,
      'user_id': userId.toString(),
    };

    setState(() {
      _complaintsFuture = _apiProvider.getComplaints(
        userId: userId,
        queryParameters: params,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<Complaint>?>(
      future: _complaintsFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Center(child: CircularProgressIndicator());
        }

        if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        }

        final complaints = snapshot.data ?? [];

        return RefreshIndicator(
          onRefresh: () async {
            await _loadComplaints();
            widget.onRefresh?.call();
          },
          child:
              complaints.isEmpty
                  ? const Center(child: Text('No complaints found'))
                  : ListView.builder(
                    padding: const EdgeInsets.all(8.0),
                    itemCount: complaints.length,
                    itemBuilder:
                        (context, index) => ComplaintCard(
                          complaint: complaints[index],
                          onTap:
                              () =>
                                  _navigateToDetail(context, complaints[index]),
                        ),
                  ),
        );
      },
    );
  }

  void _navigateToDetail(BuildContext context, Complaint complaint) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder:
            (context) =>
                ComplaintDetailScreen(complaintId: complaint.complaintId),
      ),
    );
  }
}
