import 'package:flutter/material.dart';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';

import 'package:app/features/home/presentation/screens/statistics_screen.dart';
import 'package:app/features/home/presentation/widgets/bottom_navbar.dart';
import 'package:app/features/home/presentation/widgets/dashboard_content.dart';
import 'package:app/features/home/presentation/widgets/search_dialog.dart';
import 'package:app/features/home/presentation/widgets/side_drawer/app_drawer.dart';
import 'package:app/routes/routes.dart';

// TODO: Implement Dashboard Page
class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

enum DashboardTab { dashboard, statistics }

const _tabs = [DashboardTab.dashboard, DashboardTab.statistics];

class _DashboardPageState extends State<DashboardPage> {
  String? _currentSearchQuery;
  Map<String, String?>? _currentFilters;

  DashboardTab _selectedTab = DashboardTab.dashboard;

  void _onItemTapped(int index) {
    setState(() {
      _selectedTab = _tabs[index];
    });
  }

  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return AppBar(
      title: Text(_getAppBarTitle(context)),
      actions: _getAppBarActions(),
    );
  }

  String _getAppBarTitle(BuildContext context) {
    final localizations = AppLocalizations.of(context)!;
    return switch (_selectedTab) {
      DashboardTab.dashboard => localizations.dashboard,
      DashboardTab.statistics => localizations.statistics,
    };
  }

  List<Widget>? _getAppBarActions() {
    if (_selectedTab != DashboardTab.dashboard) return null;

    return [
      IconButton(
        icon: const Icon(Icons.search_outlined),
        onPressed: _onSearchPressed,
      ),
      IconButton(
        icon: const Icon(Icons.notifications_none_outlined),
        onPressed: _onNotificationPressed,
      ),
    ];
  }

  void _onSearchPressed() async {
    final result = await showDialog(
      context: context,
      builder:
          (context) => AdvancedSearchDialog(
            query: _currentSearchQuery,
            filters: _currentFilters,
          ),
    );

    if (result != null) {
      setState(() {
        _currentFilters = result['filters'];
        _currentSearchQuery = result['query'];
      });
    }
  }

  void _onNotificationPressed() {
    Navigator.pushNamed(context, AppRoutes.notification);
  }

  Widget _buildBodyContent() {
    return switch (_selectedTab) {
      DashboardTab.dashboard => DashboardContent(
        key: ValueKey('dashboard_content'),
        onRefresh: () => setState(() {}),
        currentSearchQuery: _currentSearchQuery,
        currentFilters: _currentFilters,
      ),
      DashboardTab.statistics => StatisticsScreen(),
    };
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: _buildAppBar(context),
      drawer: const AppDrawer(),
      body: _buildBodyContent(),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.pushNamed(context, AppRoutes.complaintForm),
        child: const Icon(Icons.add, size: 28),
      ),
      bottomNavigationBar: BottomAppNavbar(
        currentIndex: _tabs.indexOf(_selectedTab),
        onTap: _onItemTapped,
      ),
    );
  }
}
