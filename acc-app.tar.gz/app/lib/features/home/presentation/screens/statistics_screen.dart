import 'dart:convert';
import 'package:flutter_gen/gen_l10n/app_localizations.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import 'package:app/core/config/app_config.dart';
import 'package:app/core/config/preferences_config.dart';
import 'package:app/core/utils/status_util.dart';

class StatisticsScreen extends StatefulWidget {
  const StatisticsScreen({super.key});

  @override
  State<StatisticsScreen> createState() => _StatisticsScreenState();
}

class _StatisticsScreenState extends State<StatisticsScreen> {
  Map<String, dynamic> statsData = {
    "user_id": -1,
    "total_complaints": 0,
    "statuses": {
      "rejected": "0",
      "pending": "0",
      "processing": "0",
      "solved": "0",
    },
  };

  bool isLoading = true;
  String? errorMessage;

  @override
  void initState() {
    super.initState();
    _loadStatistics();
  }

  Future<void> _loadStatistics() async {
    try {
      final _prefs = await SharedPreferences.getInstance();
      final userId = _prefs.getInt(PreferencesConfig.userId) ?? -1;

      final response = await http.get(
        Uri.parse("${AppConfig.baseUrl}/complaints/stats?user_id=$userId"),
      );

      if (response.statusCode == 200) {
        setState(() {
          statsData = json.decode(response.body);
          isLoading = false;
        });
      } else {
        setState(() {
          errorMessage = 'Failed to load statistics';
          isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        errorMessage = 'Error: ${e.toString()}';
        isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final localizations = AppLocalizations.of(context)!;

    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child:
            isLoading
                ? const Center(child: CircularProgressIndicator())
                : errorMessage != null
                ? Center(child: Text(errorMessage!))
                : Column(
                  children: [
                    _buildSummaryCard(localizations),
                    const SizedBox(height: 20),
                    _buildStatusList(localizations),
                  ],
                ),
      ),
    );
  }

  Widget _buildSummaryCard(AppLocalizations localizations) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text(
              localizations.total_complaints,
              style: TextStyle(fontSize: 16, color: Colors.grey[600]),
            ),
            const SizedBox(height: 8),
            Text(
              statsData['total_complaints'].toString(),
              style: const TextStyle(fontSize: 36, fontWeight: FontWeight.bold),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusList(AppLocalizations localizations) {
    final statuses = statsData['statuses'] as Map<String, dynamic>;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              localizations.status_summary_title,
              style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 12),
            ...statuses.entries.map(
              (entry) => _buildStatusItem(entry.key, entry.value),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusItem(String status, String count) {
    final color = getComplaintStatusColor(status);

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8.0),
      child: Row(
        children: [
          Container(
            width: 12,
            height: 12,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              getTranslatedComplaintStatus(context, status),
              style: const TextStyle(fontSize: 16),
            ),
          ),
          Text(
            count,
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: color,
            ),
          ),
        ],
      ),
    );
  }
}
