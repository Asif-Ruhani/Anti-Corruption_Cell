import 'package:app/features/auth/presentation/screens/otp_screen.dart';
import 'package:app/features/languageSelection/presentation/screens/language_selection_screen.dart';
import 'package:flutter/material.dart';

import 'package:app/features/about/presentation/screens/about_screen.dart';
import 'package:app/features/complaint/presentation/screens/complaint_form_screen.dart';
import 'package:app/features/home/presentation/screens/dashboard_screen.dart';
import 'package:app/features/home/presentation/screens/statistics_screen.dart';
import 'package:app/features/auth/presentation/screens/login_screen.dart';
import 'package:app/features/notification/presentation/screens/notification_screen.dart';
import 'package:app/features/settings/presentation/screens/settings_screen.dart';
import 'package:app/features/support/presentation/screens/support_screen.dart';
import 'package:app/routes/routes.dart';

class AppRouter {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case AppRoutes.root:
        return MaterialPageRoute(
          builder: (_) => Text("Never gonna let you down"),
        );
      case AppRoutes.about:
        return MaterialPageRoute(builder: (_) => const AboutScreen());
      case AppRoutes.dashboard:
        return MaterialPageRoute(builder: (_) => const DashboardPage());
      case AppRoutes.complaintForm:
        return MaterialPageRoute(builder: (_) => const ComplaintFormScreen());
      case AppRoutes.notification:
        return MaterialPageRoute(builder: (_) => const NotificationScreen());
      case AppRoutes.login:
        return MaterialPageRoute(builder: (_) => const LoginScreen());
      case AppRoutes.language:
        return MaterialPageRoute(builder: (_) => LanguageSelectionScreen());
      case AppRoutes.otp:
        return MaterialPageRoute(builder: (_) => const OTPScreen());
      case AppRoutes.settings:
        return MaterialPageRoute(builder: (_) => const SettingsScreen());
      case AppRoutes.support:
        return MaterialPageRoute(builder: (_) => const SupportScreen());
      case AppRoutes.statistics:
        return MaterialPageRoute(builder: (_) => StatisticsScreen());
      default:
        return MaterialPageRoute(
          builder:
              (_) => Scaffold(
                body: Center(
                  child: Text('No route defined for ${settings.name}'),
                ),
              ),
        );
    }
  }
}
