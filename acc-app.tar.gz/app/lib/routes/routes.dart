abstract class AppRoutes {
  static const root = '/';
  static const about = '/about';
  static const dashboard = '/dashboard';
  static const complaintForm = '/complaintForm';
  static const notification = '/notification';
  static const language = '/language';
  static const login = '/login';
  static const otp = '/otp';
  static const settings = '/settings';
  static const support = '/support';
  static const statistics = '/statistics';
}
